/* ============================================================
   SQL Space Guardian -- frontend
   Vanilla JS SPA: polls the API, renders gauges + sparklines,
   drives the ambient bubble field, and handles the add-server drawer.
   ============================================================ */

const STATUS_COLOR = { ok: 'var(--green)', warn: 'var(--amber)', alert: 'var(--red)' };
const STATUS_HEX = { ok: '#3DDC97', warn: '#F5A623', alert: '#FF5C5C' };
const TOAST_AUTO_CLOSE_MS = 10000;
const DEFAULT_WARNING_PCT = 70;
const DEFAULT_CRITICAL_PCT = 80;
const runtimeFlags = {
  enableFileDelete: false,
  enableSqlLogShrink: false,
  enableSqlDataFileMove: false,
  enableSqlOps: false,
  aiConfigured: false,
};

const activeToastIds = new Set();
const toastTimers = new Map();
const mountToastKeys = new Set();
const actionToastSeen = new Set();
const sqlConnPromptSeen = new Set();
const sqlPrepPromptSeen = new Set();
let actionToastBootstrapped = false;
let sqlConnPromptServerId = null;

function warningFor(criticalPct = DEFAULT_CRITICAL_PCT) {
  return criticalPct === DEFAULT_CRITICAL_PCT ? DEFAULT_WARNING_PCT : Math.max(0, criticalPct - 10);
}

function statusFor(pct, criticalPct = DEFAULT_CRITICAL_PCT) {
  if (pct === null || pct === undefined) return 'ok';
  if (pct >= criticalPct) return 'alert';
  if (pct >= warningFor(criticalPct)) return 'warn';
  return 'ok';
}

function fmtTime(iso) {
  const d = new Date(iso + (iso.endsWith('Z') ? '' : 'Z'));
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function fmtScanInterval(data) {
  const seconds = data.scan_interval_seconds;
  if (seconds && seconds < 60) return `every ${seconds}s`;
  if (seconds && seconds % 60 !== 0) return `every ${seconds}s`;
  return `every ${data.scan_interval_minutes}m`;
}

function showToast({ id, type = 'info', title, message, autoCloseMs = TOAST_AUTO_CLOSE_MS }) {
  const stack = document.getElementById('toastStack');
  if (!stack) return;

  const toastId = id || `toast:${Date.now()}:${Math.random()}`;
  if (activeToastIds.has(toastId)) return;
  activeToastIds.add(toastId);

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.dataset.toastId = toastId;
  toast.innerHTML = `
    <button class="toast-close" type="button" aria-label="Close alert">x</button>
    <div class="toast-title">${escapeHtml(title)}</div>
    <div class="toast-message">${escapeHtml(message)}</div>
  `;

  toast.querySelector('.toast-close').addEventListener('click', () => dismissToast(toast));
  stack.prepend(toast);

  const timer = setTimeout(() => dismissToast(toast), autoCloseMs);
  toastTimers.set(toastId, timer);
}

function parseApiError(text) {
  try {
    const data = JSON.parse(text);
    return data.detail || data.message || text;
  } catch (_err) {
    return text;
  }
}

function dismissToast(toast) {
  if (!toast) return;
  const toastId = toast.dataset.toastId;
  if (toastTimers.has(toastId)) {
    clearTimeout(toastTimers.get(toastId));
    toastTimers.delete(toastId);
  }
  activeToastIds.delete(toastId);
  toast.remove();
}

function triggerMountPointToasts(mountPoints, force = false) {
  mountPoints.forEach(mp => {
    const latest = mp.latest;
    const criticalPct = mp.mount_point.threshold_pct || DEFAULT_CRITICAL_PCT;
    const warningPct = warningFor(criticalPct);
    const pct = latest ? latest.used_pct : null;
    const status = statusFor(pct, criticalPct);
    const key = `mount-${status}:${mp.mount_point.id}`;
    const server = mp.server || {};
    const labelPath = `${mp.mount_point.label || ''} ${mp.mount_point.path || ''}`.toLowerCase();
    const isUserBackupMount = mp.mount_point.folder_type === 'sqlbackups_mp' || labelPath.includes('sqlbackups_mp');

    if (pct !== null && pct >= warningPct && isUserBackupMount && !server.has_sql_conn_string) {
      const prepKey = `sql-prep:${server.id || mp.mount_point.server_id}:${mp.mount_point.id}`;
      if (!sqlPrepPromptSeen.has(prepKey)) {
        sqlPrepPromptSeen.add(prepKey);
        openSqlConnectionPrompt({
          server_id: server.id || mp.mount_point.server_id,
          message: `${mp.mount_point.label} is at ${pct.toFixed(1)}% used. Enter the SQL connection string now so the app is ready to take fresh compressed full and differential backups before old backup cleanup is needed.`,
        });
      }
    }

    if (pct === null || status === 'ok') {
      mountToastKeys.delete(`mount-warn:${mp.mount_point.id}`);
      mountToastKeys.delete(`mount-alert:${mp.mount_point.id}`);
      return;
    }
    if (mountToastKeys.has(key) && !force) return;

    mountToastKeys.add(key);
    const freeText = latest ? `${fmtSpace(latest.free_gb)} free` : 'latest scan unavailable';
    showToast({
      id: key,
      type: status,
      title: status === 'alert' ? 'Space critical alert' : 'Space warning',
      message: status === 'alert'
        ? `${mp.mount_point.label} is at ${pct.toFixed(1)}% used (critical ${criticalPct}%). ${freeText}.`
        : `${mp.mount_point.label} is at ${pct.toFixed(1)}% used (warning ${warningPct}%, critical ${criticalPct}%). ${freeText}.`,
    });
  });
}

function triggerActionToasts(rows) {
  const keyFor = row => row.id ?? `${row.created_at}:${row.action_type}:${row.message}`;

  if (!actionToastBootstrapped) {
    rows.forEach(row => actionToastSeen.add(keyFor(row)));
    actionToastBootstrapped = true;
    return;
  }

  [...rows].reverse().forEach(row => {
    const key = keyFor(row);
    if (actionToastSeen.has(key)) return;
    actionToastSeen.add(key);

    if (!['alert', 'failed'].includes(row.status)) return;
    showToast({
      id: `action:${key}`,
      type: row.status,
      title: row.status === 'failed' ? 'Action failed' : 'Action alert',
      message: `${row.action_type}: ${row.message}`,
    });
  });
}

function needsSqlConnectionPrompt(row) {
  if (!row || row.action_type !== 'PROD_BACKUP_CLEANUP_HELD') return false;
  const message = row.message || '';
  return /SQL backup preflight is not configured|SQL connection string|No SQL connection/i.test(message);
}

function openSqlConnectionPrompt(row) {
  if (!row?.server_id) return;
  sqlConnPromptServerId = row.server_id;
  const modal = document.getElementById('sqlConnModal');
  const backdrop = document.getElementById('sqlConnBackdrop');
  const message = document.getElementById('sqlConnMessage');
  const input = document.getElementById('sqlConnInput');
  message.textContent = row.message || 'Enter the SQL connection string so the app can monitor SQL jobs, active transactions, log reuse waits, backups, and log shrink decisions.';
  input.value = '';
  modal.classList.add('open');
  backdrop.classList.add('open');
  setTimeout(() => input.focus(), 80);
}

function closeSqlConnectionPrompt() {
  document.getElementById('sqlConnModal')?.classList.remove('open');
  document.getElementById('sqlConnBackdrop')?.classList.remove('open');
  sqlConnPromptServerId = null;
}

/* ---------------------------------------------------------- */
/* Ambient bubble field -- one bubble family per mount point,   */
/* sized by GB used, coloured by status, drifting upward slowly */
/* ---------------------------------------------------------- */
const canvas = document.getElementById('bubbleField');
const ctx = canvas.getContext('2d');
let bubbles = [];
let bubbleSeeds = []; // derived from live mount point data

function resizeCanvas() {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.ceil(window.innerWidth * dpr);
  canvas.height = Math.ceil(window.innerHeight * dpr);
  canvas.style.width = `${window.innerWidth}px`;
  canvas.style.height = `${window.innerHeight}px`;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

function seedBubblesFromStatus(mountPoints) {
  bubbleSeeds = mountPoints.map(mp => {
    const pct = mp.latest ? mp.latest.used_pct : 30;
    const criticalPct = mp.mount_point.threshold_pct || DEFAULT_CRITICAL_PCT;
    return { status: statusFor(pct, criticalPct), size: 8 + Math.min(pct, 100) / 4 };
  });
  if (bubbleSeeds.length === 0) {
    bubbleSeeds = [{ status: 'ok', size: 14 }, { status: 'ok', size: 10 }];
  }
  // (Re)populate the floating pool. Keep a healthy minimum so a single
  // watched mount point still creates a full-screen ambient field.
  bubbles = [];
  const minBubbleCount = 38;
  const perSeed = Math.max(18, Math.ceil(minBubbleCount / bubbleSeeds.length));
  for (let s = 0; s < bubbleSeeds.length; s++) {
    for (let i = 0; i < perSeed; i++) {
      bubbles.push(spawnBubble(bubbleSeeds[s], true));
    }
  }
}

function spawnBubble(seed, fillViewport = false) {
  return {
    x: Math.random() * window.innerWidth,
    y: fillViewport ? Math.random() * window.innerHeight : window.innerHeight + Math.random() * 80,
    r: Math.max(14, seed.size * (0.7 + Math.random() * 0.9)),
    speed: 0.10 + Math.random() * 0.16, // slow, smooth
    drift: (Math.random() - 0.5) * 0.15,
    color: STATUS_HEX[seed.status],
    seed,
    wobble: Math.random() * Math.PI * 2,
  };
}

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function animateBubbles() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (const b of bubbles) {
    if (!reduceMotion) {
      b.y -= b.speed;
      b.wobble += 0.01;
      b.x += b.drift + Math.sin(b.wobble) * 0.08;
      if (b.y < -20) {
        b.y = window.innerHeight + 20;
        b.x = Math.random() * window.innerWidth;
      }
    }
    const grad = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
    grad.addColorStop(0, b.color + 'AA');
    grad.addColorStop(1, b.color + '00');
    ctx.beginPath();
    ctx.fillStyle = grad;
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.strokeStyle = b.color + '55';
    ctx.lineWidth = 1;
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.stroke();
  }
  requestAnimationFrame(animateBubbles);
}
requestAnimationFrame(animateBubbles);

/* ---------------------------------------------------------- */
/* SVG gauge ring + sparkline renderers                        */
/* ---------------------------------------------------------- */
function gaugeSvg(pct, status) {
  const r = 30, c = 2 * Math.PI * r;
  const offset = c - (Math.min(pct, 100) / 100) * c;
  const color = STATUS_HEX[status];
  return `
    <svg class="gauge" viewBox="0 0 74 74">
      <circle cx="37" cy="37" r="${r}" fill="none" stroke="var(--steel-soft)" stroke-width="7"/>
      <circle cx="37" cy="37" r="${r}" fill="none" stroke="${color}" stroke-width="7"
        stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${offset}"
        transform="rotate(-90 37 37)"/>
      <text x="37" y="42" text-anchor="middle" class="gauge-pct" fill="${color}">${pct.toFixed(0)}%</text>
    </svg>`;
}

function sparklineSvg(history, status) {
  if (!history || history.length < 2) {
    return `<svg class="sparkline" viewBox="0 0 200 30"><line x1="0" y1="28" x2="200" y2="28" stroke="var(--steel-soft)"/></svg>`;
  }
  const vals = history.map(h => h.used_pct);
  const min = Math.min(...vals), max = Math.max(...vals, min + 1);
  const w = 200, h = 30;
  const pts = vals.map((v, i) => {
    const x = (i / (vals.length - 1)) * w;
    const y = h - ((v - min) / (max - min)) * (h - 4) - 2;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  const color = STATUS_HEX[status];
  return `<svg class="sparkline" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
    <polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
}

const FOLDER_TYPE_LABEL = {
  general: 'General',
  data_mp: 'Data files',
  log_mp: 'Log files',
  tempdb_mp: 'tempdb files',
  sqlbackups_mp: 'User DB backups',
  sqlbackup_mp2: 'Relief target',
  testbackups_mp: 'Restore / test backups',
  systembackups_mp: 'System DB backups',
  sqltest_backups: 'Restore / test',
  log_drive: 'Log drive',
};

const FOLDER_SHORT_LABEL = {
  general: 'general',
  data_mp: 'data',
  log_mp: 'logs',
  tempdb_mp: 'tempdb',
  sqlbackups_mp: 'backups',
  sqlbackup_mp2: 'backup relief',
  testbackups_mp: 'test backups',
  systembackups_mp: 'system',
  sqltest_backups: 'test backups',
  log_drive: 'logs',
};

const BACKUP_FOLDER_TYPES = new Set(['sqlbackups_mp', 'systembackups_mp']);
const TEST_BACKUP_FOLDER_TYPES = new Set(['testbackups_mp', 'sqltest_backups']);
const LOG_FOLDER_TYPES = new Set(['log_mp', 'log_drive']);

let selectedActionMountPoint = null;
let selectedActionSqlDiagnostics = null;
let currentServerGroupKey = null;
let latestStatusData = null;
let latestActionRows = [];
let aiChatMessages = [];
let opslogLevel = 0;

function fmtSpace(gb) {
  if (gb === null || gb === undefined || Number.isNaN(gb)) return 'n/a';
  const absGb = Math.abs(gb);
  if (absGb < 1) return `${Math.round(gb * 1024).toLocaleString()} MB`;
  if (absGb < 10) return `${gb.toFixed(2)} GB`;
  return `${gb.toFixed(1)} GB`;
}

function diagnosticCount(diag, key, fallbackArrayKey = null) {
  if (!diag) return 0;
  if (typeof diag[key] === 'number') return diag[key];
  if (fallbackArrayKey && Array.isArray(diag[fallbackArrayKey])) return diag[fallbackArrayKey].length;
  return 0;
}

function buildActionPlan(mp, sqlDiagnostics = null) {
  const latest = mp.latest;
  const mount = mp.mount_point;
  const criticalPct = mount.threshold_pct || DEFAULT_CRITICAL_PCT;
  const warningPct = warningFor(criticalPct);
  const folderType = mount.folder_type;
  const fc = mp.forecast || {};

  if (!latest) {
    return {
      status: 'alert',
      statusText: 'Scan failed',
      summary: 'The app could not read this path during the latest scan.',
      steps: [
        'Check that the path is reachable from the server running this app.',
        'Confirm the Windows account running Python has permission to read the folder or share.',
        'Fix the path or permissions, then run Scan now again.',
      ],
      metrics: [
        ['Path', mount.path],
        ['Folder type', FOLDER_TYPE_LABEL[folderType] || folderType],
      ],
    };
  }

  const pct = latest.used_pct;
  const status = statusFor(pct, criticalPct);
  const criticalUsedGb = latest.total_gb * criticalPct / 100;
  const aboveCriticalGb = Math.max(0, latest.used_gb - criticalUsedGb);
  const extraCapacityGb = criticalPct > 0
    ? Math.max(0, (latest.used_gb / (criticalPct / 100)) - latest.total_gb)
    : 0;
  const growth = fc.growth_gb_per_day ?? 0;

  let summary = 'No immediate action is needed. Keep monitoring the trend.';
  let steps = [
    `Keep the monitor active. It stays green below ${warningPct}%.`,
    'Run Scan now after any manual cleanup or capacity change.',
  ];

  if (status === 'warn') {
    summary = `${mount.label} crossed the ${warningPct}% warning level but has not reached the ${criticalPct}% critical level.`;
    steps = [
      'Review the recent growth trend and expected incoming backup or data volume.',
      `Plan cleanup or capacity before the drive crosses ${criticalPct}%.`,
      'Run Scan now after any change so the dashboard refreshes immediately.',
    ];
  }

  if (status === 'alert') {
    if (BACKUP_FOLDER_TYPES.has(folderType)) {
      const backupScope = folderType === 'systembackups_mp' ? 'system database backup' : 'user database backup';
      summary = `${mount.label} is over the ${backupScope} threshold. The app will look for older backup files and can alert the team.`;
      steps = [
        folderType === 'sqlbackups_mp'
          ? 'Pair this primary backup mount with a SQLBackup_MP2 relief target if automatic rebalance is desired.'
          : 'Keep master, model, and msdb backup retention tight; do not mix large user database backups here.',
        'Review backup files older than the configured retention before deleting anything manually.',
        fc.recommended_add_gb
          ? `Request about ${fmtSpace(fc.recommended_add_gb)} of additional storage for runway.`
          : `Request additional capacity if cleanup or rebalance cannot bring the drive below ${criticalPct}%.`,
      ];
    } else if (folderType === 'sqlbackup_mp2') {
      summary = `${mount.label} is a relief target and should stay below its own threshold.`;
      steps = [
        'Do not move more backup files into this relief target until usage drops.',
        'Free older non-protected backup files or add capacity.',
        'Check paired primary backup mounts after cleanup.',
      ];
    } else if (TEST_BACKUP_FOLDER_TYPES.has(folderType)) {
      summary = `${mount.label} is over threshold for restore/test backups.`;
      steps = [
        'Confirm no active restore or validation job still needs these files.',
        runtimeFlags.enableFileDelete
          ? 'Use mark restore complete when the restore is done so eligible old restore backups can be cleared.'
          : 'Deletion is disabled. Review the candidate files in the ops log before enabling cleanup.',
        `Run Scan now after cleanup to confirm the drive drops below ${warningPct}%.`,
      ];
    } else if (LOG_FOLDER_TYPES.has(folderType)) {
      summary = `${mount.label} is over threshold for a log drive.`;
      steps = [
        'Confirm log backups are running successfully and the database recovery model is expected.',
        'Enable SQL ops only when the connection string and permissions are ready.',
        'If this repeats, add log-drive capacity or investigate unusual transaction growth.',
      ];
    } else if (folderType === 'data_mp') {
      summary = `${mount.label} is over threshold for SQL data files.`;
      steps = [
        'Check which database data files are growing fastest before moving or shrinking anything.',
        'Plan capacity for .mdf/.ndf growth; avoid placing logs or backups in data_mp.',
        'If files are still in the default SQL DATA folder, plan an offline move or ALTER DATABASE file relocation during a maintenance window.',
      ];
    } else if (folderType === 'tempdb_mp') {
      summary = `${mount.label} is over threshold for tempdb files.`;
      steps = [
        'Check active sessions for spills, version store growth, large sorts, and long-running transactions.',
        'Size tempdb files intentionally and keep tempdb separate from user data/log/backup folders.',
        'If tempdb must be moved, update SQL Server tempdb file paths and restart SQL Server during a planned window.',
      ];
    } else {
      summary = `${mount.label} is above the configured ${criticalPct}% critical level.`;
      steps = [
        `Free or move about ${fmtSpace(aboveCriticalGb)} to get back under the current critical target.`,
        `If cleanup is not possible, add about ${fmtSpace(extraCapacityGb)} of capacity to make current usage land at ${criticalPct}%.`,
        'Check whether this should be a backup/test/log monitor instead of General so the app can apply the right automation.',
      ];
    }
  }

  const metrics = [
    ['Used', fmtSpace(latest.used_gb)],
    ['Free', fmtSpace(latest.free_gb)],
    ['Total', fmtSpace(latest.total_gb)],
    ['Warning', `${warningPct}%`],
    ['Critical', `${criticalPct}%`],
    ['Above critical', fmtSpace(aboveCriticalGb)],
    ['Growth/day', fmtSpace(growth)],
  ];

  if (fc.days_to_threshold !== null && fc.days_to_threshold !== undefined) {
    metrics.push(['Days to threshold', `${fc.days_to_threshold}`]);
  }
  if (fc.recommended_add_gb) {
    metrics.push(['Recommended add', fmtSpace(fc.recommended_add_gb)]);
  }

  if (sqlDiagnostics) {
    const runningJobs = diagnosticCount(sqlDiagnostics, 'running_jobs_count', 'running_jobs');
    const scheduledJobs = diagnosticCount(sqlDiagnostics, 'scheduled_jobs', 'next_jobs');
    const activeRequests = diagnosticCount(sqlDiagnostics, 'active_requests_count', 'active_requests');
    const activeTransactions = diagnosticCount(sqlDiagnostics, 'active_transactions_count', 'active_transactions');
    const logReuseWaits = diagnosticCount(sqlDiagnostics, 'log_reuse_waits_count', 'log_reuse_waits');

    if (sqlDiagnostics.status === 'not_configured') {
      steps.push('Add a SQL connection string for this server to monitor SQL Agent jobs, restore/backup activity, and log transaction pressure.');
    } else if (sqlDiagnostics.status === 'failed') {
      steps.push(`Fix SQL diagnostics connection: ${sqlDiagnostics.summary || sqlDiagnostics.message || 'connection failed'}`);
    } else if (sqlDiagnostics.status === 'ok') {
      if (activeRequests > 0) {
        steps.unshift('SQL Server currently has backup, restore, or DBCC work in progress; expect disk usage to move while it runs.');
      }
      if (runningJobs > 0) {
        steps.unshift('A SQL Agent job is currently running; check whether it writes backup or restore files to this mount.');
      }
      if (activeTransactions > 0 || logReuseWaits > 0) {
        steps.push('Active transactions or log reuse waits are present; review them before shrinking logs or assuming log space can be reclaimed.');
      }
    }

    metrics.push(['SQL jobs running', `${runningJobs}`]);
    metrics.push(['SQL jobs scheduled', `${scheduledJobs}`]);
    metrics.push(['SQL active work', `${activeRequests}`]);
    metrics.push(['SQL active trx', `${activeTransactions}`]);
  }

  return {
    status,
    statusText: status === 'alert' ? 'Action needed' : status === 'warn' ? 'Watch closely' : 'Healthy',
    summary,
    steps,
    metrics,
  };
}

function openActionModal(mp, sqlDiagnostics = null) {
  selectedActionMountPoint = mp;
  selectedActionSqlDiagnostics = sqlDiagnostics;
  const modal = document.getElementById('actionModal');
  const backdrop = document.getElementById('actionModalBackdrop');
  const title = document.getElementById('actionModalTitle');
  const kicker = document.getElementById('actionModalKicker');
  const body = document.getElementById('actionModalBody');
  if (!modal || !backdrop || !title || !body) return;

  const plan = buildActionPlan(mp, sqlDiagnostics);
  const latest = mp.latest;
  const pct = latest ? `${latest.used_pct.toFixed(1)}% used` : 'No latest usage';
  const typeLabel = FOLDER_TYPE_LABEL[mp.mount_point.folder_type] || mp.mount_point.folder_type;
  const recentActions = mp.recent_actions || [];
  const cleanupAction = backupCleanupAction(mp);
  const cleanupApprovalHtml = cleanupAction ? `
    <div class="action-start-card">
      <div>
        <b>Guarded backup cleanup is ready</b>
        <p>Are you okay to start? The app will take fresh compressed full and differential backups first, then delete only eligible old backup files outside protected folders.</p>
      </div>
      <button type="button" class="action-start-btn" data-start-backup-cleanup="${mp.mount_point.id}">Start guarded cleanup</button>
    </div>
  ` : '';
  const historyHtml = recentActions.length
    ? recentActions.map(action => `
        <div class="action-history-row ${action.status}">
          <div>
            <b>${escapeHtml(action.action_type)}</b>
            <span>${fmtTime(action.created_at)}</span>
          </div>
          <p>${escapeHtml(action.message)}</p>
        </div>
      `).join('')
    : '<div class="action-empty-history">No action history for this mount point yet.</div>';

  title.textContent = mp.mount_point.label;
  kicker.textContent = 'AI recommendation';
  body.innerHTML = `
    <div class="action-status">
      <b>${escapeHtml(pct)} / ${escapeHtml(typeLabel)}</b>
      <span class="action-pill ${plan.status}">${escapeHtml(plan.statusText)}</span>
    </div>
    <div class="action-section">
      <div class="action-section-title">What to do</div>
      <div class="action-copy">${escapeHtml(plan.summary)}</div>
      ${cleanupApprovalHtml}
    </div>
    <div class="action-section">
      <div class="action-section-title">Steps</div>
      <ol class="action-list">
        ${plan.steps.map(step => `<li>${escapeHtml(step)}</li>`).join('')}
      </ol>
    </div>
    <div class="action-section">
      <div class="action-section-title">Current scan</div>
      <div class="action-metrics">
        ${plan.metrics.map(([label, value]) => `
          <div class="action-metric">
            <span>${escapeHtml(label)}</span>
            <b>${escapeHtml(value)}</b>
          </div>
        `).join('')}
      </div>
    </div>
    <div class="action-section">
      <div class="action-section-title">Action history</div>
      <div class="action-history">
        ${historyHtml}
      </div>
    </div>
  `;

  modal.classList.add('open');
  backdrop.classList.add('open');
}

function closeActionModal() {
  selectedActionMountPoint = null;
  selectedActionSqlDiagnostics = null;
  document.getElementById('actionModal')?.classList.remove('open');
  document.getElementById('actionModalBackdrop')?.classList.remove('open');
}

function backupCleanupAction(mp) {
  if (!mp || mp.mount_point.folder_type !== 'sqlbackups_mp') return null;
  return (mp.recent_actions || []).find(action =>
    ['PROD_BACKUP_CLEANUP_READY', 'PROD_BACKUP_CLEANUP_HELD'].includes(action.action_type)
    && action.action_type !== 'PROD_BACKUP_CLEANUP'
  );
}

function renderSqlHealth(diag) {
  if (!diag) {
    return `<div class="sql-health sql-health-muted">SQL checks pending background scan</div>`;
  }
  if (diag.status === 'not_configured') {
    return `<div class="sql-health sql-health-muted">SQL checks not configured</div>`;
  }
  if (diag.status === 'failed') {
    return `<div class="sql-health sql-health-failed">SQL checks failed: ${escapeHtml(diag.summary || diag.message || 'connection issue')}</div>`;
  }

  const runningJobs = diagnosticCount(diag, 'running_jobs_count', 'running_jobs');
  const scheduledJobs = diagnosticCount(diag, 'scheduled_jobs', 'next_jobs');
  const activeRequests = diagnosticCount(diag, 'active_requests_count', 'active_requests');
  const activeTransactions = diagnosticCount(diag, 'active_transactions_count', 'active_transactions');
  const logReuseWaits = diagnosticCount(diag, 'log_reuse_waits_count', 'log_reuse_waits');
  const className = activeRequests || runningJobs || activeTransactions || logReuseWaits
    ? 'sql-health sql-health-warn'
    : 'sql-health sql-health-ok';

  return `
    <div class="${className}">
      SQL checks: ${scheduledJobs} scheduled job(s), ${runningJobs} running, ${activeRequests} backup/restore/DBCC, ${activeTransactions} active trx, ${logReuseWaits} log waits
    </div>
  `;
}

function serverGroupKey(serverName) {
  return (serverName || 'unnamed server').trim().toLowerCase();
}

function groupServersByName(servers) {
  const groups = new Map();
  servers.forEach(entry => {
    const key = serverGroupKey(entry.server.name);
    if (!groups.has(key)) {
      groups.set(key, {
        key,
        name: entry.server.name || 'Unnamed server',
        servers: [],
        mountItems: [],
      });
    }
    const group = groups.get(key);
    group.servers.push(entry);
    entry.mount_points.forEach(mp => {
      group.mountItems.push({
        mp,
        server: entry.server,
        sqlDiagnostics: entry.sql_diagnostics,
      });
    });
  });
  return [...groups.values()];
}

function summarizeServerGroup(group) {
  let totalGb = 0;
  let usedGb = 0;
  let freeGb = 0;
  let worstPct = 0;
  let missing = 0;
  let worstStatus = 'ok';
  const statusRank = { ok: 0, warn: 1, alert: 2 };

  group.mountItems.forEach(({ mp }) => {
    if (!mp.latest) {
      missing += 1;
      worstStatus = 'alert';
      return;
    }
    const criticalPct = mp.mount_point.threshold_pct || DEFAULT_CRITICAL_PCT;
    const mpStatus = statusFor(mp.latest.used_pct, criticalPct);
    totalGb += mp.latest.total_gb || 0;
    usedGb += mp.latest.used_gb || 0;
    freeGb += mp.latest.free_gb || 0;
    worstPct = Math.max(worstPct, mp.latest.used_pct || 0);
    if (statusRank[mpStatus] > statusRank[worstStatus]) {
      worstStatus = mpStatus;
    }
  });

  const usedPct = totalGb > 0 ? (usedGb / totalGb) * 100 : worstPct;
  return { totalGb, usedGb, freeGb, usedPct, worstPct, worstStatus, missing };
}

function miniDonutSvg(pct, status) {
  const r = 13;
  const c = 2 * Math.PI * r;
  const value = Math.max(0, Math.min(pct ?? 0, 100));
  const offset = c - (value / 100) * c;
  const color = STATUS_HEX[status] || STATUS_HEX.ok;
  return `
    <svg class="mini-donut" viewBox="0 0 36 36" aria-hidden="true">
      <circle cx="18" cy="18" r="${r}" fill="none" stroke="var(--steel-soft)" stroke-width="5"/>
      <circle cx="18" cy="18" r="${r}" fill="none" stroke="${color}" stroke-width="5"
        stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${offset}"
        transform="rotate(-90 18 18)"/>
    </svg>
  `;
}

function compactMountLabel(mp, index = 0) {
  const label = (mp.mount_point.label || '').trim();
  const shortType = FOLDER_SHORT_LABEL[mp.mount_point.folder_type];
  if (shortType && label.toLowerCase() === mp.mount_point.folder_type.toLowerCase()) return shortType;
  if (label && !/[\\/]/.test(label)) return label;
  if (shortType && mp.mount_point.folder_type !== 'general') return shortType;

  const path = (mp.mount_point.path || '').replace(/[\\/]+$/, '');
  const parts = path.split(/[\\/]/).filter(Boolean);
  return parts.at(-1) || `mount ${index + 1}`;
}

function statusText(status) {
  if (status === 'alert') return 'Critical';
  if (status === 'warn') return 'Warning';
  return 'Healthy';
}

function serverDonutSvg(summary, mountItems) {
  const r = 54;
  const c = 2 * Math.PI * r;
  const center = 74;
  let cursor = 0;
  const totalGb = summary.totalGb || 0;

  const segments = mountItems.map(({ mp }) => {
    if (!mp.latest || totalGb <= 0) return '';
    const value = Math.max(0, Math.min(mp.latest.used_gb / totalGb, 1));
    if (value <= 0) return '';

    const criticalPct = mp.mount_point.threshold_pct || DEFAULT_CRITICAL_PCT;
    const status = statusFor(mp.latest.used_pct, criticalPct);
    const dashLength = Math.max(0, c * value - 2.2);
    const gapLength = c - dashLength;
    const dashOffset = -cursor;
    cursor += c * value;

    return `
      <circle cx="${center}" cy="${center}" r="${r}" fill="none" stroke="${STATUS_HEX[status]}" stroke-width="22"
        stroke-dasharray="${dashLength} ${gapLength}" stroke-dashoffset="${dashOffset}"
        transform="rotate(-90 ${center} ${center})"/>
    `;
  }).join('');

  return `
    <svg class="server-donut" viewBox="0 0 148 148" aria-hidden="true">
      <circle cx="${center}" cy="${center}" r="${r}" fill="none" stroke="var(--steel-soft)" stroke-width="22"/>
      ${segments}
      <text x="${center}" y="${center - 2}" text-anchor="middle" class="server-donut-pct">${summary.usedPct.toFixed(0)}%</text>
      <text x="${center}" y="${center + 23}" text-anchor="middle" class="server-donut-sub">used</text>
    </svg>
  `;
}

function statusRank(status) {
  return { ok: 0, warn: 1, alert: 2 }[status] ?? 0;
}

function getMountStatus(mp) {
  if (!mp.latest) return 'alert';
  return statusFor(mp.latest.used_pct, mp.mount_point.threshold_pct || DEFAULT_CRITICAL_PCT);
}

function getWorstMountItem(group) {
  return [...group.mountItems].sort((a, b) => {
    const aStatus = getMountStatus(a.mp);
    const bStatus = getMountStatus(b.mp);
    const statusDelta = statusRank(bStatus) - statusRank(aStatus);
    if (statusDelta) return statusDelta;
    return ((b.mp.latest?.used_pct || 0) - (a.mp.latest?.used_pct || 0));
  })[0] || null;
}

function folderActionCopy(mp) {
  const type = mp.mount_point.folder_type;
  if (type === 'data_mp') {
    return runtimeFlags.enableSqlDataFileMove
      ? 'AI can prepare and run a SQL data-file relocation when a safe relief data mount exists.'
      : 'AI will recommend a relief data mount and prepare SQL steps, but automatic movement is disabled.';
  }
  if (LOG_FOLDER_TYPES.has(type)) {
    return runtimeFlags.enableSqlLogShrink
      ? 'AI can check log reuse waits and shrink the largest safe log file when this mount crosses critical.'
      : 'AI will diagnose log pressure, but automatic log shrink is disabled.';
  }
  if (TEST_BACKUP_FOLDER_TYPES.has(type)) {
    return runtimeFlags.enableFileDelete
      ? 'AI can clear eligible restore-test backups after protection rules are checked.'
      : 'AI will only list cleanup candidates because file deletion is disabled.';
  }
  if (BACKUP_FOLDER_TYPES.has(type)) {
    return 'AI watches growth and recommends retention cleanup, capacity, or a backup relief target.';
  }
  return 'AI watches trend, threshold, and scan health for this mount point.';
}

function buildServerRecommendation(group) {
  const summary = summarizeServerGroup(group);
  const worst = getWorstMountItem(group);
  if (!worst) {
    return {
      status: 'ok',
      title: 'No mount points configured',
      body: 'Add mount points to this server folder so AI can watch capacity and SQL activity.',
      optionA: 'Add mount point',
      optionB: 'Run scan',
    };
  }

  const { mp } = worst;
  const latest = mp.latest;
  const status = getMountStatus(mp);
  const label = compactMountLabel(mp);
  if (!latest) {
    return {
      status: 'alert',
      title: 'Scan path needs attention',
      body: `${label} could not be scanned. Check path, share access, or Windows permissions before AI can act on live capacity.`,
      optionA: 'Fix path access',
      optionB: 'Scan again',
    };
  }

  const criticalPct = mp.mount_point.threshold_pct || DEFAULT_CRITICAL_PCT;
  const warningPct = warningFor(criticalPct);
  if (status === 'alert') {
    return {
      status,
      title: 'Immediate action recommended',
      body: `${label} is at ${latest.used_pct.toFixed(1)}% used. ${folderActionCopy(mp)}`,
      optionA: mp.mount_point.folder_type === 'data_mp' ? 'Find relief mount' : LOG_FOLDER_TYPES.has(mp.mount_point.folder_type) ? 'Check log reuse' : 'Review cleanup',
      optionB: `Get below ${warningPct}%`,
      mountLabel: label,
    };
  }
  if (status === 'warn') {
    return {
      status,
      title: 'Watch this folder closely',
      body: `${label} crossed warning at ${latest.used_pct.toFixed(1)}%. AI is watching growth before it reaches ${criticalPct}%.`,
      optionA: 'Review trend',
      optionB: 'Plan capacity',
    };
  }
  return {
    status: summary.worstStatus,
    title: 'Storage is stable',
    body: `${group.name} is at ${summary.usedPct.toFixed(1)}% overall. AI will keep scanning every cycle and only alert when action is needed.`,
    optionA: 'Keep monitoring',
    optionB: 'Open mount cards',
    mountLabel: group.name,
  };
}

function renderDetailKpis(group) {
  const summary = summarizeServerGroup(group);
  const counts = { ok: 0, warn: 0, alert: 0 };
  group.mountItems.forEach(({ mp }) => counts[getMountStatus(mp)] += 1);
  return `
    <div class="console-kpis">
      <div class="console-kpi"><span>Used</span><b>${fmtSpace(summary.usedGb)}</b></div>
      <div class="console-kpi"><span>Free</span><b>${fmtSpace(summary.freeGb)}</b></div>
      <div class="console-kpi"><span>Total</span><b>${fmtSpace(summary.totalGb)}</b></div>
      <div class="console-kpi"><span>Risk</span><b class="${summary.worstStatus}">${counts.alert} critical / ${counts.warn} warning</b></div>
    </div>
  `;
}

function renderStrataLayers(group) {
  const totalGb = group.mountItems.reduce((sum, item) => sum + (item.mp.latest?.total_gb || 0), 0);
  if (!group.mountItems.length) return '<div class="console-empty">No mount points in this server folder.</div>';

  return group.mountItems.map(({ mp }, index) => {
    const latest = mp.latest;
    const status = getMountStatus(mp);
    const pct = latest ? latest.used_pct : 0;
    const share = latest && totalGb > 0 ? Math.max(44, Math.min(72, (latest.total_gb / totalGb) * 140)) : 44;
    const label = compactMountLabel(mp, index);
    return `
      <button class="strata-layer ${status}" type="button" data-open-mp="${mp.mount_point.id}" style="--fill:${Math.max(0, Math.min(pct, 100))}%; --layer-size:${share}px; --layer-color:${STATUS_HEX[status]}">
        <span class="strata-layer-fill"></span>
        <span class="strata-layer-name">${escapeHtml(label)}</span>
        <span class="strata-layer-meta">${latest ? `${fmtSpace(latest.used_gb)} / ${fmtSpace(latest.total_gb)}` : 'scan failed'}</span>
        <b>${latest ? `${pct.toFixed(0)}%` : 'n/a'}</b>
      </button>
    `;
  }).join('');
}

function aggregateTrendPoints(group) {
  const summary = summarizeServerGroup(group);
  const histories = group.mountItems.map(({ mp }) => mp.history || []).filter(rows => rows.length);
  const maxLen = Math.max(0, ...histories.map(rows => rows.length));
  let points = [];
  for (let i = Math.max(0, maxLen - 30); i < maxLen; i++) {
    let used = 0;
    let total = 0;
    histories.forEach(rows => {
      const offset = i - (maxLen - rows.length);
      if (offset >= 0 && offset < rows.length) {
        used += Number(rows[offset].used_gb || 0);
        total += Number(rows[offset].total_gb || 0);
      }
    });
    if (total > 0) {
      points.push({ label: `${i - maxLen + 1}`, pct: (used / total) * 100 });
    }
  }
  if (points.length < 2) {
    const base = Math.max(0, summary.usedPct - 3);
    points = Array.from({ length: 12 }, (_, index) => ({
      label: `${index - 11}`,
      pct: base + ((summary.usedPct - base) * (index / 11)),
    }));
  }
  const growth = group.mountItems.reduce((sum, { mp }) => sum + Number(mp.forecast?.growth_gb_per_day || 0), 0);
  const growthPct = summary.totalGb > 0 ? (growth / summary.totalGb) * 100 : 0;
  const last = points.at(-1)?.pct || summary.usedPct || 0;
  const projection = Array.from({ length: 14 }, (_, index) => ({
    label: `${index + 1}`,
    pct: Math.min(100, last + Math.max(growthPct, 0.08) * (index + 1)),
  }));
  return { actual: points, projection };
}

function trendSvg(group) {
  const { actual, projection } = aggregateTrendPoints(group);
  const all = [...actual, ...projection];
  const rawMin = Math.min(...all.map(p => p.pct));
  const rawMax = Math.max(...all.map(p => p.pct), rawMin + 1);
  const padded = Math.max((rawMax - rawMin) * 0.35, 4);
  const min = Math.max(0, rawMin - padded);
  const max = Math.min(100, rawMax + padded);
  const w = 360;
  const h = 150;
  const left = 42;
  const right = 14;
  const top = 14;
  const bottom = 28;
  const plotW = w - left - right;
  const plotH = h - top - bottom;
  const xFor = (index, total) => left + (index / Math.max(1, total - 1)) * plotW;
  const yFor = value => top + (1 - ((value - min) / Math.max(1, max - min))) * plotH;
  const actualPts = actual.map((p, i) => `${xFor(i, actual.length + projection.length - 1).toFixed(1)},${yFor(p.pct).toFixed(1)}`).join(' ');
  const projPts = [actual.at(-1), ...projection].map((p, i) => `${xFor(actual.length - 1 + i, actual.length + projection.length - 1).toFixed(1)},${yFor(p.pct).toFixed(1)}`).join(' ');
  const splitX = xFor(actual.length - 1, actual.length + projection.length - 1);
  const areaPts = `${left},${top + plotH} ${actualPts} ${splitX},${top + plotH}`;
  const yTop = `${max.toFixed(0)}%`;
  const yMid = `${((min + max) / 2).toFixed(0)}%`;
  const yBottom = `${min.toFixed(0)}%`;
  return `
    <svg class="usage-trend-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">
      <line x1="${left}" y1="${top}" x2="${w - right}" y2="${top}" />
      <line x1="${left}" y1="${top + plotH / 2}" x2="${w - right}" y2="${top + plotH / 2}" />
      <line x1="${left}" y1="${top + plotH}" x2="${w - right}" y2="${top + plotH}" />
      <line class="trend-split" x1="${splitX}" y1="${top}" x2="${splitX}" y2="${top + plotH}" />
      <polygon class="trend-area" points="${areaPts}" />
      <polyline class="trend-actual" points="${actualPts}" />
      <polyline class="trend-projection" points="${projPts}" />
      <text class="trend-y" x="2" y="${top + 4}">${yTop}</text>
      <text class="trend-y" x="2" y="${top + plotH / 2 + 4}">${yMid}</text>
      <text class="trend-y" x="2" y="${top + plotH + 4}">${yBottom}</text>
      <text x="${left}" y="${h - 5}">-30</text>
      <text x="${splitX - 4}" y="${h - 5}">0</text>
      <text x="${w - right - 18}" y="${h - 5}">+14</text>
    </svg>
  `;
}

function renderUsageTrendPanel(group) {
  return `
    <article class="console-panel usage-trend-panel">
      <div class="console-panel-title split-title">
        <span>Usage trend</span>
        <small>30d history · 14d projection</small>
      </div>
      ${trendSvg(group)}
    </article>
  `;
}

function renderBackupsPanel(group) {
  const backupMounts = group.mountItems.filter(({ mp }) => BACKUP_FOLDER_TYPES.has(mp.mount_point.folder_type) || TEST_BACKUP_FOLDER_TYPES.has(mp.mount_point.folder_type));
  const backupActions = group.mountItems
    .flatMap(({ mp }) => (mp.recent_actions || []).map(action => ({ ...action, mountLabel: compactMountLabel(mp) })))
    .filter(action => /BACKUP|RESTORE|CLEANUP|REBALANCE/i.test(action.action_type));
  const fullAction = backupActions[0];
  const incrementalAction = backupActions[1];
  return `
    <article class="console-panel backups-panel">
      <div class="console-panel-title split-title">
        <span>Backups</span>
        <small>${backupMounts.length} backup mount(s)</small>
      </div>
      <div class="backup-status-list">
        <div class="backup-status-card success">
          <span>Full backup</span>
          <b>${fullAction ? statusText(fullAction.status === 'success' ? 'ok' : fullAction.status === 'failed' ? 'alert' : 'warn') : 'No recent event'}</b>
          <p>${fullAction ? `${fmtTime(fullAction.created_at)} · ${escapeHtml(fullAction.mountLabel)} · ${escapeHtml(fullAction.action_type)}` : 'Waiting for SQL backup job/action history.'}</p>
        </div>
        <div class="backup-status-card ${incrementalAction?.status === 'failed' ? 'alert' : 'success'}">
          <span>Incremental</span>
          <b>${incrementalAction ? statusText(incrementalAction.status === 'success' ? 'ok' : incrementalAction.status === 'failed' ? 'alert' : 'warn') : 'No recent event'}</b>
          <p>${incrementalAction ? `${fmtTime(incrementalAction.created_at)} · ${escapeHtml(incrementalAction.mountLabel)}` : 'No differential/incremental event captured yet.'}</p>
        </div>
      </div>
    </article>
  `;
}

function renderSqlConsolePanel(group) {
  const server = group.servers[0]?.server || {};
  const isConnected = Boolean(server.has_sql_conn_string);
  const connectionButton = `
    <button
      type="button"
      class="sql-connection-toggle ${isConnected ? 'connected' : 'disconnected'}"
      data-sql-connection-toggle="${server.id || ''}"
      data-connected="${isConnected ? 'true' : 'false'}"
      title="${isConnected ? 'Disconnect SQL monitoring for this server' : 'Connect SQL monitoring for this server'}"
    >
      <span></span>${isConnected ? 'Connected' : 'Disconnected'}
    </button>
  `;
  const diag = group.mountItems.map(item => item.sqlDiagnostics).find(item => item && item.status !== 'not_configured')
    || group.mountItems[0]?.sqlDiagnostics;
  if (!diag || diag.status === 'not_configured') {
    return `
      <article class="console-panel sql-ops-panel">
        <div class="console-panel-title split-title">
          <span>SQL operations</span>
          ${connectionButton}
        </div>
        <div class="console-empty">${isConnected ? 'SQL checks are waiting for the next scan.' : 'SQL checks are disconnected for this server folder.'}</div>
      </article>
    `;
  }
  if (diag.status === 'failed') {
    return `
      <article class="console-panel sql-ops-panel">
        <div class="console-panel-title split-title">
          <span>SQL operations</span>
          ${connectionButton}
        </div>
        <div class="console-empty danger">SQL checks failed: ${escapeHtml(diag.summary || diag.message || 'connection issue')}</div>
      </article>
    `;
  }

  const stats = [
    ['Scheduled jobs', diagnosticCount(diag, 'scheduled_jobs', 'next_jobs')],
    ['Running jobs', diagnosticCount(diag, 'running_jobs_count', 'running_jobs')],
    ['Backup/restore/DBCC', diagnosticCount(diag, 'active_requests_count', 'active_requests')],
    ['Active transactions', diagnosticCount(diag, 'active_transactions_count', 'active_transactions')],
    ['Log reuse waits', diagnosticCount(diag, 'log_reuse_waits_count', 'log_reuse_waits')],
  ];
  const logRows = Array.isArray(diag.log_space) ? diag.log_space.slice(0, 4) : [];
  return `
    <article class="console-panel sql-ops-panel">
      <div class="console-panel-title split-title">
        <span>SQL operations</span>
        ${connectionButton}
      </div>
      <div class="sql-console-grid">
        ${stats.map(([label, value]) => `<div><span>${escapeHtml(label)}</span><b>${value}</b></div>`).join('')}
      </div>
      <div class="mini-history">
        ${logRows.length ? logRows.map(row => `
          <div class="mini-history-row">
            <span>${escapeHtml(row.database_name || row.name || 'database')}</span>
            <b>${row.log_space_used_percent !== undefined ? `${Number(row.log_space_used_percent).toFixed(1)}% log` : 'log ok'}</b>
          </div>
        `).join('') : '<div class="console-empty">No active log pressure reported.</div>'}
      </div>
    </article>
  `;
}

function renderAutomationPanel() {
  const items = [
    ['SQL ops', runtimeFlags.enableSqlOps, 'Required for SQL file movement and log shrink workflows.', 'ENABLE_SQL_OPS', true],
    ['Data-file move', runtimeFlags.enableSqlDataFileMove, 'Moves .mdf/.ndf only after SQL preflight and permissions pass.', 'ENABLE_SQL_DATA_FILE_MOVE'],
    ['Log shrink', runtimeFlags.enableSqlLogShrink, 'Checks log reuse waits before DBCC SHRINKFILE.', 'ENABLE_SQL_LOG_SHRINK'],
    ['File cleanup', runtimeFlags.enableFileDelete, 'Deletes only eligible backup files outside protected folders.', 'ENABLE_FILE_DELETE'],
    ['AI key', runtimeFlags.aiConfigured, 'Uses AI for recommendations and action explanation.', null],
  ];
  return `
    <article class="console-panel automation-panel">
      <div class="console-panel-title">Automation guardrails</div>
      <div class="automation-list">
        ${items.map(([label, enabled, copy, key]) => `
          <div class="automation-row ${enabled ? 'on' : 'off'}">
            <span>${escapeHtml(label)}</span>
            <p>${escapeHtml(copy)}</p>
            ${key ? `<button type="button" class="automation-toggle" data-setting="${escapeHtml(key)}" data-enabled="${enabled ? 'true' : 'false'}">${enabled ? 'Disable' : 'Enable'}</button>` : '<span class="automation-static">Configured</span>'}
          </div>
        `).join('')}
      </div>
    </article>
  `;
}

function renderServerHistory(group) {
  const rows = group.mountItems
    .flatMap(({ mp }) => (mp.recent_actions || []).map(action => ({ ...action, mountLabel: compactMountLabel(mp) })))
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(0, 30);
  return `
    <article class="console-panel console-panel-wide history-console-card">
      <div class="console-panel-title split-title">
        <span>AI history for this server</span>
        <small>${rows.length} event(s)</small>
      </div>
      <div class="history-filters">
        <label><span>Start</span><input type="date" class="history-start"></label>
        <label><span>End</span><input type="date" class="history-end"></label>
        <button type="button" class="history-clear">Clear</button>
      </div>
      <div class="server-history-list scrollable-history">
        ${rows.length ? rows.map(row => `
          <div class="server-history-row ${row.status}" data-history-date="${escapeHtml((row.created_at || '').slice(0, 10))}">
            <time>${fmtTime(row.created_at)}</time>
            <span>${escapeHtml(row.mountLabel)}</span>
            <b>${escapeHtml(row.action_type)}</b>
            <p>${escapeHtml(row.message)}</p>
          </div>
        `).join('') : '<div class="console-empty">No AI actions recorded for this server folder yet.</div>'}
      </div>
    </article>
  `;
}

function renderServerFolderCard(group) {
  const summary = summarizeServerGroup(group);
  const status = summary.worstStatus;
  const hosts = [...new Set(group.servers.map(s => s.server.host).filter(Boolean))];
  const card = document.createElement('div');
  card.className = `server-folder-card ${status}`;
  card.tabIndex = 0;
  card.setAttribute('role', 'button');
  card.setAttribute('aria-label', `Open ${group.name} server folder`);
  card.style.setProperty('--status-color', STATUS_COLOR[status]);

  const labelCounts = new Map();
  group.mountItems.forEach(({ mp }, index) => {
    const label = compactMountLabel(mp, index);
    labelCounts.set(label, (labelCounts.get(label) || 0) + 1);
  });
  const labelSeen = new Map();

  const mountPreview = group.mountItems.map(({ mp, server }, index) => {
    const pct = mp.latest ? mp.latest.used_pct : null;
    const mpStatus = statusFor(pct ?? 0, mp.mount_point.threshold_pct || DEFAULT_CRITICAL_PCT);
    const baseLabel = compactMountLabel(mp, index);
    const seenCount = (labelSeen.get(baseLabel) || 0) + 1;
    labelSeen.set(baseLabel, seenCount);
    const label = labelCounts.get(baseLabel) > 1 ? `${baseLabel} ${seenCount}` : baseLabel;
    return `
      <div class="folder-legend-row" title="${escapeHtml(server.host || '')} / ${escapeHtml(mp.mount_point.path || label)}">
        <span class="legend-dot" style="--dot-color: ${STATUS_HEX[mpStatus]}"></span>
        <span class="legend-label">${escapeHtml(label)}</span>
        <b class="legend-pct ${mpStatus}">${pct === null ? 'n/a' : `${pct.toFixed(0)}%`}</b>
      </div>
    `;
  }).join('');

  card.innerHTML = `
    <div class="server-folder-head">
      <div>
        <div class="server-folder-title">${escapeHtml(group.name)}</div>
        <div class="server-folder-sub">${escapeHtml(hosts.join(', ') || 'no host')} &middot; ${group.mountItems.length} mount point(s)</div>
      </div>
      <div class="server-folder-actions">
        <span class="server-status-pill ${status}">${statusText(status)}</span>
        <button class="server-folder-remove" type="button" title="Remove server group" aria-label="Remove server group">x</button>
      </div>
    </div>
    <div class="server-folder-body">
      <div class="server-usage-donut">${serverDonutSvg(summary, group.mountItems)}</div>
      <div class="server-folder-legend">${mountPreview || '<span class="muted">No mount points</span>'}</div>
    </div>
    <div class="server-folder-totals">
      <div><span>Used</span><b>${fmtSpace(summary.usedGb)}</b></div>
      <div><span>Free</span><b>${fmtSpace(summary.freeGb)}</b></div>
      <div><span>Total</span><b>${fmtSpace(summary.totalGb)}</b></div>
    </div>
    <div class="server-folder-hint">Open server folder</div>
  `;

  card.querySelector('.server-folder-remove').addEventListener('click', async event => {
    event.stopPropagation();
    await removeServerGroup(group);
  });
  card.addEventListener('click', () => {
    currentServerGroupKey = group.key;
    refreshStatus();
  });
  card.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      currentServerGroupKey = group.key;
      refreshStatus();
    }
  });

  return card;
}

function renderServerDetail(group, listEl) {
  const detail = document.createElement('div');
  detail.className = 'server-detail';
  const hosts = [...new Set(group.servers.map(s => s.server.host).filter(Boolean))];
  const summary = summarizeServerGroup(group);
  const recommendation = buildServerRecommendation(group);
  detail.innerHTML = `
    <div class="server-detail-head">
      <button class="btn btn-ghost btn-sm" id="backToDashboardBtn">Back</button>
      <div>
        <div class="server-detail-title">${escapeHtml(group.name)}</div>
        <div class="server-detail-sub">${escapeHtml(hosts.join(', ') || 'no host')} / ${group.mountItems.length} mount point(s)</div>
      </div>
      <button class="btn btn-ghost btn-sm" id="detailAddMountBtn">+ Add mount point</button>
      <span class="server-status-pill ${summary.worstStatus}">${statusText(summary.worstStatus)}</span>
    </div>
    <section class="server-console" style="--status-color:${STATUS_COLOR[summary.worstStatus]}">
      ${renderDetailKpis(group)}
      <div class="console-main">
        <article class="console-recommendation ${recommendation.status}">
          <div class="recommendation-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" focusable="false">
              <path d="M13.4 2.7 5.8 13h5.1l-1.1 8.3 7.9-11h-5.2l.9-7.6Z" />
            </svg>
          </div>
          <div>
            <span class="console-kicker recommendation-strip">AI standing recommendation / ${escapeHtml(recommendation.mountLabel || group.name)}</span>
            <h3>${escapeHtml(recommendation.title)}</h3>
            <p>${escapeHtml(recommendation.body)}</p>
          </div>
          <div class="console-options">
            <span>${escapeHtml(recommendation.optionA)}</span>
            <span>${escapeHtml(recommendation.optionB)}</span>
            <button type="button" class="ai-discuss-btn" data-ai-discuss="${escapeHtml(recommendation.title)}">Discuss with AI →</button>
          </div>
        </article>
        <article class="console-panel strata-panel">
          <div class="console-panel-title">Storage strata</div>
          <div class="strata-stack">${renderStrataLayers(group)}</div>
        </article>
        ${renderSqlConsolePanel(group)}
        ${renderUsageTrendPanel(group)}
        ${renderBackupsPanel(group)}
        ${renderAutomationPanel()}
        ${renderServerHistory(group)}
      </div>
      <div class="detail-section-title">Mount point cards</div>
      <div class="detail-mp-grid"></div>
    </section>
  `;

  const grid = detail.querySelector('.detail-mp-grid');
  group.mountItems.forEach(({ mp, sqlDiagnostics }) => {
    grid.appendChild(renderMountCard(mp, sqlDiagnostics));
  });

  detail.querySelectorAll('[data-open-mp]').forEach(btn => {
    btn.addEventListener('click', event => {
      const mountId = Number(event.currentTarget.dataset.openMp);
      const item = group.mountItems.find(({ mp }) => mp.mount_point.id === mountId);
      if (item) openActionModal(item.mp, item.sqlDiagnostics);
    });
  });

  detail.querySelectorAll('[data-ai-discuss]').forEach(btn => {
    btn.addEventListener('click', event => {
      event.stopPropagation();
      openAiPanelWithPrompt(`${recommendation.title}: ${recommendation.body}`);
    });
  });

  wireHistoryFilters(detail);

  detail.querySelector('#backToDashboardBtn').addEventListener('click', () => {
    currentServerGroupKey = null;
    refreshStatus();
  });
  detail.querySelector('#detailAddMountBtn').addEventListener('click', () => {
    openDrawerForServerGroup(group);
  });
  listEl.appendChild(detail);
}

async function removeServerGroup(group) {
  const confirmed = confirm(`Remove "${group.name}" and all ${group.mountItems.length} monitored mount point(s)?`);
  if (!confirmed) return;
  await Promise.all(group.servers.map(entry => fetch(`/api/servers/${entry.server.id}`, { method: 'DELETE' })));
  if (currentServerGroupKey === group.key) currentServerGroupKey = null;
  await Promise.all([refreshStatus(), refreshLog()]);
}

async function removeMonitoring(mp) {
  const confirmed = confirm(`Remove monitoring for "${mp.mount_point.label}"? Scan history for this card will be removed.`);
  if (!confirmed) return;

  const res = await fetch(`/api/mount_points/${mp.mount_point.id}`, { method: 'DELETE' });
  if (!res.ok) {
    showToast({
      id: `delete-failed:${mp.mount_point.id}:${Date.now()}`,
      type: 'failed',
      title: 'Remove failed',
      message: `Could not remove monitoring for ${mp.mount_point.label}.`,
    });
    return;
  }

  closeActionModal();
  mountToastKeys.delete(`mount-alert:${mp.mount_point.id}`);
  showToast({
    id: `delete-success:${mp.mount_point.id}:${Date.now()}`,
    type: 'success',
    title: 'Monitoring removed',
    message: `${mp.mount_point.label} is no longer being watched.`,
  });
  await Promise.all([refreshStatus(), refreshLog()]);
}

/* ---------------------------------------------------------- */
/* Main render                                                 */
/* ---------------------------------------------------------- */
async function refreshStatus({ forceToasts = false } = {}) {
  const res = await fetch(`/api/status?t=${Date.now()}`, { cache: 'no-store' });
  const data = await res.json();
  latestStatusData = data;
  runtimeFlags.enableFileDelete = Boolean(data.enable_file_delete);
  runtimeFlags.enableSqlLogShrink = Boolean(data.enable_sql_log_shrink);
  runtimeFlags.enableSqlDataFileMove = Boolean(data.enable_sql_data_file_move);
  runtimeFlags.enableSqlOps = Boolean(data.enable_sql_ops);
  runtimeFlags.aiConfigured = Boolean(data.ai_configured);

  document.getElementById('chipDemo').textContent = data.demo_mode ? 'DEMO DATA' : 'LIVE FILESYSTEM';
  document.getElementById('chipDemo').className = 'chip' + (data.demo_mode ? ' warn' : ' ok');
  document.getElementById('chipAi').textContent = data.ai_configured ? 'AI ENABLED' : 'AI: NO KEY YET';
  document.getElementById('chipAi').className = 'chip' + (data.ai_configured ? ' ok' : '');
  document.getElementById('chipNext').textContent = fmtScanInterval(data);

  const listEl = document.getElementById('serverList');
  const emptyEl = document.getElementById('emptyState');
  listEl.innerHTML = '';

  const allMountPoints = [];
  data.servers.forEach(s => s.mount_points.forEach(mp => allMountPoints.push({ ...mp, server: s.server })));
  seedBubblesFromStatus(allMountPoints);
  triggerMountPointToasts(allMountPoints, forceToasts);

  if (data.servers.length === 0) {
    emptyEl.style.display = 'block';
    return;
  }
  emptyEl.style.display = 'none';

  const groups = groupServersByName(data.servers);
  const selectedGroup = groups.find(group => group.key === currentServerGroupKey);
  listEl.className = selectedGroup ? 'server-list is-detail' : 'server-list';

  if (currentServerGroupKey && !selectedGroup) {
    currentServerGroupKey = null;
  }

  if (selectedGroup) {
    renderServerDetail(selectedGroup, listEl);
    return;
  }

  groups.forEach(group => {
    listEl.appendChild(renderServerFolderCard(group));
  });
}

function renderMountCard(mp, sqlDiagnostics = null) {
  const pct = mp.latest ? mp.latest.used_pct : null;
  const criticalPct = mp.mount_point.threshold_pct || DEFAULT_CRITICAL_PCT;
  const warningPct = warningFor(criticalPct);
  const status = statusFor(pct ?? 0, criticalPct);
  const card = document.createElement('div');
  card.className = 'mp-card';
  card.tabIndex = 0;
  card.setAttribute('role', 'button');
  card.setAttribute('aria-label', `Show recommended action for ${mp.mount_point.label}`);
  card.style.setProperty('--status-color', STATUS_COLOR[status]);

  const fc = mp.forecast || {};
  let footer = '';
  if (pct === null) {
    footer = `<span class="danger">Unreachable on last scan -- check the path/permissions.</span>`;
  } else if (status === 'alert') {
    if (BACKUP_FOLDER_TYPES.has(mp.mount_point.folder_type)) {
      footer = `<span class="danger">Critical: ${criticalPct}%+.</span> ~${fmtSpace(fc.growth_gb_per_day)} / day growth.
        ${fc.recommended_add_gb ? `Suggest adding <b>${fmtSpace(fc.recommended_add_gb)}</b>.` : ''}`;
    } else if (TEST_BACKUP_FOLDER_TYPES.has(mp.mount_point.folder_type)) {
      footer = runtimeFlags.enableFileDelete
        ? `<span class="danger">Critical: ${criticalPct}%+.</span> Eligible old restore backups can be cleared.`
        : `<span class="danger">Critical: ${criticalPct}%+.</span> Cleanup is disabled; candidates are listed in ops log.`;
    } else if (LOG_FOLDER_TYPES.has(mp.mount_point.folder_type)) {
      footer = `<span class="danger">Critical: ${criticalPct}%+.</span> Shrink workflow will run this cycle.`;
    } else if (mp.mount_point.folder_type === 'data_mp') {
      footer = `<span class="danger">Critical: ${criticalPct}%+.</span> Data-file capacity action needed.`;
    } else if (mp.mount_point.folder_type === 'tempdb_mp') {
      footer = `<span class="danger">Critical: ${criticalPct}%+.</span> Check tempdb pressure and active sessions.`;
    } else {
      footer = `<span class="danger">Critical usage (${criticalPct}%+).</span>`;
    }
  } else if (status === 'warn') {
    footer = `<span class="accent">Warning: ${warningPct}%+.</span> Watch growth before it reaches ${criticalPct}%.`;
  } else if (fc.days_to_threshold !== null && fc.days_to_threshold !== undefined) {
    footer = `Healthy. Trending toward ${criticalPct}% in <b>${fc.days_to_threshold}</b> day(s).`;
  } else {
    footer = `Healthy. Warning at ${warningPct}%, critical at ${criticalPct}%.`;
  }

  let actionsHtml = '';
  if (TEST_BACKUP_FOLDER_TYPES.has(mp.mount_point.folder_type)) {
    actionsHtml = `<div class="mp-actions"><button data-mark-restore="${mp.mount_point.id}">mark restore complete</button></div>`;
  } else if (backupCleanupAction(mp)) {
    actionsHtml = `
      <div class="mp-actions mp-actions-approval">
        <span>Approve fresh backup + old cleanup?</span>
        <button data-start-backup-cleanup="${mp.mount_point.id}">start</button>
      </div>
    `;
  }

  card.innerHTML = `
    <div class="mp-card-head">
      <div>
        <div class="mp-label">${escapeHtml(mp.mount_point.label)}</div>
        <div class="mp-type-tag">${FOLDER_TYPE_LABEL[mp.mount_point.folder_type] || mp.mount_point.folder_type}</div>
      </div>
      <button class="mp-card-remove" type="button" title="Remove monitoring" aria-label="Remove monitoring" data-delete-mp="${mp.mount_point.id}">x</button>
    </div>
    <div class="mp-body">
      ${gaugeSvg(pct ?? 0, status)}
      <div class="mp-stats">
        <div class="row"><span>Used</span><b>${mp.latest ? fmtSpace(mp.latest.used_gb) : '–'}</b></div>
        <div class="row"><span>Free</span><b>${mp.latest ? fmtSpace(mp.latest.free_gb) : '–'}</b></div>
        <div class="row"><span>Total</span><b>${mp.latest ? fmtSpace(mp.latest.total_gb) : '–'}</b></div>
        <div class="row"><span>Warning</span><b>${warningPct}%</b></div>
        <div class="row"><span>Critical</span><b>${criticalPct}%</b></div>
      </div>
    </div>
    ${sparklineSvg(mp.history, status)}
    <div class="mp-footer">${footer}</div>
    ${actionsHtml}
  `;

  card.querySelectorAll('[data-mark-restore]').forEach(btn => {
    btn.addEventListener('click', async event => {
      event.stopPropagation();
      await fetch(`/api/mount_points/${btn.dataset.markRestore}/mark_restore_complete`, { method: 'POST' });
      refreshStatus();
    });
  });

  card.querySelectorAll('[data-start-backup-cleanup]').forEach(btn => {
    btn.addEventListener('click', async event => {
      event.stopPropagation();
      await startBackupCleanup(btn.dataset.startBackupCleanup, btn);
    });
  });

  card.querySelector('[data-delete-mp]').addEventListener('click', async btnEvent => {
    btnEvent.stopPropagation();
    await removeMonitoring(mp);
  });

  card.addEventListener('click', () => openActionModal(mp, sqlDiagnostics));
  card.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openActionModal(mp, sqlDiagnostics);
    }
  });

  return card;
}

/* ---------------------------------------------------------- */
/* Ops log                                                     */
/* ---------------------------------------------------------- */
async function refreshLog() {
  const res = await fetch(`/api/actions?limit=80&t=${Date.now()}`, { cache: 'no-store' });
  const rows = await res.json();
  latestActionRows = rows;
  const body = document.getElementById('opslogBody');
  body.innerHTML = rows.map(r => `
    <div class="log-row ${r.status}">
      <span class="log-time">${fmtTime(r.created_at)}</span>
      <span class="log-tag">${r.action_type}</span>
      <span class="log-msg">${escapeHtml(r.message)}</span>
    </div>
  `).join('');
  triggerActionToasts(rows);
  const promptRow = rows.find(row => {
    const key = row.id ?? `${row.created_at}:${row.action_type}:${row.message}`;
    return needsSqlConnectionPrompt(row) && !sqlConnPromptSeen.has(key);
  });
  if (promptRow) {
    const key = promptRow.id ?? `${promptRow.created_at}:${promptRow.action_type}:${promptRow.message}`;
    sqlConnPromptSeen.add(key);
    openSqlConnectionPrompt(promptRow);
  }
  renderAiPanel(rows);
}

function wireHistoryFilters(root) {
  const start = root.querySelector('.history-start');
  const end = root.querySelector('.history-end');
  const clear = root.querySelector('.history-clear');
  const rows = [...root.querySelectorAll('.server-history-row')];
  if (!start || !end || !rows.length) return;

  const apply = () => {
    const startValue = start.value;
    const endValue = end.value;
    rows.forEach(row => {
      const date = row.dataset.historyDate || '';
      const visible = (!startValue || date >= startValue) && (!endValue || date <= endValue);
      row.hidden = !visible;
    });
  };
  start.addEventListener('change', apply);
  end.addEventListener('change', apply);
  clear?.addEventListener('click', () => {
    start.value = '';
    end.value = '';
    apply();
  });
}

function aiActionTone(row) {
  if (row.status === 'success') return 'success';
  if (row.status === 'alert' || row.status === 'failed') return 'alert';
  return 'info';
}

function aiActionTitle(type) {
  const labels = {
    AI_REBALANCE: 'Rebalanced backups',
    SPACE_ALERT: 'Capacity decision',
    TEST_BACKUP_CLEANUP: 'Deleted old restore backups',
    TEST_BACKUP_HOLD: 'Held files',
    SHRINK_LOG: 'Log shrink decision',
    DATA_FILE_ACTION: 'Data-file action needed',
    TEMPDB_ACTION: 'tempdb action needed',
    GENERAL_SPACE_REVIEW: 'Space review',
    SCAN_FAILED: 'Scan failed',
  };
  return labels[type] || type.replaceAll('_', ' ').toLowerCase();
}

function renderAiPanel(rows) {
  const panelBody = document.getElementById('aiPanelBody');
  const summary = document.getElementById('aiPanelSummary');
  const count = document.getElementById('aiPanelCount');
  const actionCount = document.getElementById('aiActionCount');
  if (!panelBody || !summary || !count) return;

  const aiRows = rows
    .filter(row => row.mount_point_id && row.action_type !== 'CYCLE')
    .slice(0, 18);

  const successCount = aiRows.filter(row => row.status === 'success').length;
  const alertCount = aiRows.filter(row => row.status === 'alert' || row.status === 'failed').length;
  const holdCount = aiRows.filter(row => row.action_type.includes('HOLD') || row.message.toLowerCase().includes('held')).length;

  count.textContent = `${aiRows.length}`;
  if (actionCount) actionCount.textContent = `${aiRows.length} item${aiRows.length === 1 ? '' : 's'}`;
  summary.innerHTML = `
    <div><b>${successCount}</b><span>actions taken</span></div>
    <div><b>${holdCount}</b><span>files held</span></div>
    <div><b>${alertCount}</b><span>needs care</span></div>
  `;

  if (!aiRows.length) {
    panelBody.innerHTML = '';
    return;
  }

  panelBody.innerHTML = '';
}

function currentServerContext() {
  if (!latestStatusData?.servers?.length) return null;
  const groups = groupServersByName(latestStatusData.servers);
  return groups.find(group => group.key === currentServerGroupKey) || groups[0] || null;
}

function answerAiPrompt(prompt) {
  const group = currentServerContext();
  const text = prompt.toLowerCase();
  if (!group) return 'No server data is loaded yet. Run a scan or add a server first.';

  const summary = summarizeServerGroup(group);
  const worst = getWorstMountItem(group);
  const worstLabel = worst ? compactMountLabel(worst.mp) : 'no mount';
  const worstPct = worst?.mp.latest ? `${worst.mp.latest.used_pct.toFixed(1)}%` : 'scan failed';
  const alerts = group.mountItems.filter(({ mp }) => getMountStatus(mp) === 'alert');
  const actions = latestActionRows.filter(row => row.action_type !== 'CYCLE');

  if (
    (text.includes('recent') || text.includes('ai work') || text.includes('action history') || text.includes('what happened'))
    && !text.includes('deleted')
    && !text.includes('files')
    && !text.includes('backup')
  ) {
    const rows = actions.slice(0, 5);
    if (!rows.length) return 'No recent AI action records are available yet. I will show them here after scan decisions, cleanup holds, log shrink, or data-file movement events happen.';
    return `Recent AI work: ${rows.map(row => `${aiActionTitle(row.action_type)} at ${fmtTime(row.created_at)} - ${row.message}`).join(' ')}`;
  }

  if (text.includes('deleted') || text.includes('files')) {
    const deleteRows = actions.filter(row => /DELETE|CLEANUP|HELD|HOLD/i.test(`${row.action_type} ${row.message}`)).slice(0, 4);
    if (!deleteRows.length) return 'I do not see any recent deletion action in the action log. Cleanup may be disabled, or the latest run only listed candidates.';
    return `Recent file decisions: ${deleteRows.map(row => `${row.action_type} at ${fmtTime(row.created_at)} - ${row.message}`).join(' ')}`;
  }

  if (text.includes('backup')) {
    const backupRows = actions.filter(row => /BACKUP|RESTORE|REBALANCE|CLEANUP/i.test(`${row.action_type} ${row.message}`)).slice(0, 3);
    if (!backupRows.length) return `I see ${group.mountItems.filter(({ mp }) => BACKUP_FOLDER_TYPES.has(mp.mount_point.folder_type) || TEST_BACKUP_FOLDER_TYPES.has(mp.mount_point.folder_type)).length} backup-related mount point(s), but no recent backup action event.`;
    return `Backup-related activity: ${backupRows.map(row => `${row.action_type} at ${fmtTime(row.created_at)} - ${row.message}`).join(' ')}`;
  }

  if (text.includes('storage') || text.includes('add') || text.includes('space')) {
    if (!alerts.length) return `${group.name} is stable overall at ${summary.usedPct.toFixed(1)}% used. I do not see an immediate add-storage requirement right now.`;
    return `Yes, review storage now. ${alerts.length} mount point(s) are critical; the first is ${worstLabel} at ${worstPct}. ${folderActionCopy(worst.mp)}`;
  }

  if (text.includes('first') || text.includes('action') || text.includes('priority')) {
    return `Handle ${worstLabel} first. It is ${worstPct}, server overall is ${summary.usedPct.toFixed(1)}%, and the recommended path is: ${worst ? folderActionCopy(worst.mp) : 'keep monitoring.'}`;
  }

  if (text.includes('log') || text.includes('shrink')) {
    const logMounts = group.mountItems.filter(({ mp }) => LOG_FOLDER_TYPES.has(mp.mount_point.folder_type));
    if (!logMounts.length) return 'This server folder does not currently have a log_mp monitor.';
    const worstLog = logMounts.sort((a, b) => (b.mp.latest?.used_pct || 0) - (a.mp.latest?.used_pct || 0))[0];
    return `${compactMountLabel(worstLog.mp)} is at ${worstLog.mp.latest ? worstLog.mp.latest.used_pct.toFixed(1) : 'n/a'}%. Log shrink automation is ${runtimeFlags.enableSqlLogShrink ? 'enabled' : 'disabled'}, and SQL checks must pass before shrink runs.`;
  }

  return `${group.name}: ${summary.usedPct.toFixed(1)}% used, ${fmtSpace(summary.freeGb)} free. Worst mount is ${worstLabel} at ${worstPct}. Ask me about storage, backups, deleted files, logs, or priority action.`;
}

function renderAiChat() {
  const body = document.getElementById('aiChatBody');
  if (!body) return;
  body.innerHTML = aiChatMessages.length
    ? aiChatMessages.map(msg => `
      <div class="ai-chat-message ${msg.role}">
        <p>${escapeHtml(msg.text)}</p>
      </div>
    `).join('')
    : '<div class="ai-chat-empty">Ask about capacity, backups, recently deleted files, log shrink, or priority actions.</div>';
  requestAnimationFrame(() => {
    const scrollSurface = body.closest('.ai-panel-content') || body;
    scrollSurface.scrollTop = scrollSurface.scrollHeight;
  });
}

function sendAiPrompt(prompt) {
  const question = (prompt || '').trim();
  if (!question) return;
  aiChatMessages.push({ role: 'user', text: question });
  aiChatMessages.push({ role: 'assistant', text: answerAiPrompt(question) });
  renderAiChat();
}

async function startBackupCleanup(mpId, button = null) {
  if (!mpId) return;
  const ok = confirm('Start guarded production backup cleanup now? Fresh compressed full and differential backups will run first. Old eligible backup files will be deleted only after backup success.');
  if (!ok) return;

  const originalText = button?.textContent;
  if (button) {
    button.disabled = true;
    button.textContent = 'Starting...';
  }
  try {
    const res = await fetch(`/api/mount_points/${mpId}/start_backup_cleanup`, {
      method: 'POST',
      cache: 'no-store',
    });
    const text = await res.text();
    if (!res.ok) throw new Error(parseApiError(text));
    const data = text ? JSON.parse(text) : {};
    showToast({
      id: `backup-cleanup:${mpId}:${Date.now()}`,
      type: 'success',
      title: 'Backup cleanup completed',
      message: data.message || 'Fresh backups completed and old eligible backups were cleaned.',
      autoCloseMs: 14000,
    });
    closeActionModal();
    await refreshStatus(true);
    await refreshLog();
  } catch (error) {
    showToast({
      id: `backup-cleanup-failed:${mpId}:${Date.now()}`,
      type: 'failed',
      title: 'Cleanup did not start',
      message: error.message || 'Guarded backup cleanup failed.',
      autoCloseMs: 14000,
    });
    await refreshLog();
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = originalText || 'start';
    }
  }
}

async function toggleSqlConnection(serverId, isConnected, button = null) {
  if (!serverId) return;
  if (!isConnected) {
    openSqlConnectionPrompt({
      server_id: serverId,
      message: 'Connect SQL monitoring for this server. Use one of the examples below, then replace YOUR_SERVER / username / password as needed. Database=master is recommended for server-level monitoring.',
    });
    return;
  }

  const ok = confirm('Disconnect SQL monitoring for this server? SQL jobs, active transactions, log shrink, and backup cleanup preflight will stop until you connect again.');
  if (!ok) return;
  const originalText = button?.textContent;
  if (button) {
    button.disabled = true;
    button.textContent = 'Disconnecting...';
  }
  try {
    const res = await fetch(`/api/servers/${serverId}/sql_conn_string`, {
      method: 'DELETE',
      cache: 'no-store',
    });
    if (!res.ok) throw new Error(parseApiError(await res.text()));
    showToast({
      id: `sql-disconnected:${serverId}:${Date.now()}`,
      type: 'success',
      title: 'SQL disconnected',
      message: 'SQL monitoring is off for this server. Mount point storage scans will continue.',
    });
    await refreshStatus(true);
  } catch (error) {
    showToast({
      id: `sql-disconnect-failed:${serverId}:${Date.now()}`,
      type: 'failed',
      title: 'Disconnect failed',
      message: error.message || 'Could not clear SQL connection.',
    });
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = originalText || 'Connected';
    }
  }
}

function openAiPanelWithPrompt(prompt) {
  document.getElementById('aiPanel')?.classList.add('open');
  if (prompt) sendAiPrompt(prompt);
}

function setOpslogState(state) {
  const opslog = document.querySelector('.opslog');
  if (!opslog) return;
  opslogLevel = state === 'expanded' ? 2 : state === 'raised' ? 1 : 0;
  opslog.classList.toggle('raised', state === 'raised');
  opslog.classList.toggle('expanded', state === 'expanded');
  opslog.classList.toggle('collapsed', state === 'collapsed');
  document.body.classList.toggle('opslog-raised', state === 'raised');
  document.body.classList.toggle('opslog-expanded', state === 'expanded');
  document.body.classList.toggle('opslog-collapsed', state === 'collapsed');
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str ?? '';
  return d.innerHTML;
}

/* ---------------------------------------------------------- */
/* Drawer: add server                                          */
/* ---------------------------------------------------------- */
const drawer = document.getElementById('serverDrawer');
const backdrop = document.getElementById('drawerBackdrop');
const mpRowsEl = document.getElementById('mpRows');
const mpRowTemplate = document.getElementById('mpRowTemplate');

function openDrawer() {
  drawer.classList.add('open');
  backdrop.classList.add('open');
  document.body.classList.add('drawer-open');
}
function openDrawerForServerGroup(group) {
  const server = group?.servers?.[0]?.server;
  if (!server) {
    openDrawer();
    return;
  }
  document.getElementById('fServerName').value = server.name || group.name || '';
  document.getElementById('fServerHost').value = server.host || '';
  document.getElementById('fSqlConnString').value = server.sql_conn_string || '';
  document.getElementById('fServerDesc').value = server.description || '';
  mpRowsEl.innerHTML = '';
  addMpRow();
  document.getElementById('saveServerBtn').textContent = 'Add mount point';
  openDrawer();
  setTimeout(() => mpRowsEl.querySelector('.mp-label')?.focus(), 80);
}
function closeDrawer() {
  drawer.classList.remove('open');
  backdrop.classList.remove('open');
  document.body.classList.remove('drawer-open');
  document.getElementById('saveServerBtn').textContent = 'Save server';
}
document.getElementById('addServerBtn').addEventListener('click', openDrawer);
document.getElementById('emptyAddServerBtn').addEventListener('click', openDrawer);
document.getElementById('closeDrawerBtn').addEventListener('click', closeDrawer);
backdrop.addEventListener('click', closeDrawer);

const sqlConnectionTemplates = {
  local: 'Driver={ODBC Driver 18 for SQL Server};Server=localhost\\SQLEXPRESS;Database=master;Trusted_Connection=yes;TrustServerCertificate=yes;',
  windows: 'Driver={ODBC Driver 18 for SQL Server};Server=YOUR_SERVER\\SQLEXPRESS;Database=master;Trusted_Connection=yes;TrustServerCertificate=yes;',
  sqlauth: 'Driver={ODBC Driver 18 for SQL Server};Server=YOUR_SERVER;Database=master;UID=YOUR_USERNAME;PWD=YOUR_PASSWORD;TrustServerCertificate=yes;',
};

document.querySelectorAll('[data-sql-template]').forEach(button => {
  button.addEventListener('click', () => {
    const input = document.getElementById('fSqlConnString');
    const template = sqlConnectionTemplates[button.dataset.sqlTemplate];
    if (!input || !template) return;
    input.value = template;
    input.focus();
  });
});
document.querySelectorAll('[data-sql-popup-template]').forEach(button => {
  button.addEventListener('click', () => {
    const input = document.getElementById('sqlConnInput');
    const template = sqlConnectionTemplates[button.dataset.sqlPopupTemplate];
    if (!input || !template) return;
    input.value = template;
    input.focus();
  });
});
document.getElementById('sqlConnCloseBtn')?.addEventListener('click', closeSqlConnectionPrompt);
document.getElementById('sqlConnCancelBtn')?.addEventListener('click', closeSqlConnectionPrompt);
document.getElementById('sqlConnBackdrop')?.addEventListener('click', closeSqlConnectionPrompt);
document.getElementById('sqlConnSaveBtn')?.addEventListener('click', async event => {
  const btn = event.currentTarget;
  const input = document.getElementById('sqlConnInput');
  const conn = input.value.trim();
  if (!sqlConnPromptServerId || !conn) {
    showToast({
      id: `sql-conn-missing:${Date.now()}`,
      type: 'failed',
      title: 'Connection required',
      message: 'Enter a SQL connection string before saving.',
    });
    return;
  }
  btn.disabled = true;
  btn.textContent = 'Saving...';
  try {
    const res = await fetch(`/api/servers/${sqlConnPromptServerId}/sql_conn_string`, {
      method: 'POST',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql_conn_string: conn }),
    });
    if (!res.ok) throw new Error(parseApiError(await res.text()));
    if (!runtimeFlags.enableSqlOps) {
      await fetch('/api/settings/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: 'ENABLE_SQL_OPS', enabled: true }),
      });
    }
    closeSqlConnectionPrompt();
    showToast({
      id: `sql-conn-saved:${Date.now()}`,
      type: 'success',
      title: 'SQL connection saved',
      message: 'Next scan can run the fresh backup preflight before old backup cleanup.',
    });
    await refreshStatus();
  } catch (error) {
    showToast({
      id: `sql-conn-failed:${Date.now()}`,
      type: 'failed',
      title: 'Could not save connection',
      message: error.message || 'SQL connection update failed.',
    });
  } finally {
    btn.disabled = false;
    btn.textContent = 'Save connection';
  }
});

document.getElementById('closeActionModalBtn').addEventListener('click', closeActionModal);
document.getElementById('actionModalBackdrop').addEventListener('click', closeActionModal);
document.getElementById('aiPanelToggle')?.addEventListener('click', () => {
  document.getElementById('aiPanel')?.classList.toggle('open');
  renderAiChat();
});
document.getElementById('aiPanelClose')?.addEventListener('click', () => {
  document.getElementById('aiPanel')?.classList.remove('open');
});
document.getElementById('aiPromptGrid')?.addEventListener('click', event => {
  const btn = event.target.closest('[data-ai-prompt]');
  if (!btn) return;
  sendAiPrompt(btn.dataset.aiPrompt);
});
document.getElementById('aiChatForm')?.addEventListener('submit', event => {
  event.preventDefault();
  const input = document.getElementById('aiChatInput');
  sendAiPrompt(input?.value || '');
  if (input) input.value = '';
});
document.getElementById('opslogExpandBtn')?.addEventListener('click', () => {
  if (opslogLevel <= 0) {
    setOpslogState('raised');
  } else {
    setOpslogState('expanded');
  }
});
document.getElementById('opslogCollapseBtn')?.addEventListener('click', () => {
  if (opslogLevel >= 2) {
    setOpslogState('raised');
  } else {
    setOpslogState('collapsed');
  }
});
document.addEventListener('click', async event => {
  const cleanupBtn = event.target.closest('[data-start-backup-cleanup]');
  if (cleanupBtn) {
    event.stopPropagation();
    await startBackupCleanup(cleanupBtn.dataset.startBackupCleanup, cleanupBtn);
    return;
  }

  const sqlToggle = event.target.closest('[data-sql-connection-toggle]');
  if (sqlToggle) {
    event.stopPropagation();
    await toggleSqlConnection(
      sqlToggle.dataset.sqlConnectionToggle,
      sqlToggle.dataset.connected === 'true',
      sqlToggle,
    );
    return;
  }

  const btn = event.target.closest('.automation-toggle');
  if (!btn) return;
  const enabled = btn.dataset.enabled === 'true';
  const setting = btn.dataset.setting;
  if (!enabled && setting === 'ENABLE_FILE_DELETE') {
    const ok = confirm('Enable automatic file cleanup? Protected folders are still blocked, but eligible files can be deleted.');
    if (!ok) return;
  }
  btn.disabled = true;
  btn.textContent = enabled ? 'Disabling...' : 'Enabling...';
  try {
    const res = await fetch('/api/settings/toggle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: setting, enabled: !enabled }),
    });
    if (!res.ok) throw new Error(parseApiError(await res.text()));
    showToast({
      id: `setting:${setting}:${Date.now()}`,
      type: 'success',
      title: 'Guardrail updated',
      message: `${setting} is now ${enabled ? 'disabled' : 'enabled'}.`,
    });
    await refreshStatus();
  } catch (error) {
    showToast({
      id: `setting-failed:${setting}:${Date.now()}`,
      type: 'failed',
      title: 'Guardrail update failed',
      message: error.message || `Could not update ${setting}.`,
    });
  } finally {
    btn.disabled = false;
  }
});
document.getElementById('modalRemoveBtn').addEventListener('click', async () => {
  if (selectedActionMountPoint) {
    await removeMonitoring(selectedActionMountPoint);
  }
});
document.getElementById('modalScanBtn').addEventListener('click', async event => {
  const btn = event.currentTarget;
  btn.textContent = 'Scanning...';
  btn.disabled = true;
  await fetch('/api/scan_now', { method: 'POST', cache: 'no-store' });
  closeActionModal();
  await Promise.all([refreshStatus({ forceToasts: true }), refreshLog()]);
  btn.textContent = 'Scan now';
  btn.disabled = false;
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    closeActionModal();
    document.getElementById('aiPanel')?.classList.remove('open');
  }
});

function addMpRow() {
  const node = mpRowTemplate.content.cloneNode(true);
  const row = node.querySelector('.mp-row');
  row.querySelector('.mp-remove').addEventListener('click', () => row.remove());
  mpRowsEl.appendChild(node);
}
document.getElementById('addMpRowBtn').addEventListener('click', addMpRow);
addMpRow(); // start with one row

let savingServer = false;
document.getElementById('saveServerBtn').addEventListener('click', async () => {
  if (savingServer) return;
  const saveBtn = document.getElementById('saveServerBtn');
  const name = document.getElementById('fServerName').value.trim();
  const host = document.getElementById('fServerHost').value.trim();
  const sql_conn_string = document.getElementById('fSqlConnString').value.trim();
  const description = document.getElementById('fServerDesc').value.trim();
  if (!name || !host) { alert('Server name and host are required.'); return; }

  const mount_points = [...mpRowsEl.querySelectorAll('.mp-row')].map(row => ({
    label: row.querySelector('.mp-label').value.trim(),
    path: row.querySelector('.mp-path').value.trim(),
    folder_type: row.querySelector('.mp-type').value,
    threshold_pct: parseInt(row.querySelector('.mp-threshold').value, 10) || DEFAULT_CRITICAL_PCT,
  })).filter(mp => mp.label && mp.path);

  savingServer = true;
  saveBtn.disabled = true;
  saveBtn.textContent = 'Saving...';
  try {
    const res = await fetch('/api/servers', {
      method: 'POST',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, host, description, sql_conn_string, mount_points }),
    });
    if (!res.ok) throw new Error(await res.text());

    closeDrawer();
    document.getElementById('fServerName').value = '';
    document.getElementById('fServerHost').value = '';
    document.getElementById('fSqlConnString').value = '';
    document.getElementById('fServerDesc').value = '';
    mpRowsEl.innerHTML = '';
    addMpRow();
    saveBtn.textContent = 'Save server';
    await Promise.all([refreshStatus(), refreshLog()]);
  } catch (err) {
    showToast({
      id: `save-server-failed:${Date.now()}`,
      type: 'failed',
      title: 'Mount point validation failed',
      message: err.message || 'Could not save server.',
    });
  } finally {
    savingServer = false;
    saveBtn.disabled = false;
    if (!drawer.classList.contains('open')) {
      saveBtn.textContent = 'Save server';
    }
  }
});

/* ---------------------------------------------------------- */
/* Scan now + polling loop                                     */
/* ---------------------------------------------------------- */
document.getElementById('scanNowBtn').addEventListener('click', async () => {
  const btn = document.getElementById('scanNowBtn');
  btn.textContent = 'Scanning...';
  btn.disabled = true;
  await fetch('/api/scan_now', { method: 'POST', cache: 'no-store' });
  await Promise.all([refreshStatus({ forceToasts: true }), refreshLog()]);
  btn.textContent = 'Scan now';
  btn.disabled = false;
});

refreshStatus();
refreshLog();
setInterval(refreshStatus, 15000);
setInterval(refreshLog, 8000);
