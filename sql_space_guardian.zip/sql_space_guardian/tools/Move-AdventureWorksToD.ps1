#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

$dbName = 'AdventureWorks2022'
$logicalData = 'AdventureWorks2022'
$logicalLog = 'AdventureWorks2022_log'
$sourceData = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\AdventureWorks2022.mdf'
$sourceLog = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\AdventureWorks2022_log.ldf'
$destData = 'D:\data_mp\AdventureWorks2022.mdf'
$destLog = 'D:\log_mp\AdventureWorks2022_log.ldf'
$backupDir = 'D:\sqlbackups_mp'
$backupFile = Join-Path $backupDir ("AdventureWorks2022_pre_move_{0}.bak" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$serviceAcl = 'NT SERVICE\MSSQL$SQLEXPRESS:(OI)(CI)F'
$connString = 'DRIVER={ODBC Driver 18 for SQL Server};SERVER=.\SQLEXPRESS;DATABASE=master;Trusted_Connection=yes;TrustServerCertificate=yes;Encrypt=no;'

function Invoke-SqlBatch {
    param([Parameter(Mandatory = $true)][string]$Sql)

    $env:SQL_CONN_STRING = $connString
    $env:SQL_BATCH = $Sql
    @'
import os
import pyodbc

conn = pyodbc.connect(os.environ["SQL_CONN_STRING"], timeout=10, autocommit=True)
cur = conn.cursor()
cur.execute(os.environ["SQL_BATCH"])
while cur.nextset():
    pass
'@ | python -
    if ($LASTEXITCODE -ne 0) {
        throw "SQL batch failed."
    }
}

function Restore-OriginalState {
    Write-Warning "Trying to restore AdventureWorks2022 to original C: paths."
    if ((Test-Path -LiteralPath $destData) -and !(Test-Path -LiteralPath $sourceData)) {
        Move-Item -LiteralPath $destData -Destination $sourceData
    }
    if ((Test-Path -LiteralPath $destLog) -and !(Test-Path -LiteralPath $sourceLog)) {
        Move-Item -LiteralPath $destLog -Destination $sourceLog
    }

    Invoke-SqlBatch @"
ALTER DATABASE [$dbName]
MODIFY FILE (NAME = N'$logicalData', FILENAME = N'$sourceData');
ALTER DATABASE [$dbName]
MODIFY FILE (NAME = N'$logicalLog', FILENAME = N'$sourceLog');
ALTER DATABASE [$dbName] SET ONLINE;
"@
}

try {
    foreach ($path in @($sourceData, $sourceLog)) {
        if (!(Test-Path -LiteralPath $path)) { throw "Source file missing: $path" }
    }
    foreach ($path in @($destData, $destLog)) {
        if (Test-Path -LiteralPath $path) { throw "Destination already exists: $path" }
    }
    foreach ($dir in @('D:\data_mp', 'D:\log_mp', $backupDir)) {
        if (!(Test-Path -LiteralPath $dir)) { throw "Required folder missing: $dir" }
        icacls $dir /grant $serviceAcl | Out-Null
    }

    Invoke-SqlBatch @"
IF DB_ID(N'$dbName') IS NULL THROW 50001, 'AdventureWorks2022 not found.', 1;
IF (SELECT state_desc FROM sys.databases WHERE name = N'$dbName') <> 'ONLINE'
    THROW 50002, 'AdventureWorks2022 must be ONLINE before starting.', 1;

ALTER DATABASE [$dbName]
MODIFY FILE (NAME = N'$logicalData', FILENAME = N'$destData');
ALTER DATABASE [$dbName]
MODIFY FILE (NAME = N'$logicalLog', FILENAME = N'$destLog');

BACKUP DATABASE [$dbName]
TO DISK = N'$backupFile'
WITH INIT, CHECKSUM, STATS = 10;

RESTORE VERIFYONLY
FROM DISK = N'$backupFile'
WITH CHECKSUM;

ALTER DATABASE [$dbName] SET OFFLINE WITH ROLLBACK IMMEDIATE;
"@

    Move-Item -LiteralPath $sourceData -Destination $destData
    Move-Item -LiteralPath $sourceLog -Destination $destLog

    Invoke-SqlBatch "ALTER DATABASE [$dbName] SET ONLINE;"

    $env:SQL_CONN_STRING = $connString
    @'
import os
import pyodbc

conn = pyodbc.connect(os.environ["SQL_CONN_STRING"], timeout=10, autocommit=True)
cur = conn.cursor()
cur.execute("""
SELECT name, physical_name, state_desc
FROM sys.master_files
WHERE database_id = DB_ID('AdventureWorks2022')
ORDER BY type_desc;
""")
for row in cur.fetchall():
    print(f"{row[0]} | {row[1]} | {row[2]}")
cur.execute("SELECT state_desc FROM sys.databases WHERE name = 'AdventureWorks2022'")
print("DATABASE_STATE=" + cur.fetchone()[0])
'@ | python -

    Write-Host "Move complete."
    Write-Host "Backup file: $backupFile"
} catch {
    Write-Error $_
    try {
        Restore-OriginalState
    } catch {
        Write-Error "Automatic recovery failed. Check SQL Server state before retrying: $_"
    }
    exit 1
}
