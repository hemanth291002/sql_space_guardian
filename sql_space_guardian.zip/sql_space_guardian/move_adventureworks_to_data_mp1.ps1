$ErrorActionPreference = "Stop"

$server = ".\SQLEXPRESS"
$database = "AdventureWorks2022"
$targetDir = "D:\data_mp1"
$targetMdf = Join-Path $targetDir "AdventureWorks2022.mdf"

function Run-Sql($query) {
    sqlcmd -S $server -E -b -Q $query
}

if (-not (Test-Path -LiteralPath $targetDir)) {
    New-Item -ItemType Directory -Path $targetDir | Out-Null
}

icacls $targetDir /grant "NT SERVICE\MSSQL`$SQLEXPRESS:(OI)(CI)F" | Out-Host

$metadataQuery = @"
SET NOCOUNT ON;
SELECT name + '|' + physical_name
FROM sys.master_files
WHERE database_id = DB_ID(N'$database')
  AND type_desc = 'ROWS';
"@

$metadata = sqlcmd -S $server -E -h -1 -W -Q $metadataQuery
$row = ($metadata | Where-Object { $_ -match "\|" } | Select-Object -First 1)

if (-not $row) {
    throw "Could not find ROWS/MDF metadata for database [$database]."
}

$parts = $row -split "\|", 2
$logicalDataName = $parts[0].Trim()
$sourceMdf = $parts[1].Trim()

Write-Host "Database: $database"
Write-Host "Logical data file: $logicalDataName"
Write-Host "Current MDF: $sourceMdf"
Write-Host "Target MDF: $targetMdf"

if (-not (Test-Path -LiteralPath $sourceMdf)) {
    throw "Source MDF not found: $sourceMdf"
}

if ((Resolve-Path -LiteralPath $sourceMdf).Path -ieq (Resolve-Path -LiteralPath $targetMdf -ErrorAction SilentlyContinue).Path) {
    Write-Host "MDF is already at target path. Verifying SQL metadata only."
} else {
    $alterQuery = @"
ALTER DATABASE [$database]
MODIFY FILE (NAME = N'$logicalDataName', FILENAME = N'$targetMdf');
ALTER DATABASE [$database] SET OFFLINE WITH ROLLBACK IMMEDIATE;
"@

    Run-Sql $alterQuery

    Move-Item -LiteralPath $sourceMdf -Destination $targetMdf

    Run-Sql "ALTER DATABASE [$database] SET ONLINE;"
}

Run-Sql @"
SELECT
    DB_NAME(database_id) AS database_name,
    name AS logical_name,
    type_desc,
    physical_name
FROM sys.master_files
WHERE database_id = DB_ID(N'$database');
"@

