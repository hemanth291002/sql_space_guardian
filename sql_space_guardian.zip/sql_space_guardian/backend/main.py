import os
import datetime as dt
from typing import Dict, List, Optional

from fastapi import FastAPI, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import init_db, get_db, SessionLocal
from models import Server, MountPoint, ScanResult, ActionLog, FolderType
import schemas
import actions
import predictor
import ai_client
import scheduler as sched
import sql_diagnostics
import scanner
from config import settings

FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend")

app = FastAPI(title=settings.APP_NAME)


class SettingToggle(BaseModel):
    key: str
    enabled: bool


class SqlConnectionUpdate(BaseModel):
    sql_conn_string: str


def _persist_env_bool(updates: Dict[str, bool]) -> None:
    env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env")
    existing = []
    if os.path.exists(env_path):
        with open(env_path, "r", encoding="utf-8") as fh:
            existing = fh.read().splitlines()

    update_text = {key: f"{key}={'true' if value else 'false'}" for key, value in updates.items()}
    seen = set()
    next_lines = []
    for line in existing:
        stripped = line.strip()
        matched_key = None
        for key in update_text:
            if stripped.startswith(f"{key}="):
                matched_key = key
                break
        if matched_key:
            next_lines.append(update_text[matched_key])
            seen.add(matched_key)
        else:
            next_lines.append(line)

    for key, line in update_text.items():
        if key not in seen:
            next_lines.append(line)

    with open(env_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(next_lines).rstrip() + "\n")


def _ensure_mount_point_path(path: str) -> None:
    ok, message = scanner.validate_mount_point_path(path)
    if not ok:
        raise HTTPException(400, message)


def _infer_folder_type(label: str, path: str, selected_type: str) -> str:
    selected = (selected_type or FolderType.GENERAL.value).strip().lower()
    if selected and selected != FolderType.GENERAL.value:
        return selected

    text = f"{label or ''} {path or ''}".lower().replace("-", "_").replace(" ", "_")
    if "sqlbackup_mp2" in text or "sqlbackups_mp2" in text:
        return FolderType.SQLBACKUP_MP2.value
    if "testbackups_mp" in text or "sqltest_backups" in text:
        return FolderType.TESTBACKUPS_MP.value
    if "systembackups_mp" in text:
        return FolderType.SYSTEMBACKUPS_MP.value
    if "sqlbackups_mp" in text or "sqlbackup_mp" in text:
        return FolderType.SQLBACKUPS_MP.value
    if "tempdb_mp" in text:
        return FolderType.TEMPDB_MP.value
    if "log_mp" in text:
        return FolderType.LOG_MP.value
    if "data_mp" in text:
        return FolderType.DATA_MP.value
    return selected or FolderType.GENERAL.value


def _normalize_mount_point_folder_types() -> None:
    db = SessionLocal()
    try:
        changed = False
        for mp in db.query(MountPoint).all():
            inferred = _infer_folder_type(mp.label, mp.path, mp.folder_type.value if hasattr(mp.folder_type, "value") else mp.folder_type)
            current = mp.folder_type.value if hasattr(mp.folder_type, "value") else mp.folder_type
            if current == FolderType.GENERAL.value and inferred != current:
                mp.folder_type = inferred
                changed = True
        if changed:
            db.commit()
    finally:
        db.close()


@app.middleware("http")
async def no_cache_api_responses(request, call_next):
    response = await call_next(request)
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


@app.on_event("startup")
def on_startup():
    init_db()
    _normalize_mount_point_folder_types()
    sched.start_scheduler()


# ---------------------------------------------------------------- servers --
@app.get("/api/servers", response_model=List[schemas.ServerOut])
def list_servers(db: Session = Depends(get_db)):
    return db.query(Server).all()


@app.post("/api/servers", response_model=schemas.ServerOut)
def create_server(payload: schemas.ServerCreate, db: Session = Depends(get_db)):
    name = payload.name.strip()
    host = payload.host.strip()
    if not name or not host:
        raise HTTPException(400, "Server name and host are required")

    server = (
        db.query(Server)
        .filter(Server.name.ilike(name))
        .first()
    )
    if server:
        if host and host != server.host:
            server.host = server.host or host
        if payload.description and payload.description != server.description:
            server.description = payload.description
        if payload.sql_conn_string and payload.sql_conn_string != server.sql_conn_string:
            server.sql_conn_string = payload.sql_conn_string
    else:
        server = Server(
            name=name, host=host,
            description=payload.description.strip(),
            sql_conn_string=payload.sql_conn_string.strip(),
        )
        db.add(server)
        db.flush()

    existing_paths = {
        (mp.path or "").strip().lower()
        for mp in db.query(MountPoint).filter(MountPoint.server_id == server.id).all()
    }
    existing_labels = {
        (mp.label or "").strip().lower()
        for mp in db.query(MountPoint).filter(MountPoint.server_id == server.id).all()
    }
    for mp in payload.mount_points:
        label = mp.label.strip()
        path = mp.path.strip()
        if not label or not path:
            continue
        _ensure_mount_point_path(path)
        path_key = path.lower()
        label_key = label.lower()
        if path_key in existing_paths or label_key in existing_labels:
            continue
        db.add(MountPoint(
            server_id=server.id, label=label, path=path,
            folder_type=_infer_folder_type(label, path, mp.folder_type), threshold_pct=mp.threshold_pct,
            paired_relief_mount_id=mp.paired_relief_mount_id,
        ))
        existing_paths.add(path_key)
        existing_labels.add(label_key)
    db.commit()
    db.refresh(server)
    return server


@app.delete("/api/servers/{server_id}")
def delete_server(server_id: int, db: Session = Depends(get_db)):
    server = db.query(Server).get(server_id)
    if not server:
        raise HTTPException(404, "Server not found")
    db.delete(server)
    db.commit()
    return {"ok": True}


@app.post("/api/servers/{server_id}/sql_conn_string")
def update_server_sql_connection(server_id: int, payload: SqlConnectionUpdate, db: Session = Depends(get_db)):
    server = db.query(Server).get(server_id)
    if not server:
        raise HTTPException(404, "Server not found")
    conn = payload.sql_conn_string.strip()
    if not conn:
        raise HTTPException(400, "SQL connection string is required.")
    server.sql_conn_string = conn
    db.commit()
    return {"ok": True, "server_id": server_id}


@app.delete("/api/servers/{server_id}/sql_conn_string")
def clear_server_sql_connection(server_id: int, db: Session = Depends(get_db)):
    server = db.query(Server).get(server_id)
    if not server:
        raise HTTPException(404, "Server not found")
    server.sql_conn_string = ""
    db.commit()
    return {"ok": True, "server_id": server_id}


# ------------------------------------------------------------ mount points --
@app.post("/api/servers/{server_id}/mount_points", response_model=schemas.MountPointOut)
def add_mount_point(server_id: int, payload: schemas.MountPointCreate, db: Session = Depends(get_db)):
    server = db.query(Server).get(server_id)
    if not server:
        raise HTTPException(404, "Server not found")
    label = payload.label.strip()
    path = payload.path.strip()
    _ensure_mount_point_path(path)
    existing = (
        db.query(MountPoint)
        .filter(MountPoint.server_id == server_id)
        .filter(
            (MountPoint.path.ilike(path)) | (MountPoint.label.ilike(label))
        )
        .first()
    )
    if existing:
        return existing
    mp = MountPoint(
        server_id=server_id, label=label, path=path,
        folder_type=_infer_folder_type(label, path, payload.folder_type), threshold_pct=payload.threshold_pct,
        paired_relief_mount_id=payload.paired_relief_mount_id,
    )
    db.add(mp)
    db.commit()
    db.refresh(mp)
    return mp


@app.delete("/api/mount_points/{mp_id}")
def delete_mount_point(mp_id: int, db: Session = Depends(get_db)):
    mp = db.query(MountPoint).get(mp_id)
    if not mp:
        raise HTTPException(404, "Mount point not found")
    db.query(MountPoint).filter(MountPoint.paired_relief_mount_id == mp_id).update(
        {MountPoint.paired_relief_mount_id: None},
        synchronize_session=False,
    )
    db.query(ActionLog).filter(ActionLog.mount_point_id == mp_id).update(
        {ActionLog.mount_point_id: None},
        synchronize_session=False,
    )
    db.delete(mp)
    db.commit()
    return {"ok": True}


@app.post("/api/mount_points/{mp_id}/mark_restore_complete")
def mark_restore_complete(mp_id: int, db: Session = Depends(get_db)):
    mp = db.query(MountPoint).get(mp_id)
    if not mp:
        raise HTTPException(404, "Mount point not found")
    mp.restore_marked_complete_at = dt.datetime.utcnow()
    db.commit()
    return {"ok": True}


@app.post("/api/mount_points/{mp_id}/start_backup_cleanup")
def start_backup_cleanup(mp_id: int, db: Session = Depends(get_db)):
    mp = db.query(MountPoint).get(mp_id)
    if not mp:
        raise HTTPException(404, "Mount point not found")
    try:
        result = actions.execute_prod_backup_cleanup(db, mp)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    if not result.get("ok"):
        raise HTTPException(400, result.get("message", "Backup cleanup could not start."))
    return result


# ------------------------------------------------------------------ status --
@app.get("/api/status")
def full_status(db: Session = Depends(get_db)):
    servers = db.query(Server).all()
    out = []
    for server in servers:
        latest_diag = (
            db.query(sql_diagnostics.SqlDiagnosticSnapshot)
            .filter(sql_diagnostics.SqlDiagnosticSnapshot.server_id == server.id)
            .order_by(sql_diagnostics.SqlDiagnosticSnapshot.checked_at.desc())
            .first()
        )
        mp_out = []
        for mp in server.mount_points:
            history = (
                db.query(ScanResult)
                .filter(ScanResult.mount_point_id == mp.id)
                .order_by(ScanResult.scanned_at.desc())
                .limit(60)
                .all()
            )
            history.reverse()
            latest = history[-1] if history else None
            if latest and latest.total_gb:
                history = [
                    h for h in history
                    if h.total_gb and abs(h.total_gb - latest.total_gb) / latest.total_gb <= 0.05
                ]
            fc = predictor.forecast([(h.scanned_at, h.used_gb, h.total_gb) for h in history]) \
                if history else {}
            recent_actions = (
                db.query(ActionLog)
                .filter(ActionLog.mount_point_id == mp.id)
                .order_by(ActionLog.created_at.desc())
                .limit(8)
                .all()
            )
            mp_out.append({
                "mount_point": schemas.MountPointOut.model_validate(mp).model_dump(),
                "latest": schemas.ScanResultOut.model_validate(latest).model_dump() if latest else None,
                "history": [schemas.ScanResultOut.model_validate(h).model_dump() for h in history],
                "forecast": fc,
                "recent_actions": [
                    schemas.ActionLogOut.model_validate(row).model_dump()
                    for row in recent_actions
                ],
            })
        out.append({
            "server": {
                **schemas.ServerOut.model_validate(server).model_dump(exclude={"mount_points"}),
                "has_sql_conn_string": bool((server.sql_conn_string or "").strip()),
            },
            "sql_diagnostics": sql_diagnostics.snapshot_to_dict(latest_diag),
            "mount_points": mp_out,
        })
    return {
        "servers": out,
        "demo_mode": settings.DEMO_MODE,
        "ai_configured": ai_client.is_configured(),
        "last_run_at": sched.last_run_at(),
        "scan_interval_minutes": settings.SCAN_INTERVAL_MINUTES,
        "scan_interval_seconds": settings.SCAN_INTERVAL_SECONDS,
        "enable_file_delete": settings.ENABLE_FILE_DELETE,
        "enable_sql_log_shrink": settings.ENABLE_SQL_LOG_SHRINK,
        "enable_sql_data_file_move": settings.ENABLE_SQL_DATA_FILE_MOVE,
        "enable_sql_ops": settings.ENABLE_SQL_OPS,
    }


@app.post("/api/settings/toggle")
def toggle_setting(payload: SettingToggle):
    allowed = {
        "ENABLE_FILE_DELETE": "ENABLE_FILE_DELETE",
        "ENABLE_SQL_LOG_SHRINK": "ENABLE_SQL_LOG_SHRINK",
        "ENABLE_SQL_DATA_FILE_MOVE": "ENABLE_SQL_DATA_FILE_MOVE",
        "ENABLE_SQL_OPS": "ENABLE_SQL_OPS",
    }
    attr = allowed.get(payload.key)
    if not attr:
        raise HTTPException(400, "This setting cannot be toggled from the dashboard.")

    updates = {payload.key: payload.enabled}
    setattr(settings, attr, payload.enabled)

    if payload.enabled and payload.key in {"ENABLE_SQL_LOG_SHRINK", "ENABLE_SQL_DATA_FILE_MOVE"}:
        settings.ENABLE_SQL_OPS = True
        updates["ENABLE_SQL_OPS"] = True

    _persist_env_bool(updates)
    return {
        "ok": True,
        "key": payload.key,
        "enabled": payload.enabled,
        "enable_sql_ops": settings.ENABLE_SQL_OPS,
    }


@app.get("/api/actions", response_model=List[schemas.ActionLogOut])
def get_actions(
    limit: int = 100,
    mount_point_id: Optional[int] = None,
    db: Session = Depends(get_db),
):
    q = db.query(ActionLog)
    if mount_point_id is not None:
        q = q.filter(ActionLog.mount_point_id == mount_point_id)
    return q.order_by(ActionLog.created_at.desc()).limit(limit).all()


@app.post("/api/scan_now")
def scan_now():
    sched.run_full_scan_cycle()
    return {"ok": True}


@app.get("/api/folder_types")
def folder_types():
    return [ft.value for ft in FolderType]


# --------------------------------------------------------------- frontend --
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")


@app.get("/")
def index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))
