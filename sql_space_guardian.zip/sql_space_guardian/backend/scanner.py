"""
Everything that touches the filesystem lives here, and only here.
Real mode: uses shutil.disk_usage() and os.walk() straight against the path
you configure (e.g. \\\\p07983\\f$\\SQLBackups_MP once the jumpbox can see it).
Demo mode: fabricates believable, slowly-drifting numbers per mount point so
the whole app is fully clickable before it's pointed at real infrastructure.
"""
import os
import shutil
import hashlib
import random
import datetime as dt
import re
import ctypes
from dataclasses import dataclass
from typing import List, Set

from config import settings


@dataclass
class DiskUsage:
    total_gb: float
    used_gb: float
    free_gb: float
    used_pct: float


@dataclass
class OldFile:
    path: str
    size_gb: float
    modified_at: dt.datetime


def _normalize_protection_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.lower())


def _protected_markers(exclude_marker: str = "") -> Set[str]:
    markers = {
        marker.lower()
        for marker in [exclude_marker, *getattr(settings, "EXCLUDE_FOLDER_MARKERS", [])]
        if marker
    }
    normalized = {_normalize_protection_name(marker) for marker in markers}
    normalized.update({
        "donotdelete",
        "donnotdelete",
        "donotdelte",
        "dontdelete",
        "donotremove",
        "donnotremove",
    })
    return normalized


def _delete_after_date(value: str):
    """Return a date if the folder name carries a delete-after/until date."""
    candidates = [
        r"(20\d{2})[-_\.]?(0[1-9]|1[0-2])[-_\.]?([0-2]\d|3[01])",
        r"([0-2]\d|3[01])[-_\.](0[1-9]|1[0-2])[-_\.](20\d{2})",
    ]
    for pattern in candidates:
        match = re.search(pattern, value)
        if not match:
            continue
        parts = match.groups()
        try:
            if len(parts[0]) == 4:
                return dt.date(int(parts[0]), int(parts[1]), int(parts[2]))
            return dt.date(int(parts[2]), int(parts[1]), int(parts[0]))
        except ValueError:
            continue
    return None


def is_path_protected(path: str, exclude_marker: str = "") -> bool:
    """True when any folder in the path says do/don't/donnot delete.

    If a protected folder includes a date, it is protected until that date.
    """
    markers = _protected_markers(exclude_marker)
    parts = [p for p in re.split(r"[\\/]+", path) if p]
    for part in parts:
        compact = _normalize_protection_name(part)
        if not any(marker and marker in compact for marker in markers):
            continue
        release_date = _delete_after_date(part)
        if release_date is None:
            return True
        if dt.datetime.utcnow().date() < release_date:
            return True
    return False


def _seed_for(path: str) -> int:
    return int(hashlib.md5(path.encode()).hexdigest()[:8], 16)


def _is_unc_share_root(path: str) -> bool:
    normalized = path.strip().replace("/", "\\").rstrip("\\")
    if not normalized.startswith("\\\\"):
        return False
    parts = [part for part in normalized[2:].split("\\") if part]
    return len(parts) == 2


def _is_drive_root(path: str) -> bool:
    drive, rest = os.path.splitdrive(path.strip())
    return bool(drive) and rest in ("\\", "/")


def _is_windows_volume_mount_point(path: str) -> bool:
    if os.name != "nt":
        return False
    normalized = os.path.abspath(path)
    if not normalized.endswith("\\"):
        normalized += "\\"
    volume_name = ctypes.create_unicode_buffer(1024)
    return bool(
        ctypes.windll.kernel32.GetVolumeNameForVolumeMountPointW(
            ctypes.c_wchar_p(normalized),
            volume_name,
            len(volume_name),
        )
    )


def validate_mount_point_path(path: str):
    """Return (ok, message) after checking that path is monitorable.

    Accepted:
    - Drive roots such as D:\
    - UNC share roots such as \\server\share
    - Windows volume-mounted folders
    - DBA-standard mount folders such as D:\data_mp, D:\data_mp1, D:\sqlbackups_mp
    Rejected:
    - Normal subfolders that do not look like DBA mount folders
    """
    candidate = (path or "").strip()
    if not candidate:
        return False, "Mount point path is required."
    if not os.path.exists(candidate):
        return False, f"{candidate} is not reachable from this machine."
    if _is_unc_share_root(candidate) or _is_drive_root(candidate):
        return True, "ok"
    if os.path.ismount(candidate) or _is_windows_volume_mount_point(candidate):
        return True, "ok"
    folder_name = os.path.basename(os.path.normpath(candidate)).lower()
    if re.search(r"(^|[_-])mp\d*$", folder_name):
        return True, "ok"
    return (
        False,
        f"{candidate} is a normal folder, not a mount point folder. Use a drive root, UNC share root, "
        "Windows mounted volume, or a DBA-standard folder ending with _mp, _mp1, _mp2, etc.",
    )


def get_disk_usage(path: str, mount_point_id: int) -> DiskUsage:
    if not settings.DEMO_MODE:
        try:
            total, used, free = shutil.disk_usage(path)
            total_gb = total / (1024 ** 3)
            used_gb = used / (1024 ** 3)
            free_gb = free / (1024 ** 3)
            used_pct = (used_gb / total_gb) * 100 if total_gb else 0
            return DiskUsage(
                round(total_gb, 4),
                round(used_gb, 4),
                round(free_gb, 4),
                round(used_pct, 2),
            )
        except OSError:
            # Path unreachable (share down, no permissions, VPN off, etc).
            # Fall through to demo data so the dashboard still renders,
            # the caller logs this as a FAILED action.
            raise

    # ---- DEMO MODE: deterministic-but-drifting simulated usage ----
    rnd = random.Random(_seed_for(path) + int(dt.datetime.utcnow().strftime("%Y%m%d")))
    total_gb = 500 + (_seed_for(path) % 6) * 250  # 500GB - 1.75TB, stable per mount
    hour_of_day = dt.datetime.utcnow().hour
    # backups tend to land overnight -> usage creeps up then gets partly reclaimed
    day_index = dt.datetime.utcnow().toordinal()
    drift = ((_seed_for(path) % 37) + day_index) % 40  # 0-39 slow sawtooth
    base_pct = 45 + drift + (3 if hour_of_day < 6 else 0) + rnd.uniform(-2, 2)
    used_pct = max(5, min(97, base_pct))
    used_gb = total_gb * used_pct / 100
    free_gb = total_gb - used_gb
    return DiskUsage(round(total_gb, 1), round(used_gb, 1), round(free_gb, 1), round(used_pct, 2))


def find_old_files(
    path: str,
    older_than_days: int,
    exclude_marker: str,
    mount_point_id: int = 0,
    limit: int = 200,
) -> List[OldFile]:
    """Returns files older than N days, skipping any folder whose name/path
    contains a protected marker (e.g. 'do_not_delete'), case-insensitive."""
    cutoff = dt.datetime.utcnow() - dt.timedelta(days=older_than_days)
    results: List[OldFile] = []
    if not settings.DEMO_MODE:
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if not is_path_protected(d, exclude_marker)]
            if is_path_protected(root, exclude_marker):
                continue
            for f in files:
                full = os.path.join(root, f)
                try:
                    stat = os.stat(full)
                except OSError:
                    continue
                mtime = dt.datetime.fromtimestamp(stat.st_mtime)
                if mtime < cutoff:
                    results.append(OldFile(full, stat.st_size / (1024 ** 3), mtime))
                if len(results) >= limit:
                    return results
        return results

    # ---- DEMO MODE: fabricate a plausible list of aging backup files ----
    rnd = random.Random(_seed_for(path))
    count = rnd.randint(6, 18)
    for i in range(count):
        age_days = rnd.randint(older_than_days, older_than_days + 40)
        size_gb = round(rnd.uniform(2, 45), 2)
        fname = f"{['FULL','DIFF','LOG'][i % 3]}_backup_{(dt.date.today() - dt.timedelta(days=age_days)).isoformat()}.bak"
        results.append(
            OldFile(
                os.path.join(path, fname),
                size_gb,
                dt.datetime.utcnow() - dt.timedelta(days=age_days),
            )
        )
    return results
