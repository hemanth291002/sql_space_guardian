import enum
import datetime as dt

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Enum, Text
)
from sqlalchemy.orm import relationship

from database import Base


class FolderType(str, enum.Enum):
    GENERAL = "general"
    DATA_MP = "data_mp"                  # user database .mdf/.ndf files
    LOG_MP = "log_mp"                    # user database .ldf files
    TEMPDB_MP = "tempdb_mp"              # tempdb data/log files
    SQLBACKUPS_MP = "sqlbackups_mp"      # production/user DB backups -> alert + suggest space
    SQLBACKUP_MP2 = "sqlbackup_mp2"      # relief drive -> AI silently rebalances into here
    TESTBACKUPS_MP = "testbackups_mp"    # restore/testing backups -> auto cleanup
    SYSTEMBACKUPS_MP = "systembackups_mp"  # master/model/msdb backups -> alert + suggest space
    SQLTEST_BACKUPS = "sqltest_backups"  # legacy alias for testbackups_mp
    LOG_DRIVE = "log_drive"              # legacy alias for log_mp


class ActionStatus(str, enum.Enum):
    INFO = "info"
    SUCCESS = "success"
    ALERT = "alert"
    FAILED = "failed"


class Server(Base):
    __tablename__ = "servers"

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)               # friendly name, e.g. SQLPROD01
    host = Column(String, nullable=False)                # e.g. p07983 (jumpbox share host)
    description = Column(String, default="")
    sql_conn_string = Column(String, default="")         # optional, only if ENABLE_SQL_OPS
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    mount_points = relationship(
        "MountPoint", back_populates="server", cascade="all, delete-orphan"
    )
    diagnostic_snapshots = relationship(
        "SqlDiagnosticSnapshot", back_populates="server", cascade="all, delete-orphan"
    )


class MountPoint(Base):
    __tablename__ = "mount_points"

    id = Column(Integer, primary_key=True)
    server_id = Column(Integer, ForeignKey("servers.id"), nullable=False)
    label = Column(String, nullable=False)               # e.g. "SQLBackups_MP (F:)"
    path = Column(String, nullable=False)                # e.g. \\p07983\f$\SQLBackups_MP
    folder_type = Column(Enum(FolderType), default=FolderType.GENERAL)
    threshold_pct = Column(Integer, default=80)
    paired_relief_mount_id = Column(Integer, ForeignKey("mount_points.id"), nullable=True)
    restore_marked_complete_at = Column(DateTime, nullable=True)  # for sqltest_backups
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    server = relationship("Server", back_populates="mount_points")
    scans = relationship(
        "ScanResult", back_populates="mount_point", cascade="all, delete-orphan"
    )


class ScanResult(Base):
    __tablename__ = "scan_results"

    id = Column(Integer, primary_key=True)
    mount_point_id = Column(Integer, ForeignKey("mount_points.id"), nullable=False)
    total_gb = Column(Float)
    used_gb = Column(Float)
    free_gb = Column(Float)
    used_pct = Column(Float)
    scanned_at = Column(DateTime, default=dt.datetime.utcnow)

    mount_point = relationship("MountPoint", back_populates="scans")


class ActionLog(Base):
    __tablename__ = "action_log"

    id = Column(Integer, primary_key=True)
    server_id = Column(Integer, ForeignKey("servers.id"), nullable=True)
    mount_point_id = Column(Integer, ForeignKey("mount_points.id"), nullable=True)
    action_type = Column(String, nullable=False)   # e.g. SPACE_ALERT, AI_REBALANCE, SHRINK_LOG
    status = Column(Enum(ActionStatus), default=ActionStatus.INFO)
    message = Column(Text, nullable=False)
    created_at = Column(DateTime, default=dt.datetime.utcnow)


class SqlDiagnosticSnapshot(Base):
    __tablename__ = "sql_diagnostic_snapshots"

    id = Column(Integer, primary_key=True)
    server_id = Column(Integer, ForeignKey("servers.id"), nullable=False)
    status = Column(String, default="not_configured")  # ok, not_configured, failed
    connection_ok = Column(Boolean, default=False)
    scheduled_jobs = Column(Integer, default=0)
    running_jobs = Column(Integer, default=0)
    active_requests = Column(Integer, default=0)
    active_transactions = Column(Integer, default=0)
    log_reuse_waits = Column(Integer, default=0)
    summary = Column(Text, default="")
    details_json = Column(Text, default="{}")
    checked_at = Column(DateTime, default=dt.datetime.utcnow)

    server = relationship("Server", back_populates="diagnostic_snapshots")
