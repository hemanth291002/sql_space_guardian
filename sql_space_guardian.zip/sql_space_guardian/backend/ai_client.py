"""
Thin wrapper around any OpenAI-compatible /chat/completions endpoint, so
whatever free API key gets dropped into .env later (OpenAI, Groq, an
Anthropic-compatible gateway, etc.) just works by setting AI_API_BASE /
AI_API_KEY / AI_MODEL. Until a key is configured, every call falls back to a
clear, deterministic, rule-based explanation so the app is never blocked
waiting on AI.
"""
import requests
from config import settings


def is_configured() -> bool:
    return bool(settings.AI_API_KEY)


def ask_ai(prompt: str, fallback: str) -> str:
    if not is_configured():
        return fallback
    try:
        resp = requests.post(
            f"{settings.AI_API_BASE.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {settings.AI_API_KEY}"},
            json={
                "model": settings.AI_MODEL,
                "messages": [
                    {
                        "role": "system",
                        "content": (
                            "You are a senior DBA assistant writing short, precise, "
                            "no-nonsense operational summaries for a DBA team. "
                            "Be concrete with numbers. No fluff."
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
                "max_tokens": 400,
                "temperature": 0.2,
            },
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:  # noqa: BLE001 - never let AI errors break monitoring
        return f"{fallback}\n\n(AI summary unavailable: {e})"


def explain_space_alert(mount_label: str, used_pct: float, growth_gb_day: float,
                         days_to_threshold, recommended_add_gb, forecast_reliable: bool = True,
                         forecast_note: str = "") -> str:
    if not forecast_reliable:
        fallback = (
            f"{mount_label} is at {used_pct:.1f}% used. Growth projection is not reliable yet: "
            f"{forecast_note or 'not enough scan history is available.'} "
            "Do not provision storage from this trend alone; review current usage and collect more scans."
        )
        prompt = (
            f"Mount point '{mount_label}' is at {used_pct:.1f}% used capacity. "
            f"Forecast is NOT reliable: {forecast_note}. "
            "Write a 2-3 sentence DBA alert. Do not recommend additional storage based on growth. "
            "Say that current usage needs review and more scan history is required before sizing capacity."
        )
        return ask_ai(prompt, fallback)

    fallback = (
        f"{mount_label} is at {used_pct:.1f}% used, growing ~{growth_gb_day:.1f} GB/day. "
        f"At this rate it reaches threshold in "
        f"{'unknown' if days_to_threshold is None else str(days_to_threshold) + ' day(s)'}. "
        f"Recommend adding "
        f"{'no extra space right now' if not recommended_add_gb else f'{recommended_add_gb} GB'} "
        f"to keep {settings.FORECAST_BUFFER_DAYS} days of safe runway including daily backups."
    )
    prompt = (
        f"Mount point '{mount_label}' is at {used_pct:.1f}% used capacity. "
        f"Growth rate is about {growth_gb_day:.1f} GB/day. "
        f"Estimated days until it crosses the alert threshold: {days_to_threshold}. "
        f"Recommended additional storage to add: {recommended_add_gb} GB. "
        "Write a 3-4 sentence email body for the DBA team explaining the situation "
        "and requesting the storage be provisioned, including the numbers above."
    )
    return ask_ai(prompt, fallback)


def explain_rebalance(source_label: str, dest_label: str, moved_gb: float,
                       source_pct_after: float, dest_pct_after: float) -> str:
    fallback = (
        f"Moved {moved_gb:.1f} GB of older backup files from {source_label} to "
        f"{dest_label} (spare capacity available). Projected usage after move: "
        f"{source_label} {source_pct_after:.1f}%, {dest_label} {dest_pct_after:.1f}%. "
        "No alert was needed since capacity was rebalanced automatically."
    )
    prompt = (
        f"We auto-moved {moved_gb:.1f} GB of backup files from '{source_label}' "
        f"(over threshold) to '{dest_label}' (had spare capacity), because it was "
        f"worth it and no manual action was required. Resulting usage: "
        f"{source_label}={source_pct_after:.1f}%, {dest_label}={dest_pct_after:.1f}%. "
        "Write a 2-3 sentence log note (not an alert) documenting this for the DBA team."
    )
    return ask_ai(prompt, fallback)
