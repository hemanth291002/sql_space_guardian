"""
Optional, off-by-default module for the log-drive shrink workflow:
  1. try DBCC SHRINKFILE
  2. if that fails (usually because the log can't shrink past pending VLFs),
     run BACKUP LOG first, then retry the shrink
Requires pyodbc + an ODBC Driver for SQL Server, and ENABLE_SQL_OPS=true
with a real `sql_conn_string` on the Server row. Everything is guarded so the
rest of the app runs fine without any of this installed/configured.
"""
import datetime as dt
import os
import re
import shutil
import subprocess

from config import settings


def _get_pyodbc():
    import pyodbc  # imported lazily so it's not a hard dependency
    return pyodbc


def shrink_log_with_fallback(conn_string: str, database_name: str, logical_log_name: str,
                              target_mb: int = 1024, log_backup_path: str = None) -> dict:
    if not settings.ENABLE_SQL_OPS:
        return {
            "attempted": False,
            "note": "ENABLE_SQL_OPS is off -- shrink not attempted (dry run).",
        }
    try:
        pyodbc = _get_pyodbc()
    except ImportError:
        return {"attempted": False, "note": "pyodbc not installed."}

    try:
        conn = pyodbc.connect(conn_string, autocommit=True, timeout=10)
        cur = conn.cursor()
        cur.execute(f"USE [{database_name}]")

        def try_shrink():
            cur.execute(f"DBCC SHRINKFILE (N'{logical_log_name}', {target_mb})")
            return cur.fetchall()

        try:
            try_shrink()
            return {"attempted": True, "success": True, "note": "Shrink succeeded on first try."}
        except Exception as first_err:  # noqa: BLE001
            if log_backup_path:
                backup_file = f"{log_backup_path}\\{database_name}_LOG_{{ts}}.trn"
                cur.execute(
                    f"BACKUP LOG [{database_name}] TO DISK = N'{backup_file}'"
                )
            try_shrink()
            return {
                "attempted": True,
                "success": True,
                "note": f"First shrink failed ({first_err}); took a log backup then shrink succeeded.",
            }
    except Exception as e:  # noqa: BLE001
        return {"attempted": True, "success": False, "note": f"Shrink workflow failed: {e}"}


def shrink_largest_log_on_mount(conn_string: str, log_mount_path: str,
                                target_mb: int = None, log_backup_path: str = "") -> dict:
    """Shrink the largest user database log file physically located on a log mount.

    The workflow is deliberately defensive:
    - discover the database/logical log from sys.master_files instead of guessing
    - hold if active transactions exist for that database
    - hold on log reuse waits unless a log backup path is configured
    - send the caller a detailed note for action history/email
    """
    if not settings.ENABLE_SQL_OPS:
        return {"attempted": False, "success": False, "note": "ENABLE_SQL_OPS is off."}
    if not settings.ENABLE_SQL_LOG_SHRINK:
        return {"attempted": False, "success": False, "note": "ENABLE_SQL_LOG_SHRINK is off."}
    if not conn_string:
        return {"attempted": False, "success": False, "note": "No SQL connection string configured."}

    target_mb = target_mb or settings.LOG_SHRINK_TARGET_MB
    log_backup_path = log_backup_path or settings.LOG_BACKUP_PATH

    try:
        pyodbc = _get_pyodbc()
    except ImportError:
        return {"attempted": False, "success": False, "note": "pyodbc not installed."}

    try:
        conn = pyodbc.connect(conn_string, autocommit=True, timeout=20)
        cur = conn.cursor()
        cur.execute("""
            SELECT
                DB_NAME(database_id) AS database_name,
                database_id,
                name AS logical_name,
                physical_name,
                size * 8.0 / 1024 AS size_mb
            FROM sys.master_files
            WHERE type_desc = 'LOG'
              AND database_id > 4
            ORDER BY size DESC;
        """)
        candidates = []
        for row in cur.fetchall():
            physical_name = row.physical_name
            if _same_or_child_path(physical_name, log_mount_path):
                candidates.append({
                    "database_name": row.database_name,
                    "database_id": int(row.database_id),
                    "logical_name": row.logical_name,
                    "physical_name": physical_name,
                    "size_mb": float(row.size_mb or 0),
                })

        if not candidates:
            return {
                "attempted": False,
                "success": False,
                "note": f"No user database log files found under {log_mount_path}.",
            }

        choice = candidates[0]
        db_name = choice["database_name"]
        db_name_sql = _sql_literal(db_name)
        logical_name_sql = _sql_literal(choice["logical_name"])

        cur.execute("""
            SELECT COUNT(*)
            FROM sys.dm_tran_database_transactions
            WHERE database_id = ?
        """, choice["database_id"])
        active_tx = int(cur.fetchone()[0] or 0)
        if active_tx:
            return {
                "attempted": False,
                "success": False,
                "database_name": db_name,
                "logical_name": choice["logical_name"],
                "note": (
                    f"Held log shrink for {db_name}: {active_tx} active transaction(s) exist. "
                    "Shrinking now may not release space and can add pressure."
                ),
            }

        cur.execute("""
            SELECT state_desc, user_access_desc, is_read_only, recovery_model_desc, log_reuse_wait_desc
            FROM sys.databases
            WHERE name = ?
        """, db_name)
        state_desc, user_access, is_read_only, recovery_model, reuse_wait = cur.fetchone()
        if state_desc != "ONLINE" or is_read_only:
            return {
                "attempted": False,
                "success": False,
                "database_name": db_name,
                "logical_name": choice["logical_name"],
                "note": (
                    f"Held log shrink for {db_name}: database state={state_desc}, "
                    f"user_access={user_access}, read_only={bool(is_read_only)}."
                ),
            }

        active_ops = _query(cur, f"""
            SELECT command, status, percent_complete
            FROM sys.dm_exec_requests
            WHERE database_id = DB_ID(N'{db_name_sql}')
              AND session_id <> @@SPID
              AND (
                    command LIKE 'BACKUP%'
                 OR command LIKE 'RESTORE%'
                 OR command LIKE 'DBCC%'
                 OR percent_complete > 0
              );
        """, [], "active database operations")
        if active_ops:
            return {
                "attempted": False,
                "success": False,
                "database_name": db_name,
                "logical_name": choice["logical_name"],
                "note": f"Held log shrink for {db_name}: backup/restore/DBCC operation is active.",
            }

        try:
            cur.execute(f"USE [{db_name_sql}]")
            cur.execute("SELECT COUNT(*) FROM sys.database_files")
            cur.fetchone()
        except Exception as db_health_err:  # noqa: BLE001
            return {
                "attempted": False,
                "success": False,
                "database_name": db_name,
                "logical_name": choice["logical_name"],
                "note": (
                    f"Held log shrink for {db_name}: database files/log are not available for "
                    f"a safe shrink preflight. SQL error: {db_health_err}"
                ),
            }

        reuse_wait = reuse_wait or "UNKNOWN"

        backup_note = ""
        if reuse_wait not in ("NOTHING", "CHECKPOINT"):
            if recovery_model == "FULL" and log_backup_path:
                os.makedirs(log_backup_path, exist_ok=True)
                backup_file = os.path.join(
                    log_backup_path,
                    f"{db_name}_LOG_{dt.datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.trn",
                )
                _grant_sql_service_access(log_backup_path)
                cur.execute(f"BACKUP LOG [{db_name_sql}] TO DISK = N'{_sql_literal(backup_file)}'")
                backup_note = f" Took log backup to {backup_file} because reuse wait was {reuse_wait}."
            else:
                return {
                    "attempted": False,
                    "success": False,
                    "database_name": db_name,
                    "logical_name": choice["logical_name"],
                    "note": (
                        f"Held log shrink for {db_name}: log_reuse_wait_desc={reuse_wait}. "
                        "Configure LOG_BACKUP_PATH for FULL recovery log backup fallback, or resolve the wait first."
                    ),
                }

        cur.execute(f"DBCC SHRINKFILE (N'{logical_name_sql}', {int(target_mb)})")
        rows = cur.fetchall() if cur.description else []
        return {
            "attempted": True,
            "success": True,
            "database_name": db_name,
            "logical_name": choice["logical_name"],
            "physical_name": choice["physical_name"],
            "size_mb_before": round(choice["size_mb"], 2),
            "target_mb": int(target_mb),
            "note": (
                f"Shrank {db_name}/{choice['logical_name']} from ~{choice['size_mb']:.0f} MB "
                f"toward {int(target_mb)} MB. Recovery={recovery_model}, reuse_wait={reuse_wait}."
                f"{backup_note}"
            ),
        }
    except Exception as e:  # noqa: BLE001
        return {"attempted": True, "success": False, "note": f"Log shrink workflow failed: {e}"}


def _json_safe(value):
    if isinstance(value, (dt.datetime, dt.date)):
        return value.isoformat()
    return value


def _rows_as_dicts(cursor):
    cols = [col[0] for col in cursor.description or []]
    return [
        {cols[i]: _json_safe(row[i]) for i in range(len(cols))}
        for row in cursor.fetchall()
    ]


def _query(cursor, sql: str, errors: list, label: str):
    try:
        cursor.execute(sql)
        return _rows_as_dicts(cursor)
    except Exception as e:  # noqa: BLE001 - diagnostics should degrade gracefully
        errors.append(f"{label}: {e}")
        return []


def _sql_literal(value: str) -> str:
    return (value or "").replace("'", "''")


def _sql_identifier(value: str) -> str:
    return (value or "").replace("]", "]]")


def _same_or_child_path(path: str, root: str) -> bool:
    try:
        path_abs = os.path.abspath(path)
        root_abs = os.path.abspath(root)
        return os.path.commonpath([path_abs, root_abs]).lower() == root_abs.lower()
    except ValueError:
        return False


def _grant_sql_service_access(path: str) -> str:
    """Grant SQL Server service access to a directory or file on Windows."""
    if os.name != "nt":
        return "ACL grant skipped; not running on Windows."
    account = settings.SQL_SERVICE_ACCOUNT
    grant = f"{account}:(OI)(CI)F" if os.path.isdir(path) else f"{account}:F"
    result = subprocess.run(
        ["icacls", path, "/grant", grant],
        capture_output=True,
        text=True,
        check=False,
    )
    output = (result.stdout or result.stderr or "").strip()
    if result.returncode != 0:
        raise RuntimeError(f"Could not grant SQL Server access to {path}: {output}")
    return output or f"Granted {account} access to {path}."


def backup_user_databases_for_cleanup(conn_string: str, backup_root: str) -> dict:
    """Take fresh compressed full + differential backups before old backup cleanup.

    This is deliberately all-or-nothing for cleanup safety: if any backup fails,
    callers must not delete old production backups.
    """
    if not settings.ENABLE_SQL_OPS:
        return {"attempted": False, "success": False, "note": "ENABLE_SQL_OPS is off."}
    if not settings.ENABLE_SQL_BACKUP_BEFORE_CLEANUP:
        return {
            "attempted": False,
            "success": False,
            "note": "ENABLE_SQL_BACKUP_BEFORE_CLEANUP is off; old production backups held.",
        }
    if not conn_string:
        return {"attempted": False, "success": False, "note": "No SQL connection string configured."}

    try:
        pyodbc = _get_pyodbc()
    except ImportError:
        return {"attempted": False, "success": False, "note": "pyodbc is not installed."}

    try:
        os.makedirs(backup_root, exist_ok=True)
        acl_note = _grant_sql_service_access(backup_root)
        pyodbc = _get_pyodbc()
        conn = pyodbc.connect(conn_string, autocommit=True, timeout=30)
        cur = conn.cursor()
        cur.execute("""
            SELECT name
            FROM sys.databases
            WHERE database_id > 4
              AND state_desc = 'ONLINE'
              AND is_read_only = 0
              AND source_database_id IS NULL
            ORDER BY name;
        """)
        databases = [row.name for row in cur.fetchall()]
        if not databases:
            return {
                "attempted": True,
                "success": False,
                "note": "No online writable user databases found for fresh backup.",
            }

        ts = dt.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        created = []
        options = ["INIT", "CHECKSUM", "STATS = 10"]
        if settings.SQL_BACKUP_COMPRESSION:
            options.insert(2, "COMPRESSION")
        option_sql = ", ".join(options)

        for db_name in databases:
            db_ident = _sql_identifier(db_name)
            safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", db_name)
            full_file = os.path.join(backup_root, f"{safe_name}_FULL_{ts}.bak")
            diff_file = os.path.join(backup_root, f"{safe_name}_DIFF_{ts}.bak")
            cur.execute(
                f"BACKUP DATABASE [{db_ident}] TO DISK = N'{_sql_literal(full_file)}' "
                f"WITH {option_sql}"
            )
            cur.execute(
                f"BACKUP DATABASE [{db_ident}] TO DISK = N'{_sql_literal(diff_file)}' "
                f"WITH DIFFERENTIAL, {option_sql}"
            )
            created.extend([full_file, diff_file])

        return {
            "attempted": True,
            "success": True,
            "database_count": len(databases),
            "files": created,
            "note": (
                f"Fresh compressed full and differential backups completed for {len(databases)} "
                f"user database(s). Created {len(created)} file(s). {acl_note}"
            ),
        }
    except Exception as e:  # noqa: BLE001
        return {
            "attempted": True,
            "success": False,
            "note": f"Fresh backup workflow failed; old production backups were held. SQL error: {e}",
        }


def plan_data_file_relocation(conn_string: str, source_root: str, target_root: str,
                              target_free_to_threshold_gb: float) -> dict:
    """Find the largest SQL ROWS data file under source_root that fits target.

    This is read-only. It returns the SQL/PowerShell steps so the dashboard can
    explain the AI choice even when automatic SQL file movement is disabled.
    """
    if not conn_string:
        return {"ok": False, "note": "No SQL connection string configured for this server."}
    try:
        pyodbc = _get_pyodbc()
    except ImportError:
        return {"ok": False, "note": "pyodbc is not installed."}

    try:
        conn = pyodbc.connect(conn_string, autocommit=True, timeout=10)
        cur = conn.cursor()
        cur.execute("""
            SELECT
                DB_NAME(database_id) AS database_name,
                name AS logical_name,
                physical_name,
                size * 8.0 / 1024 / 1024 AS size_gb
            FROM sys.master_files
            WHERE type_desc = 'ROWS'
              AND database_id > 4
            ORDER BY size DESC;
        """)
        candidates = []
        for row in cur.fetchall():
            physical_name = row.physical_name
            size_gb = float(row.size_gb or 0)
            if not _same_or_child_path(physical_name, source_root):
                continue
            if size_gb > target_free_to_threshold_gb:
                continue
            target_path = os.path.join(target_root, os.path.basename(physical_name))
            candidates.append({
                "database_name": row.database_name,
                "logical_name": row.logical_name,
                "source_path": physical_name,
                "target_path": target_path,
                "size_gb": size_gb,
            })

        if not candidates:
            return {
                "ok": False,
                "note": (
                    "No movable user data file under the source mount fits the target mount's "
                    "safe free space."
                ),
            }

        choice = candidates[0]
        db_name = _sql_literal(choice["database_name"])
        logical_name = _sql_literal(choice["logical_name"])
        target_path = _sql_literal(choice["target_path"])
        source_path = choice["source_path"]
        script = (
            f"icacls \"{target_root}\" /grant \"{settings.SQL_SERVICE_ACCOUNT}:(OI)(CI)F\"\n"
            f"ALTER DATABASE [{choice['database_name']}] MODIFY FILE "
            f"(NAME = N'{logical_name}', FILENAME = N'{target_path}');\n"
            f"ALTER DATABASE [{choice['database_name']}] SET OFFLINE WITH ROLLBACK IMMEDIATE;\n"
            f"Move-Item \"{source_path}\" \"{choice['target_path']}\"\n"
            f"icacls \"{choice['target_path']}\" /grant \"{settings.SQL_SERVICE_ACCOUNT}:F\"\n"
            f"ALTER DATABASE [{choice['database_name']}] SET ONLINE;"
        )
        return {"ok": True, "choice": choice, "script": script}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "note": f"SQL data-file planning failed: {e}"}


def relocate_data_file(conn_string: str, choice: dict) -> dict:
    """Disruptive SQL data-file move. Requires explicit enablement.

    Sequence: update metadata, offline DB, move file, online DB. This should be
    used only in a maintenance window because it disconnects users.
    """
    if not settings.ENABLE_SQL_OPS:
        return {"success": False, "note": "ENABLE_SQL_OPS is off."}
    if not settings.ENABLE_SQL_DATA_FILE_MOVE:
        return {"success": False, "note": "ENABLE_SQL_DATA_FILE_MOVE is off."}

    try:
        pyodbc = _get_pyodbc()
        db_name = choice["database_name"]
        logical_name = _sql_literal(choice["logical_name"])
        source_path = choice["source_path"]
        target_path = choice["target_path"]
        if not os.path.exists(source_path):
            return {"success": False, "note": f"Source file does not exist: {source_path}"}
        if os.path.exists(target_path):
            return {"success": False, "note": f"Target file already exists, refusing overwrite: {target_path}"}
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        acl_notes = [_grant_sql_service_access(os.path.dirname(target_path))]

        conn = pyodbc.connect(conn_string, autocommit=True, timeout=20)
        cur = conn.cursor()
        offline_started = False
        cur.execute(
            f"ALTER DATABASE [{db_name}] MODIFY FILE "
            f"(NAME = N'{logical_name}', FILENAME = N'{_sql_literal(target_path)}')"
        )
        try:
            cur.execute(f"ALTER DATABASE [{db_name}] SET OFFLINE WITH ROLLBACK IMMEDIATE")
            offline_started = True
            shutil.move(source_path, target_path)
            acl_notes.append(_grant_sql_service_access(target_path))
            try:
                cur.execute(f"ALTER DATABASE [{db_name}] SET ONLINE")
            except Exception as online_err:  # noqa: BLE001
                acl_notes.append(_grant_sql_service_access(os.path.dirname(target_path)))
                acl_notes.append(_grant_sql_service_access(target_path))
                try:
                    cur.execute(f"ALTER DATABASE [{db_name}] SET ONLINE")
                except Exception as retry_err:  # noqa: BLE001
                    raise RuntimeError(
                        f"SET ONLINE failed after ACL retry. First error: {online_err}; "
                        f"retry error: {retry_err}"
                    ) from retry_err
        except Exception:
            if offline_started:
                try:
                    cur.execute(f"ALTER DATABASE [{db_name}] SET ONLINE")
                except Exception:
                    pass
            raise
        return {
            "success": True,
            "note": (
                f"Moved {db_name}/{choice['logical_name']} to {target_path}. "
                f"Permission steps: {' | '.join(acl_notes)}"
            ),
        }
    except Exception as e:  # noqa: BLE001
        return {"success": False, "note": f"SQL data-file move failed: {e}"}


def collect_sql_diagnostics(conn_string: str) -> dict:
    """Read-only SQL Server diagnostics for background monitoring.

    This checks whether SQL Agent jobs are scheduled/running, whether backup or
    restore commands are in progress, whether long transactions/log reuse waits
    may hold log space, and current log-space usage. It never performs cleanup,
    backup, restore, shrink, or any write operation.
    """
    if not conn_string:
        return {
            "status": "not_configured",
            "connection_ok": False,
            "message": "SQL diagnostics not configured. Add a SQL connection string on the server.",
            "running_jobs": [],
            "next_jobs": [],
            "active_requests": [],
            "active_transactions": [],
            "log_reuse_waits": [],
            "log_space": [],
            "errors": [],
        }

    try:
        pyodbc = _get_pyodbc()
    except ImportError:
        return {
            "status": "failed",
            "connection_ok": False,
            "message": "pyodbc is not installed, so SQL diagnostics cannot connect yet.",
            "running_jobs": [],
            "next_jobs": [],
            "active_requests": [],
            "active_transactions": [],
            "log_reuse_waits": [],
            "log_space": [],
            "errors": ["Install pyodbc and the Microsoft ODBC Driver for SQL Server."],
        }

    errors = []
    try:
        conn = pyodbc.connect(conn_string, autocommit=True, timeout=10)
        cur = conn.cursor()

        running_jobs = _query(cur, """
            SELECT TOP 20
                j.name,
                ja.start_execution_date,
                DATEDIFF(MINUTE, ja.start_execution_date, GETDATE()) AS duration_min
            FROM msdb.dbo.sysjobactivity AS ja
            INNER JOIN msdb.dbo.sysjobs AS j ON ja.job_id = j.job_id
            WHERE ja.session_id = (SELECT MAX(session_id) FROM msdb.dbo.syssessions)
              AND ja.start_execution_date IS NOT NULL
              AND ja.stop_execution_date IS NULL
            ORDER BY ja.start_execution_date;
        """, errors, "running SQL Agent jobs")

        next_jobs = _query(cur, """
            SELECT TOP 20
                j.name,
                msdb.dbo.agent_datetime(js.next_run_date, js.next_run_time) AS next_run_at
            FROM msdb.dbo.sysjobschedules AS js
            INNER JOIN msdb.dbo.sysjobs AS j ON js.job_id = j.job_id
            WHERE j.enabled = 1
              AND js.next_run_date > 0
            ORDER BY next_run_at;
        """, errors, "scheduled SQL Agent jobs")

        active_requests = _query(cur, """
            SELECT
                DB_NAME(database_id) AS database_name,
                command,
                status,
                percent_complete,
                start_time,
                estimated_completion_time / 60000 AS estimated_completion_min,
                wait_type
            FROM sys.dm_exec_requests
            WHERE session_id <> @@SPID
              AND (
                    command LIKE 'BACKUP%'
                 OR command LIKE 'RESTORE%'
                 OR command LIKE 'DBCC%'
                 OR percent_complete > 0
              )
            ORDER BY start_time;
        """, errors, "backup/restore/DBCC requests")

        active_transactions = _query(cur, """
            SELECT
                DB_NAME(dt.database_id) AS database_name,
                COUNT(*) AS active_transactions,
                MIN(at.transaction_begin_time) AS oldest_begin_time,
                DATEDIFF(MINUTE, MIN(at.transaction_begin_time), GETDATE()) AS oldest_age_min
            FROM sys.dm_tran_database_transactions AS dt
            INNER JOIN sys.dm_tran_active_transactions AS at
                ON dt.transaction_id = at.transaction_id
            WHERE at.transaction_begin_time IS NOT NULL
            GROUP BY dt.database_id
            HAVING COUNT(*) > 0
            ORDER BY oldest_age_min DESC;
        """, errors, "active transactions")

        log_reuse_waits = _query(cur, """
            SELECT
                name AS database_name,
                log_reuse_wait_desc
            FROM sys.databases
            WHERE log_reuse_wait_desc <> 'NOTHING'
            ORDER BY name;
        """, errors, "log reuse waits")

        log_space = _query(cur, "DBCC SQLPERF(LOGSPACE);", errors, "log space")

        message = (
            f"{len(next_jobs)} scheduled job(s), {len(running_jobs)} running job(s), "
            f"{len(active_requests)} backup/restore/DBCC request(s), "
            f"{sum(int(r.get('active_transactions') or 0) for r in active_transactions)} active transaction(s), "
            f"{len(log_reuse_waits)} log reuse wait(s)."
        )
        if errors:
            message += f" Some checks were skipped: {len(errors)} error(s)."

        return {
            "status": "ok",
            "connection_ok": True,
            "message": message,
            "running_jobs": running_jobs,
            "next_jobs": next_jobs,
            "active_requests": active_requests,
            "active_transactions": active_transactions,
            "log_reuse_waits": log_reuse_waits,
            "log_space": log_space,
            "errors": errors,
        }
    except Exception as e:  # noqa: BLE001
        return {
            "status": "failed",
            "connection_ok": False,
            "message": f"SQL diagnostics connection failed: {e}",
            "running_jobs": [],
            "next_jobs": [],
            "active_requests": [],
            "active_transactions": [],
            "log_reuse_waits": [],
            "log_space": [],
            "errors": [str(e)],
        }
