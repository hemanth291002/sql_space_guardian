"""
Lightweight trend forecasting -- no numpy dependency, just least-squares
over recent scan history. Good enough to answer "at this rate, when do we
hit the critical threshold?" and "how much space should we add to buy N days of runway?".
"""
import datetime as dt
from typing import List, Optional, Tuple

from config import settings


def _linreg(xs: List[float], ys: List[float]) -> Tuple[float, float]:
    """Return (slope, intercept) for y = slope*x + intercept."""
    n = len(xs)
    if n < 2:
        return 0.0, ys[0] if ys else 0.0
    mean_x = sum(xs) / n
    mean_y = sum(ys) / n
    num = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    den = sum((x - mean_x) ** 2 for x in xs) or 1e-9
    slope = num / den
    intercept = mean_y - slope * mean_x
    return slope, intercept


def forecast(history: List[Tuple[dt.datetime, float, float]]) -> dict:
    """
    history: list of (scanned_at, used_gb, total_gb), oldest first.
    Returns growth_gb_per_day, days_to_threshold, days_to_full, recommended_add_gb.
    """
    base = {
        "growth_gb_per_day": 0.0,
        "days_to_threshold": None,
        "days_to_full": None,
        "recommended_add_gb": None,
        "forecast_reliable": False,
        "forecast_note": "Need more scan history before projecting growth.",
        "history_span_hours": 0.0,
        "history_samples": len(history),
    }

    if len(history) < 2:
        return base

    span_hours = (history[-1][0] - history[0][0]).total_seconds() / 3600
    base["history_span_hours"] = round(max(span_hours, 0.0), 2)

    if len(history) < settings.FORECAST_MIN_SAMPLES:
        base["forecast_note"] = (
            f"Need at least {settings.FORECAST_MIN_SAMPLES} scan samples before projecting growth."
        )
        return base

    if span_hours < settings.FORECAST_MIN_SPAN_HOURS:
        base["forecast_note"] = (
            f"Need at least {settings.FORECAST_MIN_SPAN_HOURS} hours of scan history before "
            "projecting daily growth. Same-day changes are treated as current usage, not a trend."
        )
        return {
            **base,
            "history_span_hours": round(max(span_hours, 0.0), 2),
        }

    t0 = history[0][0]
    xs = [(h[0] - t0).total_seconds() / 86400 for h in history]  # days since first scan
    ys = [h[1] for h in history]  # used_gb
    slope, intercept = _linreg(xs, ys)  # gb per day

    total_gb = history[-1][2]
    latest_used = history[-1][1]
    latest_x = xs[-1]

    def days_until(target_gb: Optional[float]):
        if target_gb is None or slope <= 0.0001:
            return None
        # solve slope*x + intercept = target_gb for x, then subtract "now"
        x_target = (target_gb - intercept) / slope
        days_from_now = x_target - latest_x
        return round(days_from_now, 1) if days_from_now > 0 else 0.0

    threshold_gb = total_gb * settings.DEFAULT_THRESHOLD_PCT / 100
    days_to_threshold = days_until(threshold_gb) if latest_used < threshold_gb else 0.0
    days_to_full = days_until(total_gb)

    recommended_add_gb = None
    if slope > 0.0001:
        buffer_days = settings.FORECAST_BUFFER_DAYS
        # GB needed so that (current_free + added) lasts `buffer_days` at this growth
        # rate while staying under threshold the whole time, plus a 10% safety margin.
        current_free_to_threshold = max(threshold_gb - latest_used, 0)
        needed_for_buffer = slope * buffer_days
        shortfall = needed_for_buffer - current_free_to_threshold
        if shortfall > 0:
            recommended_add_gb = round(shortfall * 1.10, 1)

    return {
        "growth_gb_per_day": round(slope, 2),
        "days_to_threshold": days_to_threshold,
        "days_to_full": days_to_full,
        "recommended_add_gb": recommended_add_gb,
        "forecast_reliable": True,
        "forecast_note": "Projection based on enough scan history.",
        "history_span_hours": round(max(span_hours, 0.0), 2),
        "history_samples": len(history),
    }
