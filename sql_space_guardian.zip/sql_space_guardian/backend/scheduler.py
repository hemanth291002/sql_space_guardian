import datetime as dt
from apscheduler.schedulers.background import BackgroundScheduler

from database import SessionLocal
from models import Server, MountPoint, ActionLog, ActionStatus
import actions
import sql_diagnostics
from config import settings

_scheduler = BackgroundScheduler()
_last_run = {"at": None}


def run_full_scan_cycle():
    db = SessionLocal()
    try:
        servers = db.query(Server).all()
        for server in servers:
            try:
                sql_diagnostics.record_sql_diagnostics(db, server)
            except Exception as e:  # noqa: BLE001 - scan cycle must survive diagnostics failures
                db.add(ActionLog(
                    server_id=server.id, mount_point_id=None,
                    action_type="SQL_DIAGNOSTICS_FAILED",
                    status=ActionStatus.FAILED,
                    message=f"SQL diagnostics failed for {server.name}: {e}",
                ))
                db.commit()
            for mp in server.mount_points:
                try:
                    latest = actions.record_scan(db, mp)
                    actions.evaluate_mount_point(db, mp, latest)
                except Exception as e:  # noqa: BLE001 - one mount must not kill the API process
                    db.add(ActionLog(
                        server_id=server.id, mount_point_id=mp.id,
                        action_type="MOUNT_ACTION_FAILED",
                        status=ActionStatus.FAILED,
                        message=f"{mp.label} scan/action failed: {e}",
                    ))
                    db.commit()
        _last_run["at"] = dt.datetime.utcnow()
        db.add(ActionLog(
            server_id=None, mount_point_id=None, action_type="CYCLE",
            status=ActionStatus.INFO,
            message=f"Scan cycle complete across {len(servers)} server(s).",
        ))
        db.commit()
    finally:
        db.close()


def start_scheduler():
    if not _scheduler.running:
        _scheduler.add_job(
            run_full_scan_cycle,
            "interval",
            seconds=settings.SCAN_INTERVAL_SECONDS,
            next_run_time=dt.datetime.now() + dt.timedelta(seconds=settings.SCAN_INTERVAL_SECONDS),
            id="scan_cycle",
            replace_existing=True,
            max_instances=1,
            coalesce=True,
        )
        _scheduler.start()


def last_run_at():
    return _last_run["at"]
