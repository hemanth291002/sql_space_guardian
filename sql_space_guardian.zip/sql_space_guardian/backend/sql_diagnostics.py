import json

from sqlalchemy.orm import Session

import sql_ops
from models import Server, SqlDiagnosticSnapshot


def _count_active_transactions(rows):
    total = 0
    for row in rows:
        try:
            total += int(row.get("active_transactions") or 0)
        except (TypeError, ValueError):
            continue
    return total


def record_sql_diagnostics(db: Session, server: Server) -> SqlDiagnosticSnapshot:
    details = sql_ops.collect_sql_diagnostics(server.sql_conn_string)
    snapshot = SqlDiagnosticSnapshot(
        server_id=server.id,
        status=details.get("status", "failed"),
        connection_ok=bool(details.get("connection_ok")),
        scheduled_jobs=len(details.get("next_jobs", [])),
        running_jobs=len(details.get("running_jobs", [])),
        active_requests=len(details.get("active_requests", [])),
        active_transactions=_count_active_transactions(details.get("active_transactions", [])),
        log_reuse_waits=len(details.get("log_reuse_waits", [])),
        summary=details.get("message", ""),
        details_json=json.dumps(details, default=str),
    )
    db.add(snapshot)
    db.flush()

    old_ids = [
        row.id
        for row in (
            db.query(SqlDiagnosticSnapshot.id)
            .filter(SqlDiagnosticSnapshot.server_id == server.id)
            .order_by(SqlDiagnosticSnapshot.checked_at.desc())
            .offset(200)
            .all()
        )
    ]
    if old_ids:
        db.query(SqlDiagnosticSnapshot).filter(SqlDiagnosticSnapshot.id.in_(old_ids)).delete(
            synchronize_session=False
        )
    db.commit()
    db.refresh(snapshot)
    return snapshot


def snapshot_to_dict(snapshot: SqlDiagnosticSnapshot):
    if snapshot is None:
        return None
    try:
        details = json.loads(snapshot.details_json or "{}")
    except json.JSONDecodeError:
        details = {}
    details.update({
        "id": snapshot.id,
        "server_id": snapshot.server_id,
        "status": snapshot.status,
        "connection_ok": snapshot.connection_ok,
        "scheduled_jobs": snapshot.scheduled_jobs,
        "running_jobs_count": snapshot.running_jobs,
        "active_requests_count": snapshot.active_requests,
        "active_transactions_count": snapshot.active_transactions,
        "log_reuse_waits_count": snapshot.log_reuse_waits,
        "summary": snapshot.summary,
        "checked_at": snapshot.checked_at.isoformat() if snapshot.checked_at else None,
    })
    return details
