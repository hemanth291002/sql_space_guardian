"""
Central configuration for SQL Space Guardian.
Everything here is overridable via a .env file (see .env.example) so the
DBA team never has to touch code to point this at their real environment.
"""
import os
from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


class Settings:
    # ---- App ----
    APP_NAME = "SQL Space Guardian"
    DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")
    DB_PATH = os.path.join(DATA_DIR, "app.db")

    # If True, disk numbers are simulated instead of read from real paths.
    # Flip to False once the app runs on a box that can actually see the
    # \\server\share paths (the jumpbox). Nothing else changes.
    DEMO_MODE = _bool("DEMO_MODE", True)

    # ---- Scanning cadence ----
    SCAN_INTERVAL_SECONDS = _int("SCAN_INTERVAL_SECONDS", _int("SCAN_INTERVAL_MINUTES", 15) * 60)
    SCAN_INTERVAL_MINUTES = max(1, round(SCAN_INTERVAL_SECONDS / 60))

    # ---- Thresholds / business rules (all overridable per-mount-point too) ----
    DEFAULT_THRESHOLD_PCT = _int("DEFAULT_THRESHOLD_PCT", 80)
    OLD_FILE_DAYS = _int("OLD_FILE_DAYS", 5)
    EXCLUDE_FOLDER_MARKER = os.getenv("EXCLUDE_FOLDER_MARKER", "do_not_delete")
    EXCLUDE_FOLDER_MARKERS = [
        marker.strip().lower()
        for marker in os.getenv(
            "EXCLUDE_FOLDER_MARKERS",
            f"{EXCLUDE_FOLDER_MARKER},don_not_delete,donotdelete,donnotdelete,do-not-delete,do not delete",
        ).split(",")
        if marker.strip()
    ]
    TEST_RESTORE_RETENTION_DAYS = _int("TEST_RESTORE_RETENTION_DAYS", 3)
    FORECAST_BUFFER_DAYS = _int("FORECAST_BUFFER_DAYS", 30)
    FORECAST_MIN_SAMPLES = _int("FORECAST_MIN_SAMPLES", 4)
    FORECAST_MIN_SPAN_HOURS = _int("FORECAST_MIN_SPAN_HOURS", 24)
    MOVE_MIN_RELIEF_PCT = _int("MOVE_MIN_RELIEF_PCT", 5)  # min % drop to bother moving
    ACTION_LOG_COOLDOWN_SECONDS = _int("ACTION_LOG_COOLDOWN_SECONDS", 1800)
    ALERT_EMAIL_REPEAT_MINUTES = _int("ALERT_EMAIL_REPEAT_MINUTES", 40)
    ALERT_EMAIL_REPEAT_SECONDS = ALERT_EMAIL_REPEAT_MINUTES * 60
    BACKUP_CLEANUP_REMINDER_HOURS = _int("BACKUP_CLEANUP_REMINDER_HOURS", 6)
    BACKUP_CLEANUP_REMINDER_SECONDS = BACKUP_CLEANUP_REMINDER_HOURS * 60 * 60
    ENABLE_FILE_DELETE = _bool("ENABLE_FILE_DELETE", False)
    ENABLE_FILE_MOVE = _bool("ENABLE_FILE_MOVE", False)
    ENABLE_SQL_BACKUP_BEFORE_CLEANUP = _bool("ENABLE_SQL_BACKUP_BEFORE_CLEANUP", True)
    SQL_BACKUP_COMPRESSION = _bool("SQL_BACKUP_COMPRESSION", True)
    ENABLE_SQL_DATA_FILE_MOVE = _bool("ENABLE_SQL_DATA_FILE_MOVE", False)
    ENABLE_SQL_LOG_SHRINK = _bool("ENABLE_SQL_LOG_SHRINK", False)
    LOG_SHRINK_TARGET_MB = _int("LOG_SHRINK_TARGET_MB", 256)
    LOG_BACKUP_PATH = os.getenv("LOG_BACKUP_PATH", "")
    SQL_SERVICE_ACCOUNT = os.getenv("SQL_SERVICE_ACCOUNT", "NT SERVICE\\MSSQL$SQLEXPRESS")

    # ---- Email ----
    SMTP_HOST = os.getenv("SMTP_HOST", "")
    SMTP_PORT = _int("SMTP_PORT", 587)
    SMTP_USER = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    SMTP_USE_TLS = _bool("SMTP_USE_TLS", True)
    MAIL_FROM = os.getenv("MAIL_FROM", "sql-space-guardian@localhost")
    TEAM_EMAIL = os.getenv("TEAM_EMAIL", "")  # comma separated ok

    # ---- AI (bring-your-own free API key, OpenAI-compatible /chat/completions) ----
    AI_API_BASE = os.getenv("AI_API_BASE", "https://api.openai.com/v1")
    AI_API_KEY = os.getenv("AI_API_KEY", "")
    AI_MODEL = os.getenv("AI_MODEL", "gpt-4o-mini")

    # ---- Optional real SQL Server ops (DBCC SHRINKFILE / BACKUP LOG) ----
    # Requires pyodbc + ODBC driver installed. Off by default so the app
    # runs everywhere with zero extra setup.
    ENABLE_SQL_OPS = _bool("ENABLE_SQL_OPS", False)


settings = Settings()
os.makedirs(settings.DATA_DIR, exist_ok=True)
