import datetime as dt
from typing import Optional, List
from pydantic import BaseModel


class MountPointCreate(BaseModel):
    label: str
    path: str
    folder_type: str = "general"
    threshold_pct: int = 80
    paired_relief_mount_id: Optional[int] = None


class MountPointOut(BaseModel):
    id: int
    server_id: int
    label: str
    path: str
    folder_type: str
    threshold_pct: int
    paired_relief_mount_id: Optional[int] = None
    restore_marked_complete_at: Optional[dt.datetime] = None

    class Config:
        from_attributes = True


class ServerCreate(BaseModel):
    name: str
    host: str
    description: str = ""
    sql_conn_string: str = ""
    mount_points: List[MountPointCreate] = []


class ServerOut(BaseModel):
    id: int
    name: str
    host: str
    description: str
    created_at: dt.datetime
    mount_points: List[MountPointOut] = []

    class Config:
        from_attributes = True


class ScanResultOut(BaseModel):
    id: int
    mount_point_id: int
    total_gb: float
    used_gb: float
    free_gb: float
    used_pct: float
    scanned_at: dt.datetime

    class Config:
        from_attributes = True


class ActionLogOut(BaseModel):
    id: int
    server_id: Optional[int]
    mount_point_id: Optional[int]
    action_type: str
    status: str
    message: str
    created_at: dt.datetime

    class Config:
        from_attributes = True


class MountPointStatus(BaseModel):
    mount_point: MountPointOut
    latest: Optional[ScanResultOut]
    history: List[ScanResultOut]
    forecast_days_to_threshold: Optional[float] = None
    forecast_days_to_full: Optional[float] = None
    recommended_add_gb: Optional[float] = None
