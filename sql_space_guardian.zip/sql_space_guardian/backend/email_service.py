import smtplib
import ssl
import time
from email.mime.text import MIMEText
from typing import Tuple

from config import settings


def send_email(subject: str, body: str) -> Tuple[bool, str]:
    """Returns (sent_ok, note). If SMTP isn't configured yet, we don't fail
    the whole action -- we log that the email *would* be sent, so nothing
    upstream (shrink/move/etc.) gets blocked waiting on mail server setup."""
    if not settings.SMTP_HOST or not settings.TEAM_EMAIL:
        return False, "SMTP not configured yet -- email skipped (would have sent): " + subject

    msg = MIMEText(body, "html")
    msg["Subject"] = subject
    msg["From"] = settings.MAIL_FROM
    msg["To"] = settings.TEAM_EMAIL

    last_error = None
    for attempt in range(3):
        try:
            if settings.SMTP_USE_TLS:
                context = ssl.create_default_context()
                with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=20) as server:
                    server.starttls(context=context)
                    if settings.SMTP_USER:
                        server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
                    server.sendmail(settings.MAIL_FROM, settings.TEAM_EMAIL.split(","), msg.as_string())
            else:
                with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=20) as server:
                    if settings.SMTP_USER:
                        server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
                    server.sendmail(settings.MAIL_FROM, settings.TEAM_EMAIL.split(","), msg.as_string())
            return True, "Email sent to " + settings.TEAM_EMAIL
        except Exception as e:  # noqa: BLE001
            last_error = e
            if attempt < 2:
                time.sleep(2)
    return False, f"Email failed after 3 attempts: {last_error}"
