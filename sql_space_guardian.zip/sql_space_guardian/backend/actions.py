"""
The actual DBA rules, one function per folder type. Called by scheduler.py
on every scan cycle, and also re-runnable on demand from the API.
"""
import datetime as dt
import os
from sqlalchemy.orm import Session

import ai_client
import email_service
import scanner
import predictor
import sql_ops
from config import settings
from models import MountPoint, ScanResult, ActionLog, ActionStatus, FolderType


def _recent_action_exists(db: Session, mp: MountPoint, action_type: str, cooldown_seconds: int = None) -> bool:
    cooldown = settings.ACTION_LOG_COOLDOWN_SECONDS if cooldown_seconds is None else cooldown_seconds
    cutoff = dt.datetime.utcnow() - dt.timedelta(seconds=cooldown)
    return (
        db.query(ActionLog)
        .filter(ActionLog.mount_point_id == mp.id)
        .filter(ActionLog.action_type == action_type)
        .filter(ActionLog.created_at >= cutoff)
        .first()
        is not None
    )


def _log(db: Session, mp: MountPoint, action_type: str, status: ActionStatus, message: str):
    entry = ActionLog(
        server_id=mp.server_id,
        mount_point_id=mp.id,
        action_type=action_type,
        status=status,
        message=message,
    )
    db.add(entry)
    db.commit()
    return entry


def _log_decision(db: Session, mp: MountPoint, action_type: str, status: ActionStatus, message: str):
    if _recent_action_exists(db, mp, action_type):
        return None
    return _log(db, mp, action_type, status, message)


def _file_policy_summary(files, label: str, retention_days: int) -> str:
    protected = ", ".join(settings.EXCLUDE_FOLDER_MARKERS)
    if not files:
        return (
            f"AI decision for {label}: no eligible files found. Held all files because they are newer than "
            f"{retention_days}d, protected by one of [{protected}], or unavailable to scan."
        )
    total_gb = round(sum(f.size_gb for f in files), 2)
    oldest = min(f.modified_at for f in files).date().isoformat()
    newest = max(f.modified_at for f in files).date().isoformat()
    examples = ", ".join(os.path.basename(f.path) for f in files[:3])
    return (
        f"AI decision for {label}: selected {len(files)} old candidate file(s), {total_gb} GB total, "
        f"modified {oldest} to {newest}. Example candidate(s): {examples or 'n/a'}. "
        f"Held newer files and anything under protected folders [{protected}]."
    )


def _file_names(files, limit: int = 12) -> str:
    names = [os.path.basename(f.path) for f in files]
    if len(names) > limit:
        names = names[:limit] + [f"... +{len(files) - limit} more"]
    return ", ".join(names) if names else "none"


def _delete_old_file_candidates(files):
    deleted_files = []
    failed_files = []
    if settings.DEMO_MODE:
        return list(files), []
    for f in files:
        if scanner.is_path_protected(f.path, settings.EXCLUDE_FOLDER_MARKER):
            continue
        try:
            os.remove(f.path)
            deleted_files.append(f)
        except OSError:
            failed_files.append(f)
    return deleted_files, failed_files


def record_scan(db: Session, mp: MountPoint) -> ScanResult:
    try:
        usage = scanner.get_disk_usage(mp.path, mp.id)
    except OSError as e:
        _log(db, mp, "SCAN_FAILED", ActionStatus.FAILED, f"Could not reach {mp.path}: {e}")
        return None
    result = ScanResult(
        mount_point_id=mp.id,
        total_gb=usage.total_gb,
        used_gb=usage.used_gb,
        free_gb=usage.free_gb,
        used_pct=usage.used_pct,
    )
    db.add(result)
    db.commit()
    db.refresh(result)
    return result


def _history_tuples(db: Session, mp: MountPoint, limit: int = 60):
    rows = (
        db.query(ScanResult)
        .filter(ScanResult.mount_point_id == mp.id)
        .order_by(ScanResult.scanned_at.desc())
        .limit(limit)
        .all()
    )
    rows.reverse()
    if rows:
        latest_total = rows[-1].total_gb or 0
        if latest_total:
            rows = [
                r for r in rows
                if r.total_gb and abs(r.total_gb - latest_total) / latest_total <= 0.05
            ]
    return [(r.scanned_at, r.used_gb, r.total_gb) for r in rows]


def evaluate_mount_point(db: Session, mp: MountPoint, latest: ScanResult):
    """Dispatch to the right rule based on folder_type. Safe to call even if
    latest is None (e.g. scan failed) -- it just no-ops."""
    if latest is None:
        return

    threshold = mp.threshold_pct or settings.DEFAULT_THRESHOLD_PCT
    history = _history_tuples(db, mp)
    fc = predictor.forecast(history)

    if mp.folder_type == FolderType.SQLBACKUPS_MP:
        _handle_primary_backup_drive(db, mp, latest, threshold, fc)
    elif mp.folder_type == FolderType.SYSTEMBACKUPS_MP:
        _handle_primary_backup_drive(db, mp, latest, threshold, fc)
    elif mp.folder_type == FolderType.SQLBACKUP_MP2:
        pass  # handled from the *source* side, see _handle_primary_backup_drive
    elif mp.folder_type in (FolderType.SQLTEST_BACKUPS, FolderType.TESTBACKUPS_MP):
        _handle_test_backup_drive(db, mp, latest, threshold)
    elif mp.folder_type in (FolderType.LOG_DRIVE, FolderType.LOG_MP):
        _handle_log_drive(db, mp, latest, threshold)
    elif mp.folder_type == FolderType.DATA_MP:
        _handle_data_drive(db, mp, latest, threshold, fc)
    elif mp.folder_type == FolderType.TEMPDB_MP:
        _handle_tempdb_drive(db, mp, latest, threshold)
    elif mp.folder_type == FolderType.GENERAL:
        _handle_general_drive(db, mp, latest, threshold, fc)


def _handle_primary_backup_drive(db: Session, mp: MountPoint, latest: ScanResult,
                                  threshold: int, fc: dict):
    action_threshold = max(0, threshold - 10) if mp.folder_type == FolderType.SQLBACKUPS_MP else threshold
    if latest.used_pct < action_threshold:
        return

    # 1. First, see if we have a paired relief mount (sqlbackup_mp2) with room
    #    to silently absorb some files -- do this *before* alerting a human.
    relief_done = False
    if mp.paired_relief_mount_id:
        relief_mp = db.query(MountPoint).get(mp.paired_relief_mount_id)
        if relief_mp and relief_mp.folder_type == FolderType.SQLBACKUP_MP2:
            relief_done = _try_ai_rebalance(db, mp, latest, relief_mp, threshold)

    if relief_done:
        return  # no email needed, problem silently solved

    # 2. No relief available / not worth it -> find stale files + suggest space, email team.
    old_files = scanner.find_old_files(
        mp.path, settings.OLD_FILE_DAYS, settings.EXCLUDE_FOLDER_MARKER, mp.id
    )
    reclaimable_gb = round(sum(f.size_gb for f in old_files), 1)
    decision = _file_policy_summary(old_files, mp.label, settings.OLD_FILE_DAYS)

    if mp.folder_type == FolderType.SQLBACKUPS_MP:
        cleanup_done = _prepare_prod_backup_cleanup(db, mp, latest, old_files)
        if cleanup_done:
            return

    if _recent_action_exists(db, mp, "SPACE_ALERT", settings.ALERT_EMAIL_REPEAT_SECONDS):
        return

    summary = ai_client.explain_space_alert(
        mp.label, latest.used_pct, fc["growth_gb_per_day"],
        fc["days_to_threshold"], fc["recommended_add_gb"],
        fc.get("forecast_reliable", True), fc.get("forecast_note", ""),
    )
    growth_text = (
        f"~{fc['growth_gb_per_day']:.1f} GB/day"
        if fc.get("forecast_reliable")
        else f"not enough history ({fc.get('history_samples', 0)} sample(s), "
             f"{fc.get('history_span_hours', 0)} hour(s))"
    )
    recommended_text = (
        f"{fc['recommended_add_gb']} GB"
        if fc.get("forecast_reliable") and fc.get("recommended_add_gb")
        else "not calculated until growth history is reliable"
    )

    body = f"""
    <h3>Space alert: {mp.label} ({mp.server.name})</h3>
    <p>{summary}</p>
    <p><b>Current usage:</b> {latest.used_pct:.1f}% ({latest.used_gb:.1f} / {latest.total_gb:.1f} GB)</p>
    <p><b>Growth rate:</b> {growth_text}</p>
    <p><b>{len(old_files)} file(s) older than {settings.OLD_FILE_DAYS} days found</b>
       ({reclaimable_gb} GB total, excluding protected folders) --
       review before deleting manually.</p>
    <p><b>Recommended space to add:</b> {recommended_text}</p>
    """
    sent, note = email_service.send_email(f"[Space Alert] {mp.label} at {latest.used_pct:.1f}%", body)
    _log_decision(
        db, mp, "SPACE_ALERT", ActionStatus.ALERT,
        f"{mp.label} at {latest.used_pct:.1f}% (>= {threshold}%). "
        f"Found {len(old_files)} file(s) ({reclaimable_gb} GB) older than "
        f"{settings.OLD_FILE_DAYS}d as candidates. Recommended add: "
        f"{recommended_text}. {decision} {note}",
    )


def _try_ai_rebalance(db: Session, source_mp: MountPoint, source_latest: ScanResult,
                       dest_mp: MountPoint, threshold: int) -> bool:
    dest_latest = (
        db.query(ScanResult)
        .filter(ScanResult.mount_point_id == dest_mp.id)
        .order_by(ScanResult.scanned_at.desc())
        .first()
    )
    if dest_latest is None:
        return False

    old_files = sorted(
        scanner.find_old_files(source_mp.path, settings.OLD_FILE_DAYS,
                                settings.EXCLUDE_FOLDER_MARKER, source_mp.id),
        key=lambda f: f.modified_at,  # oldest first
    )
    if not old_files:
        return False

    dest_threshold = dest_mp.threshold_pct or threshold
    dest_free_to_threshold_gb = (dest_latest.total_gb * dest_threshold / 100) - dest_latest.used_gb
    source_excess_gb = source_latest.used_gb - (source_latest.total_gb * threshold / 100)

    to_move = []
    moved_gb = 0.0
    target_gb = min(dest_free_to_threshold_gb * 0.8, source_excess_gb * 1.5)  # don't fill dest either
    for f in old_files:
        if moved_gb + f.size_gb > target_gb:
            continue
        to_move.append(f)
        moved_gb += f.size_gb

    if moved_gb < 1:
        return False

    source_pct_after = ((source_latest.used_gb - moved_gb) / source_latest.total_gb) * 100
    dest_pct_after = ((dest_latest.used_gb + moved_gb) / dest_latest.total_gb) * 100

    relief_pct = source_latest.used_pct - source_pct_after
    if relief_pct < settings.MOVE_MIN_RELIEF_PCT or dest_pct_after >= dest_threshold:
        return False  # not worth it / would just move the problem

    if not settings.ENABLE_FILE_MOVE:
        _log_decision(
            db, source_mp, "AI_REBALANCE_HELD", ActionStatus.INFO,
            f"AI selected {len(to_move)} old backup file candidate(s), {moved_gb:.1f} GB, "
            f"to move from {source_mp.label} to {dest_mp.label}, but file moves are disabled. "
            f"Candidate file names: {_file_names(to_move)}. No files were moved.",
        )
        return False

    # In DEMO_MODE we simulate the move; in real mode this moves only files
    # that still pass the protected-folder check at action time.
    if not settings.DEMO_MODE:
        import shutil
        for f in to_move:
            if scanner.is_path_protected(f.path, settings.EXCLUDE_FOLDER_MARKER):
                continue
            try:
                shutil.move(f.path, dest_mp.path)
            except OSError:
                pass

    note = ai_client.explain_rebalance(source_mp.label, dest_mp.label, moved_gb,
                                        source_pct_after, dest_pct_after)
    _log_decision(
        db, source_mp, "AI_REBALANCE", ActionStatus.SUCCESS,
        f"Moved {moved_gb:.1f} GB ({len(to_move)} file(s)) from {source_mp.label} "
        f"to {dest_mp.label}. Projected: source {source_pct_after:.1f}%, "
        f"dest {dest_pct_after:.1f}%. {note}",
    )
    return True


def _send_prod_cleanup_reminder(db: Session, mp: MountPoint, latest: ScanResult, old_files, candidate_gb: float) -> None:
    if _recent_action_exists(db, mp, "PROD_BACKUP_CLEANUP_REMINDER", settings.BACKUP_CLEANUP_REMINDER_SECONDS):
        return
    sent, note = email_service.send_email(
        f"[Action required] Start guarded backup cleanup for {mp.label}",
        (
            f"<h3>Backup cleanup approval waiting</h3>"
            f"<p><b>{mp.label}</b> is at {latest.used_pct:.1f}%.</p>"
            f"<p>AI found {len(old_files)} old production backup candidate file(s), "
            f"{candidate_gb} GB total. The dashboard has a Start guarded cleanup button.</p>"
            "<p>When approved, SQL Space Guardian will first take fresh compressed full and "
            "differential backups, then delete only eligible old backup files outside protected folders.</p>"
            f"<p>If no one approves, this reminder repeats every {settings.BACKUP_CLEANUP_REMINDER_HOURS} hours while the alert remains.</p>"
        ),
    )
    _log(
        db, mp, "PROD_BACKUP_CLEANUP_REMINDER", ActionStatus.INFO,
        f"{mp.label} cleanup approval reminder sent/attempted. Candidate files: {len(old_files)}, "
        f"{candidate_gb} GB. {note}",
    )


def _prepare_prod_backup_cleanup(db: Session, mp: MountPoint, latest: ScanResult, old_files) -> bool:
    if not old_files:
        return False
    if _recent_action_exists(db, mp, "PROD_BACKUP_CLEANUP"):
        return True

    candidate_gb = round(sum(f.size_gb for f in old_files), 2)
    if not settings.ENABLE_FILE_DELETE:
        _log_decision(
            db, mp, "PROD_BACKUP_CLEANUP_HELD", ActionStatus.INFO,
            f"{mp.label} at {latest.used_pct:.1f}%. AI found {len(old_files)} old production "
            f"backup candidate file(s), {candidate_gb} GB, but deletion is disabled. "
            "Fresh backup/delete workflow held. "
            f"Candidate file names: {_file_names(old_files)}.",
        )
        _send_prod_cleanup_reminder(db, mp, latest, old_files, candidate_gb)
        return True

    if not (settings.ENABLE_SQL_OPS and mp.server and mp.server.sql_conn_string):
        _log_decision(
            db, mp, "PROD_BACKUP_CLEANUP_HELD", ActionStatus.INFO,
            f"{mp.label} at {latest.used_pct:.1f}%. AI found {len(old_files)} old production "
            f"backup candidate file(s), {candidate_gb} GB, but SQL backup preflight is not configured. "
            "No files deleted. Enable SQL ops and add a SQL connection string so a fresh full and "
            "differential compressed backup can be taken first.",
        )
        _send_prod_cleanup_reminder(db, mp, latest, old_files, candidate_gb)
        return True

    _log_decision(
        db, mp, "PROD_BACKUP_CLEANUP_READY", ActionStatus.ALERT,
        f"{mp.label} at {latest.used_pct:.1f}%. Guarded production backup cleanup is ready for approval. "
        f"AI found {len(old_files)} old production backup candidate file(s), {candidate_gb} GB. "
        "Tap Start guarded cleanup to take fresh compressed full and differential backups first, "
        "then delete only eligible old backup files outside protected folders.",
    )
    _send_prod_cleanup_reminder(db, mp, latest, old_files, candidate_gb)
    return True


def execute_prod_backup_cleanup(db: Session, mp: MountPoint) -> dict:
    latest = (
        db.query(ScanResult)
        .filter(ScanResult.mount_point_id == mp.id)
        .order_by(ScanResult.scanned_at.desc())
        .first()
    )
    if latest is None:
        raise ValueError("No scan data exists for this mount point yet.")
    if mp.folder_type != FolderType.SQLBACKUPS_MP:
        raise ValueError("This action is only available for sqlbackups_mp mount points.")

    old_files = scanner.find_old_files(
        mp.path, settings.OLD_FILE_DAYS, settings.EXCLUDE_FOLDER_MARKER, mp.id
    )
    if not old_files:
        _log(
            db, mp, "PROD_BACKUP_CLEANUP_HELD", ActionStatus.INFO,
            f"{mp.label}: no eligible old production backup files found; nothing deleted.",
        )
        return {"ok": False, "message": "No eligible old backup files found."}

    if not settings.ENABLE_FILE_DELETE:
        _log(
            db, mp, "PROD_BACKUP_CLEANUP_HELD", ActionStatus.FAILED,
            f"{mp.label}: guarded cleanup was requested, but ENABLE_FILE_DELETE is off. "
            "Enable File cleanup before starting deletion.",
        )
        return {"ok": False, "message": "File cleanup is disabled."}

    if not (settings.ENABLE_SQL_OPS and mp.server and mp.server.sql_conn_string):
        _log(
            db, mp, "PROD_BACKUP_CLEANUP_HELD", ActionStatus.FAILED,
            f"{mp.label}: guarded cleanup was requested, but SQL ops or connection string is missing.",
        )
        return {"ok": False, "message": "SQL ops or SQL connection string is missing."}

    if _recent_action_exists(db, mp, "PROD_BACKUP_CLEANUP_STARTED", 300):
        return {"ok": False, "message": "Cleanup already started recently."}

    start_entry = _log_decision(
        db, mp, "PROD_BACKUP_CLEANUP_STARTED", ActionStatus.INFO,
        f"{mp.label} at {latest.used_pct:.1f}%. Starting guarded cleanup: take fresh compressed "
        f"full and differential backups before deleting {len(old_files)} old candidate file(s).",
    )
    if start_entry is None:
        return {"ok": False, "message": "Cleanup already started recently."}

    backup_result = sql_ops.backup_user_databases_for_cleanup(mp.server.sql_conn_string, mp.path)
    if not backup_result.get("success"):
        _log(
            db, mp, "PROD_BACKUP_CLEANUP_HELD", ActionStatus.FAILED,
            f"{mp.label} old production backups held. Fresh backup step did not succeed. "
            f"{backup_result.get('note')}",
        )
        return {"ok": False, "message": backup_result.get("note")}

    deleted_files, failed_files = _delete_old_file_candidates(old_files)
    freed_gb = round(sum(f.size_gb for f in deleted_files), 2)
    projected_pct = max(latest.used_pct - (freed_gb / latest.total_gb * 100), 0)
    failed_note = f" Failed to delete: {_file_names(failed_files)}." if failed_files else ""
    _log(
        db, mp, "PROD_BACKUP_CLEANUP", ActionStatus.SUCCESS,
        f"{mp.label} guarded cleanup complete. {backup_result.get('note')} Deleted "
        f"{len(deleted_files)} old production backup file(s), {freed_gb} GB, older than "
        f"{settings.OLD_FILE_DAYS}d after fresh full and differential backup completed. "
        f"Projected usage: {projected_pct:.1f}%. Deleted file names: {_file_names(deleted_files)}."
        f"{failed_note}",
    )
    return {
        "ok": True,
        "message": f"Fresh backups completed and {len(deleted_files)} old file(s) deleted.",
        "freed_gb": freed_gb,
        "projected_pct": projected_pct,
    }


def _handle_test_backup_drive(db: Session, mp: MountPoint, latest: ScanResult, threshold: int):
    if latest.used_pct < threshold:
        return

    retention_days = settings.TEST_RESTORE_RETENTION_DAYS
    restore_done_recently = (
        mp.restore_marked_complete_at is not None
        and (dt.datetime.utcnow() - mp.restore_marked_complete_at) < dt.timedelta(days=1)
    )
    old_files = scanner.find_old_files(
        mp.path, retention_days, settings.EXCLUDE_FOLDER_MARKER, mp.id
    )
    if not old_files and not restore_done_recently:
        _log_decision(
            db, mp, "TEST_BACKUP_HOLD",
            ActionStatus.INFO,
            _file_policy_summary(old_files, mp.label, retention_days),
        )
        return

    if not settings.ENABLE_FILE_DELETE:
        candidate_gb = round(sum(f.size_gb for f in old_files), 2)
        _log_decision(
            db, mp, "TEST_BACKUP_CLEANUP_HELD",
            ActionStatus.INFO,
            f"{mp.label} at {latest.used_pct:.1f}%. AI found {len(old_files)} restore-test "
            f"backup candidate file(s), {candidate_gb} GB, but deletion is disabled. "
            f"Candidate file names: {_file_names(old_files)}. "
            "No files were deleted. Set ENABLE_FILE_DELETE=true only after protection rules are verified.",
        )
        return

    deleted_files, failed_files = _delete_old_file_candidates(old_files)

    actual_freed_gb = round(sum(f.size_gb for f in deleted_files), 2)
    projected_pct = max(latest.used_pct - (actual_freed_gb / latest.total_gb * 100), 0)
    decision = _file_policy_summary(old_files, mp.label, retention_days)
    failed_note = (
        f" Failed to delete: {_file_names(failed_files)}."
        if failed_files else ""
    )
    _log_decision(
        db, mp, "TEST_BACKUP_CLEANUP", ActionStatus.SUCCESS,
        f"{mp.label} at {latest.used_pct:.1f}%. Deleted {len(deleted_files)} restore-test "
        f"backup file(s) ({actual_freed_gb} GB) older than {retention_days}d"
        f"{' after restore marked complete' if restore_done_recently else ''}. "
        f"Deleted file names: {_file_names(deleted_files)}. "
        f"Projected usage now ~{projected_pct:.1f}%. {decision}{failed_note}",
    )


def _handle_log_drive(db: Session, mp: MountPoint, latest: ScanResult, threshold: int):
    warning_threshold = max(0, threshold - 10)
    if latest.used_pct < warning_threshold:
        return
    if (
        _recent_action_exists(db, mp, "AI_LOG_SHRINK")
        or _recent_action_exists(db, mp, "AI_LOG_SHRINK_STARTED")
    ):
        return

    server = mp.server
    start_entry = _log_decision(
        db, mp, "AI_LOG_SHRINK_STARTED", ActionStatus.INFO,
        f"{mp.label} is at {latest.used_pct:.1f}% (>= warning {warning_threshold}%). "
        "AI is checking SQL log metadata and shrink eligibility.",
    )
    if start_entry is None:
        return

    sent_start, start_note = email_service.send_email(
        f"[SQL Space Guardian] Starting SQL log shrink for {mp.label}",
        (
            f"<h3>Starting SQL log shrink</h3>"
            f"<p><b>{mp.label}</b> is at {latest.used_pct:.1f}%.</p>"
            "<p>AI is checking SQL log metadata, active transactions, log reuse wait, "
            "and then will shrink only if safe.</p>"
        ),
    )
    result = sql_ops.shrink_largest_log_on_mount(
        conn_string=server.sql_conn_string,
        log_mount_path=mp.path,
        target_mb=settings.LOG_SHRINK_TARGET_MB,
        log_backup_path=settings.LOG_BACKUP_PATH,
    )
    status = ActionStatus.SUCCESS if result.get("success") else ActionStatus.INFO
    if result.get("attempted") and not result.get("success"):
        status = ActionStatus.FAILED
    done_subject = (
        f"[SQL Space Guardian] SQL log shrink completed for {mp.label}"
        if result.get("success")
        else f"[SQL Space Guardian] SQL log shrink held/failed for {mp.label}"
    )
    sent_done, done_note = email_service.send_email(
        done_subject,
        (
            f"<h3>{'SQL log shrink completed' if result.get('success') else 'SQL log shrink held/failed'}</h3>"
            f"<p><b>{mp.label}</b> was at {latest.used_pct:.1f}%.</p>"
            f"<p>{result.get('note')}</p>"
        ),
    )
    _log(
        db, mp, "AI_LOG_SHRINK", status,
        f"{mp.label} at {latest.used_pct:.1f}%. {result.get('note')} "
        f"Start mail: {start_note} Completion mail: {done_note}",
    )


def _handle_data_drive(db: Session, mp: MountPoint, latest: ScanResult, threshold: int, fc: dict):
    if latest.used_pct < threshold:
        return
    relocation = _try_data_file_relocation(db, mp, latest, threshold)
    if relocation:
        return
    recommended_add = fc.get("recommended_add_gb") or 0
    _log_decision(
        db, mp, "DATA_FILE_ACTION",
        ActionStatus.ALERT,
        f"{mp.label} data files at {latest.used_pct:.1f}% (>= {threshold}%). "
        "AI decision: do not auto-delete or move .mdf/.ndf files. "
        "Action required: identify fastest-growing database files, plan a maintenance-window file move "
        "or add capacity. "
        f"Recommended additional capacity: {recommended_add or 'n/a'} GB. "
        "Held all data files because automatic movement can corrupt SQL Server databases if done online.",
    )


def _try_data_file_relocation(db: Session, source_mp: MountPoint, source_latest: ScanResult,
                              threshold: int) -> bool:
    server = source_mp.server
    if not server or not server.sql_conn_string:
        return False
    if (
        _recent_action_exists(db, source_mp, "AI_DATA_FILE_MOVE")
        or _recent_action_exists(db, source_mp, "AI_DATA_FILE_MOVE_STARTED")
    ):
        return True

    siblings = (
        db.query(MountPoint)
        .filter(MountPoint.server_id == source_mp.server_id)
        .filter(MountPoint.id != source_mp.id)
        .filter(MountPoint.folder_type == FolderType.DATA_MP)
        .all()
    )
    best_target = None
    best_latest = None
    best_free_to_threshold = 0.0

    for target in siblings:
        target_latest = (
            db.query(ScanResult)
            .filter(ScanResult.mount_point_id == target.id)
            .order_by(ScanResult.scanned_at.desc())
            .first()
        )
        if not target_latest or not target_latest.total_gb:
            continue
        target_threshold = target.threshold_pct or threshold
        free_to_threshold = (target_latest.total_gb * target_threshold / 100) - target_latest.used_gb
        if free_to_threshold <= 0:
            continue
        if free_to_threshold > best_free_to_threshold:
            best_target = target
            best_latest = target_latest
            best_free_to_threshold = free_to_threshold

    if not best_target:
        return False

    plan = sql_ops.plan_data_file_relocation(
        server.sql_conn_string,
        source_mp.path,
        best_target.path,
        best_free_to_threshold * 0.9,
    )
    if not plan.get("ok"):
        _log_decision(
            db, source_mp, "DATA_FILE_RELOCATION_HELD", ActionStatus.INFO,
            f"{source_mp.label} is at {source_latest.used_pct:.1f}%. AI checked sibling data mount "
            f"{best_target.label}, but no safe SQL data-file move was selected. {plan.get('note')}",
        )
        return True

    choice = plan["choice"]
    source_pct_after = max(
        ((source_latest.used_gb - choice["size_gb"]) / source_latest.total_gb) * 100,
        0,
    )
    target_pct_after = (
        ((best_latest.used_gb + choice["size_gb"]) / best_latest.total_gb) * 100
        if best_latest and best_latest.total_gb else 0
    )

    if not (settings.ENABLE_SQL_OPS and settings.ENABLE_SQL_DATA_FILE_MOVE):
        _log_decision(
            db, source_mp, "AI_DATA_FILE_MOVE_READY", ActionStatus.ALERT,
            f"{source_mp.label} is at {source_latest.used_pct:.1f}%. AI found relief mount "
            f"{best_target.label} with {best_free_to_threshold:.2f} GB safe room before threshold. "
            f"Recommended SQL data-file move: database {choice['database_name']}, logical file "
            f"{choice['logical_name']}, {choice['size_gb']:.2f} GB, from {choice['source_path']} "
            f"to {choice['target_path']}. Projected usage: source {source_pct_after:.1f}%, "
            f"target {target_pct_after:.1f}%. Automatic SQL file movement is disabled; run in a "
            f"maintenance window or enable ENABLE_SQL_OPS=true and ENABLE_SQL_DATA_FILE_MOVE=true. "
            f"Prepared steps: {plan['script']}",
        )
        return True

    start_entry = _log_decision(
        db, source_mp, "AI_DATA_FILE_MOVE_STARTED", ActionStatus.INFO,
        f"{source_mp.label} at {source_latest.used_pct:.1f}%. Starting SQL data-file move "
        f"for database {choice['database_name']}, logical file {choice['logical_name']}, "
        f"from {choice['source_path']} to {choice['target_path']}.",
    )
    if start_entry is None:
        return True

    sent_start, start_note = email_service.send_email(
        f"[SQL Space Guardian] Starting SQL data-file move for {source_mp.label}",
        (
            f"<h3>Starting SQL data-file move</h3>"
            f"<p>AI is starting a data-file move because <b>{source_mp.label}</b> "
            f"is at {source_latest.used_pct:.1f}%.</p>"
            f"<p><b>Database:</b> {choice['database_name']}<br>"
            f"<b>Logical file:</b> {choice['logical_name']}<br>"
            f"<b>From:</b> {choice['source_path']}<br>"
            f"<b>To:</b> {choice['target_path']}</p>"
            f"<p>The database will be taken offline briefly during the move.</p>"
        ),
    )
    result = sql_ops.relocate_data_file(server.sql_conn_string, choice)
    status = ActionStatus.SUCCESS if result.get("success") else ActionStatus.FAILED
    done_subject = (
        f"[SQL Space Guardian] SQL data-file move completed for {source_mp.label}"
        if result.get("success")
        else f"[SQL Space Guardian] SQL data-file move failed for {source_mp.label}"
    )
    sent_done, done_note = email_service.send_email(
        done_subject,
        (
            f"<h3>{'SQL data-file move completed' if result.get('success') else 'SQL data-file move failed'}</h3>"
            f"<p><b>{source_mp.label}</b> selected relief target <b>{best_target.label}</b>.</p>"
            f"<p>{result.get('note')}</p>"
            f"<p><b>Projected usage:</b> source {source_pct_after:.1f}%, target {target_pct_after:.1f}%.</p>"
        ),
    )
    _log(
        db, source_mp, "AI_DATA_FILE_MOVE", status,
        f"{source_mp.label} at {source_latest.used_pct:.1f}%. AI selected {best_target.label} "
        f"as relief target. {result.get('note')} Projected source {source_pct_after:.1f}%, "
        f"target {target_pct_after:.1f}%. Start mail: {start_note} Completion mail: {done_note}",
    )
    return True


def _handle_tempdb_drive(db: Session, mp: MountPoint, latest: ScanResult, threshold: int):
    if latest.used_pct < threshold:
        return
    _log_decision(
        db, mp, "TEMPDB_ACTION",
        ActionStatus.ALERT,
        f"{mp.label} tempdb mount at {latest.used_pct:.1f}% (>= {threshold}%). "
        "AI decision: no file deletion. Check active sessions, spills, version store, and long transactions. "
        "If relocation is needed, update tempdb file paths and restart SQL Server in a planned window.",
    )


def _handle_general_drive(db: Session, mp: MountPoint, latest: ScanResult, threshold: int, fc: dict):
    if latest.used_pct < threshold:
        return
    old_files = scanner.find_old_files(
        mp.path, settings.OLD_FILE_DAYS, settings.EXCLUDE_FOLDER_MARKER, mp.id
    )
    _log_decision(
        db, mp, "GENERAL_SPACE_REVIEW",
        ActionStatus.ALERT,
        f"{mp.label} at {latest.used_pct:.1f}% (>= {threshold}%). "
        f"{_file_policy_summary(old_files, mp.label, settings.OLD_FILE_DAYS)} "
        "No automatic delete was performed because this mount is typed General. "
        f"Recommended add: {fc.get('recommended_add_gb') or 'n/a'} GB.",
    )
