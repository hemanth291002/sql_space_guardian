# SQL Space Guardian

A single-page app + Python backend that watches SQL Server backup/log mount
points (the shares you reach today via `\\p07983\f$\...` on the jumpbox),
applies your team's space rules automatically, and keeps a live "ops log" of
every action it took.

## What it actually does, per folder type

| Folder type | Rule |
|---|---|
| **SQLBackups_MP** (primary backups) | At ≥80% usage: first tries to silently rebalance into a paired `SQLBackup_MP2` mount (see below). If that's not possible/not enough, it lists backup files older than 5 days (skipping any folder with `don_not_delete` in the name) and **emails the team** with the growth rate and a recommended number of GB to add — sized so you keep a safe runway even with daily backups landing. |
| **SQLBackup_MP2** (relief target) | Not alerted on directly. When its paired primary drive is over threshold, this is where old backup files get moved to automatically — but only if the move is actually worth it: it must relieve the source by at least `MOVE_MIN_RELIEF_PCT` (default 5%) *and* keep the destination itself under its own threshold. If neither holds, it backs off and lets the alert path handle it instead. No alert email is sent for a successful silent rebalance — it just shows up in the ops log. |
| **SQLTest_Backups** (restore/testing drive) | At ≥80%: deletes backup files older than `TEST_RESTORE_RETENTION_DAYS` (default 3 days), or right after you click **"mark restore complete"** on that card. `don_not_delete` folders are always skipped. |
| **Log drive** | At ≥80%: attempts `DBCC SHRINKFILE`. If that fails, runs `BACKUP LOG` first, then retries the shrink. (Off by default — see **Turning on real SQL Server actions** below.) |

Every action — alert, rebalance, cleanup, shrink attempt — is written to the
ops log at the bottom of the screen with a timestamp, and a summary of what
happened is what gets emailed to the team.

Space is also **predicted**: each mount point keeps a rolling history of
scans, fits a trend line, and shows "reaches threshold in ~N days" plus the
recommended GB to add — so the team isn't just reacting when the alert fires.

## Running it

```bash
cd sql_space_guardian
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # then edit .env, see below
cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000` (or `http://<jumpbox-host>:8000` from any
machine on the network). Click **+ Add server**, give it a name, the jumpbox
host, and add each mount point with its real UNC path and folder type. Data
is stored locally in `data/app.db` (SQLite) — nothing is written back to the
SQL servers or databases themselves; this only reads free/used space and
backup-folder file listings.

It comes up in **DEMO_MODE=true** so you can click around and see the whole
thing working — gauges, sparklines, the ops log, the rebalance/cleanup logic
— with realistic simulated numbers before it ever touches a real server.

### Going live against your real shares

1. Set `DEMO_MODE=false` in `.env`.
2. Add servers with the real paths, e.g. `\\p07983\f$\SQLBackups_MP`.
3. Run the app **on a box that can actually see those shares** (the jumpbox
   itself, or a service account with access to it) — a browser-only
   deployment can't reach a UNC path, this needs to run server-side there.
4. Fill in `SMTP_HOST` / `TEAM_EMAIL` in `.env` so the space-alert emails
   actually send (until then, it logs "would have sent" so nothing blocks).
5. Optional: drop in your free AI API key (`AI_API_KEY`, and `AI_API_BASE`
   if it's not OpenAI itself) — this is used to phrase the alert/rebalance
   email text more naturally. Every rule and number is computed in plain
   Python regardless of whether AI is configured, so monitoring works with
   or without it; the key only changes the wording.

### Turning on real SQL Server log shrink/backup

The log-drive rule (`DBCC SHRINKFILE`, `BACKUP LOG`) needs a real SQL
connection, so it's off by default (`ENABLE_SQL_OPS=false`, dry-run only).
To enable it:

```
pip install pyodbc   # plus an ODBC Driver for SQL Server on the host
```
Set `ENABLE_SQL_OPS=true` and put a real connection string on each Server
(the `sql_conn_string` field — extend the "Add server" form or set it via
the API) that has permission to run those commands.

## Multi-server support

There's no limit on the number of servers or mount points — "+ Add server"
in the top bar handles that, and everything is listed on the one dashboard,
grouped by server.

## Recommended SQL mount/folder standard

SQL Server Express starts with a single default `DATA` folder, so data files,
log files, tempdb files, and system database files can all appear together
there. The app can monitor a cleaner DBA-standard layout, but SQL Server does
not create or move those folders automatically.

For a local lab box, a structure like this is easier to monitor:

```
C:\SQLMounts\
  data_mp\            user database .mdf / .ndf files
  log_mp\             user database .ldf files
  tempdb_mp\          tempdb files
  sqlbackups_mp\      user database backups
  testbackups_mp\     restore / validation backups
  systembackups_mp\   master, model, msdb backups
```

Moving existing SQL database files should be done as a planned SQL Server
operation with backups and a maintenance window. SQL Space Guardian monitors
these paths and gives guidance; it does not automatically move live `.mdf`,
`.ndf`, or `.ldf` files.

## Assumptions I made (flag anything you want changed)

- **SQLBackups_MP over threshold**: I report the >5-day-old files and email
  a recommendation rather than auto-deleting them — deleting backups
  automatically without a human sign-off felt too risky by default. If you
  actually want auto-delete here too, it's a small change in `actions.py`.
- **"Worth it" for the MP→MP2 move**: at least 5% relief on the source and
  the destination must stay under its own threshold. Both numbers are in
  `.env` (`MOVE_MIN_RELIEF_PCT`, per-mount `threshold_pct`) if you want them
  tighter or looser.
- **SQLTest_Backups auto-delete**: triggers on files older than 3 days OR
  right after "mark restore complete" is clicked — there wasn't an
  automatic signal in the request for "the restore activity is done," so
  that's a manual button on the card for now.
- Real filesystem scanning and the log-shrink SQL commands are implemented
  for real, but ship **off** (demo data / dry run) until you flip the two
  flags above, since I can't reach your actual jumpbox/servers from here to
  test against them directly.

## Project layout

```
backend/    FastAPI app, SQLite models, the scanning/rule engine, scheduler
frontend/   Single HTML page, vanilla JS (no build step), Chart-free custom SVG gauges/sparklines
data/       app.db lives here (created on first run)
```
